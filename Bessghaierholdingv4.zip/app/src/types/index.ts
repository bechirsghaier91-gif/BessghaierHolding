export interface Property {
  id: string;
  title: string;
  description: string;
  price: number;
  location: string;
  type: 'rent' | 'sale';
  status: 'available' | 'reserved' | 'unavailable';
  images: string[];
  features: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Book {
  id: string;
  title: string;
  description: string;
  price: number;
  currency: string;
  image: string;
  kindleLink: string;
  author: string;
  createdAt: string;
  updatedAt: string;
}

export interface Room {
  id: string;
  name: string;
  slug: string;
  description: string;
  icon: string;
  order: number;
  isActive: boolean;
  createdAt: string;
}

export interface Post {
  id: string;
  roomId: string;
  roomName?: string;
  title: string;
  content: string;
  images: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Booking {
  id: string;
  propertyId: string;
  propertyTitle: string;
  name: string;
  phone: string;
  email: string;
  checkIn: string;
  checkOut: string;
  message: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  updatedAt: string;
}

export interface Review {
  id: string;
  type: 'property' | 'book' | 'general';
  targetId: string;
  name: string;
  email: string;
  rating: number;
  comment: string;
  isApproved: boolean;
  createdAt: string;
}

export interface User {
  id: string;
  uid: string;
  name: string;
  email: string;
  phone: string;
  role: 'user' | 'admin';
  whatsappNumber: string;
  createdAt: string;
}

export interface Collaboration {
  id: string;
  name: string;
  email: string;
  phone: string;
  whatsapp: string;
  status: 'applied' | 'rules_signed' | 'price_set' | 'approved' | 'payment_pending' | 'completed' | 'rejected';
  rulesAccepted: boolean;
  signatureData: string;
  price: number;
  rulesContent: string;
  adminNotes: string;
  messages: CollaborationMessage[];
  createdAt: string;
  updatedAt: string;
}

export interface CollaborationMessage {
  sender: 'admin' | 'user';
  text: string;
  timestamp: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'booking' | 'collab' | 'payment' | 'message' | 'system';
  isRead: boolean;
  link: string;
  createdAt: string;
}

export interface SiteSettings {
  id: string;
  logo: string;
  siteName: string;
  contactEmail: string;
  contactPhone: string;
  whatsappNumber: string;
  rulesContent: string;
  socialLinks: {
    facebook: string;
    instagram: string;
    linkedin: string;
    youtube: string;
  };
  updatedAt: string;
}

export interface Toast {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  message: string;
}

export interface ServiceCard {
  icon: string;
  title: string;
  description: string;
  tags: string[];
  link: string;
}

export interface NavItem {
  label: string;
  path: string;
  icon?: string;
}

export interface AdminNavItem {
  label: string;
  path: string;
  icon: string;
  badge?: string;
}
