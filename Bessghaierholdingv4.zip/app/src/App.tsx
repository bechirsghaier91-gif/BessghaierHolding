import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import { ToastProvider } from '@/contexts/ToastContext';
import { useAuth } from '@/contexts/AuthContext';
import PublicLayout from '@/components/PublicLayout';
import Home from '@/pages/public/Home';
import Books from '@/pages/public/Books';
import Travel from '@/pages/public/Travel';
import RealEstate from '@/pages/public/RealEstate';
import Consulting from '@/pages/public/Consulting';
import Marketing from '@/pages/public/Marketing';
import Magazine from '@/pages/public/Magazine';
import Rules from '@/pages/public/Rules';
import Apply from '@/pages/public/Apply';
import Login from '@/pages/public/Login';
import AdminLayout from '@/components/AdminLayout';
import AdminDashboard from '@/pages/admin/AdminDashboard';
import AdminProperties from '@/pages/admin/AdminProperties';
import AdminBooks from '@/pages/admin/AdminBooks';
import AdminPostsRooms from '@/pages/admin/AdminPostsRooms';
import AdminBookings from '@/pages/admin/AdminBookings';
import AdminCollaborations from '@/pages/admin/AdminCollaborations';
import AdminReviews from '@/pages/admin/AdminReviews';
import AdminUsers from '@/pages/admin/AdminUsers';
import AdminSettings from '@/pages/admin/AdminSettings';
import NotFound from '@/pages/public/NotFound';
import { useEffect } from 'react';
import { seedAllData } from '@/lib/seedData';

function AdminGuard({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuth();
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
}

function AppRoutes() {
  useEffect(() => {
    seedAllData();
  }, []);

  return (
    <Routes>
      {/* Public Routes */}
      <Route element={<PublicLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/books" element={<Books />} />
        <Route path="/travel" element={<Travel />} />
        <Route path="/real-estate" element={<RealEstate />} />
        <Route path="/consulting" element={<Consulting />} />
        <Route path="/marketing" element={<Marketing />} />
        <Route path="/magazine" element={<Magazine />} />
        <Route path="/rules" element={<Rules />} />
        <Route path="/apply" element={<Apply />} />
        <Route path="/login" element={<Login />} />
      </Route>

      {/* Admin Routes */}
      <Route path="/admin" element={<AdminGuard><AdminLayout /></AdminGuard>}>
        <Route index element={<AdminDashboard />} />
        <Route path="properties" element={<AdminProperties />} />
        <Route path="books" element={<AdminBooks />} />
        <Route path="posts" element={<AdminPostsRooms />} />
        <Route path="bookings" element={<AdminBookings />} />
        <Route path="collaborations" element={<AdminCollaborations />} />
        <Route path="reviews" element={<AdminReviews />} />
        <Route path="users" element={<AdminUsers />} />
        <Route path="settings" element={<AdminSettings />} />
      </Route>

      {/* 404 */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <AppRoutes />
      </ToastProvider>
    </AuthProvider>
  );
}
