import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard, Home, BookOpen, FileText, Calendar, Handshake, Star, Users, Settings, LogOut, Menu
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/contexts/ToastContext';

const adminNavItems = [
  { label: 'Dashboard', path: '/admin', icon: LayoutDashboard },
  { label: 'Properties', path: '/admin/properties', icon: Home },
  { label: 'Books', path: '/admin/books', icon: BookOpen },
  { label: 'Posts & Rooms', path: '/admin/posts', icon: FileText },
  { label: 'Bookings', path: '/admin/bookings', icon: Calendar },
  { label: 'Collaborations', path: '/admin/collaborations', icon: Handshake },
  { label: 'Reviews', path: '/admin/reviews', icon: Star },
  { label: 'Users', path: '/admin/users', icon: Users },
  { label: 'Site Settings', path: '/admin/settings', icon: Settings },
];

function Sidebar({ mobileOpen, onClose }: { mobileOpen: boolean; onClose: () => void }) {
  const location = useLocation();

  const sidebarContent = (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-6 border-b border-white/8">
        <Link to="/admin" className="flex items-center gap-3 group" onClick={onClose}>
          <div className="w-10 h-10 rounded-full bg-gold/20 flex items-center justify-center border border-gold/30">
            <span className="font-display font-bold text-gold text-sm">BH</span>
          </div>
          <div>
            <span className="font-display font-semibold text-gold block leading-tight">BESSGHAIER</span>
            <span className="text-[10px] uppercase tracking-[0.2em] text-white/40">Admin</span>
          </div>
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-4 overflow-y-auto scrollbar-thin">
        {adminNavItems.map(item => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;
          return (
            <Link
              key={item.path}
              to={item.path}
              onClick={onClose}
              className={`flex items-center gap-3 px-5 py-3 mx-3 rounded-lg transition-all duration-200 text-sm font-medium ${
                isActive
                  ? 'bg-gold/15 text-gold border-l-[3px] border-gold'
                  : 'text-white/60 hover:text-white hover:bg-white/5 border-l-[3px] border-transparent'
              }`}
            >
              <Icon className="w-[18px] h-[18px]" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      {/* Logout */}
      <div className="p-4 border-t border-white/8">
        <LogoutButton />
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block fixed top-0 left-0 w-[240px] h-screen bg-[#141414] border-r border-white/8 z-40">
        {sidebarContent}
      </aside>

      {/* Mobile Sidebar Drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 z-40 lg:hidden"
              onClick={onClose}
            />
            <motion.aside
              initial={{ x: -240 }}
              animate={{ x: 0 }}
              exit={{ x: -240 }}
              transition={{ type: 'tween', duration: 0.3 }}
              className="fixed top-0 left-0 w-[240px] h-screen bg-[#141414] border-r border-white/8 z-50 lg:hidden"
            >
              {sidebarContent}
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

function LogoutButton() {
  const { logout } = useAuth();
  const { addToast } = useToast();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    addToast('success', 'Logged out successfully');
    navigate('/');
  };

  return (
    <button
      onClick={handleLogout}
      className="flex items-center gap-3 px-5 py-3 w-full rounded-lg text-white/60 hover:text-red-400 hover:bg-red-400/10 transition-all text-sm font-medium"
    >
      <LogOut className="w-[18px] h-[18px]" />
      Logout
    </button>
  );
}

function TopBar({ onMenuClick }: { onMenuClick: () => void }) {
  const location = useLocation();
  const currentSection = adminNavItems.find(item => item.path === location.pathname);

  return (
    <header className="fixed top-0 left-0 lg:left-[240px] right-0 h-16 bg-[#0A0A0A]/95 backdrop-blur-xl border-b border-white/8 z-30 flex items-center justify-between px-6">
      <div className="flex items-center gap-4">
        <button
          onClick={onMenuClick}
          className="lg:hidden p-2 text-white/70 hover:text-white transition-colors"
        >
          <Menu className="w-5 h-5" />
        </button>
        <div>
          <h1 className="font-display font-semibold text-white text-lg">{currentSection?.label || 'Dashboard'}</h1>
          <p className="text-white/40 text-xs hidden sm:block">Admin / {currentSection?.label || 'Dashboard'}</p>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <Link
          to="/"
          className="hidden sm:flex items-center gap-2 px-4 py-2 text-white/60 hover:text-gold text-sm transition-colors"
        >
          <span>View Site</span>
        </Link>
      </div>
    </header>
  );
}

export default function AdminLayout() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white">
      <Sidebar mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} />
      <TopBar onMenuClick={() => setMobileOpen(true)} />

      <main className="lg:ml-[240px] pt-16 min-h-screen">
        <div className="p-6 lg:p-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
