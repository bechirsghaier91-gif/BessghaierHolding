const statusStyles: Record<string, string> = {
  available: 'bg-green-500/15 text-green-500 border border-green-500/30',
  reserved: 'bg-yellow-500/15 text-yellow-500 border border-yellow-500/30',
  unavailable: 'bg-gray-500/15 text-gray-400 border border-gray-500/30',
  pending: 'bg-yellow-500/15 text-yellow-500 border border-yellow-500/30',
  approved: 'bg-green-500/15 text-green-500 border border-green-500/30',
  rejected: 'bg-red-500/15 text-red-500 border border-red-500/30',
  applied: 'bg-blue-500/15 text-blue-500 border border-blue-500/30',
  'rules_signed': 'bg-purple-500/15 text-purple-500 border border-purple-500/30',
  'price_set': 'bg-purple-500/15 text-purple-500 border border-purple-500/30',
  'payment_pending': 'bg-orange-500/15 text-orange-500 border border-orange-500/30',
  completed: 'bg-green-500/15 text-green-500 border border-green-500/30',
  rent: 'bg-gold/15 text-gold border border-gold/30',
  sale: 'bg-blue-500/15 text-blue-500 border border-blue-500/30',
  user: 'bg-white/10 text-white/60 border border-white/20',
  admin: 'bg-gold/15 text-gold border border-gold/30',
};

interface StatusBadgeProps {
  status: string;
  label?: string;
}

export default function StatusBadge({ status, label }: StatusBadgeProps) {
  const style = statusStyles[status.toLowerCase()] || statusStyles.unavailable;
  const displayLabel = label || status.charAt(0).toUpperCase() + status.slice(1).replace('_', ' ');

  return (
    <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium capitalize ${style}`}>
      {displayLabel}
    </span>
  );
}
