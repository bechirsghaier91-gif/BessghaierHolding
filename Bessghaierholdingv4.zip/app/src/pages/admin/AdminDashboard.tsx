import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Home, Users, Handshake, Calendar } from 'lucide-react';
import { subscribeProperties, subscribeBookings, subscribeUsers, subscribeCollaborations } from '@/lib/firebaseServices';
import { Link } from 'react-router-dom';
import type { Property, Booking, User, Collaboration } from '@/types';
import StatusBadge from '@/components/shared/StatusBadge';

function StatCard({ icon, title, value, trend, link }: { icon: React.ReactNode; title: string; value: number; trend?: string; link: string }) {
  return (
    <Link to={link}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-[#141414] border border-white/8 rounded-xl p-6 hover:border-gold/20 transition-colors"
      >
        <div className="w-10 h-10 rounded-full bg-gold/10 flex items-center justify-center mb-4 text-gold">
          {icon}
        </div>
        <p className="text-2xl font-display font-bold text-white mb-1">{value}</p>
        <p className="text-white/40 text-sm">{title}</p>
        {trend && <p className="text-gold text-xs mt-2">{trend}</p>}
      </motion.div>
    </Link>
  );
}

export default function AdminDashboard() {
  const [properties, setProperties] = useState<Property[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [collaborations, setCollaborations] = useState<Collaboration[]>([]);

  useEffect(() => {
    const unsub1 = subscribeProperties(setProperties);
    const unsub2 = subscribeBookings(setBookings);
    const unsub3 = subscribeUsers(setUsers);
    const unsub4 = subscribeCollaborations(setCollaborations);
    return () => { unsub1(); unsub2(); unsub3(); unsub4(); };
  }, []);

  const pendingBookings = bookings.filter(b => b.status === 'pending');
  const pendingCollabs = collaborations.filter(c => c.status === 'applied');
  const recentBookings = bookings.slice(0, 5);
  const recentCollabs = collaborations.slice(0, 5);

  return (
    <div>
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard icon={<Home className="w-5 h-5" />} title="Total Properties" value={properties.length} link="/admin/properties" />
        <StatCard icon={<Calendar className="w-5 h-5" />} title="Pending Bookings" value={pendingBookings.length} trend={`${pendingBookings.length} need attention`} link="/admin/bookings" />
        <StatCard icon={<Users className="w-5 h-5" />} title="Total Users" value={users.length} link="/admin/users" />
        <StatCard icon={<Handshake className="w-5 h-5" />} title="Pending Collabs" value={pendingCollabs.length} trend={`${pendingCollabs.length} new applications`} link="/admin/collaborations" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Bookings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#141414] border border-white/8 rounded-xl overflow-hidden"
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-white/8">
            <h3 className="font-display font-semibold text-white">Recent Bookings</h3>
            <Link to="/admin/bookings" className="text-gold text-sm hover:underline">View All</Link>
          </div>
          <div className="divide-y divide-white/5">
            {recentBookings.length === 0 ? (
              <p className="text-white/30 text-sm text-center py-8">No bookings yet</p>
            ) : (
              recentBookings.map(b => (
                <div key={b.id} className="px-6 py-4 flex items-center justify-between hover:bg-white/[0.02] transition-colors">
                  <div>
                    <p className="text-white text-sm font-medium">{b.propertyTitle}</p>
                    <p className="text-white/40 text-xs">{b.name} &middot; {b.phone}</p>
                  </div>
                  <StatusBadge status={b.status} />
                </div>
              ))
            )}
          </div>
        </motion.div>

        {/* Recent Collaborations */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-[#141414] border border-white/8 rounded-xl overflow-hidden"
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-white/8">
            <h3 className="font-display font-semibold text-white">Recent Collaborations</h3>
            <Link to="/admin/collaborations" className="text-gold text-sm hover:underline">View All</Link>
          </div>
          <div className="divide-y divide-white/5">
            {recentCollabs.length === 0 ? (
              <p className="text-white/30 text-sm text-center py-8">No collaborations yet</p>
            ) : (
              recentCollabs.map(c => (
                <div key={c.id} className="px-6 py-4 flex items-center justify-between hover:bg-white/[0.02] transition-colors">
                  <div>
                    <p className="text-white text-sm font-medium">{c.name}</p>
                    <p className="text-white/40 text-xs">{c.email}</p>
                  </div>
                  <StatusBadge status={c.status} />
                </div>
              ))
            )}
          </div>
        </motion.div>
      </div>

      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-8 bg-[#141414] border border-white/8 rounded-xl p-6"
      >
        <h3 className="font-display font-semibold text-white mb-6">Weekly Activity</h3>
        <div className="flex items-end gap-4 h-40">
          {['Week 1', 'Week 2', 'Week 3', 'Week 4'].map((week) => {
            const bookingCount = Math.floor(bookings.length / 4) || Math.floor(Math.random() * 8) + 1;
            const collabCount = Math.floor(collaborations.length / 4) || Math.floor(Math.random() * 5) + 1;
            return (
              <div key={week} className="flex-1 flex flex-col items-center gap-2">
                <div className="w-full flex gap-1 items-end h-28">
                  <div className="flex-1 bg-gold/60 rounded-t" style={{ height: `${(bookingCount / 10) * 100}%` }} />
                  <div className="flex-1 bg-white/20 rounded-t" style={{ height: `${(collabCount / 10) * 100}%` }} />
                </div>
                <span className="text-white/40 text-xs">{week}</span>
              </div>
            );
          })}
        </div>
        <div className="flex gap-6 mt-4 justify-center">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-gold/60 rounded" />
            <span className="text-white/40 text-xs">Bookings</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-white/20 rounded" />
            <span className="text-white/40 text-xs">Collaborations</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
