import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Save, Globe, Mail, Phone, Image, FileText, Facebook, Instagram, Linkedin, Youtube } from 'lucide-react';
import { subscribeSiteSettings, updateSiteSettings } from '@/lib/firebaseServices';
import { useToast } from '@/contexts/ToastContext';
import type { SiteSettings } from '@/types';

export default function AdminSettings() {
  const [, setSettings] = useState<SiteSettings | null>(null);
  const [activeTab, setActiveTab] = useState('general');
  const [form, setForm] = useState<Partial<SiteSettings>>({});
  const { addToast } = useToast();

  useEffect(() => {
    const unsub = subscribeSiteSettings((s) => {
      setSettings(s);
      if (s) setForm(s);
    });
    return () => unsub();
  }, []);

  const handleSave = async () => {
    try {
      await updateSiteSettings(form);
      addToast('success', 'Settings saved successfully!');
    } catch {
      addToast('error', 'Failed to save settings');
    }
  };

  const tabs = [
    { id: 'general', label: 'General', icon: Globe },
    { id: 'social', label: 'Social Links', icon: Facebook },
    { id: 'rules', label: 'Rules Content', icon: FileText },
  ];

  return (
    <div>
      {/* Tabs */}
      <div className="flex gap-2 mb-8">
        {tabs.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-medium transition-all ${activeTab === tab.id ? 'bg-gold text-[#0A0A0A]' : 'bg-[#141414] text-white/60 border border-white/10 hover:border-gold/30'}`}>
            <tab.icon className="w-4 h-4" /> {tab.label}
          </button>
        ))}
      </div>

      <div className="max-w-2xl">
        {/* General Tab */}
        {activeTab === 'general' && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <div className="bg-[#141414] border border-white/8 rounded-xl p-6">
              <h3 className="font-display text-lg font-semibold text-white mb-6 flex items-center gap-2"><Image className="w-5 h-5 text-gold" /> Logo</h3>
              <div className="flex items-center gap-4 mb-4">
                {form.logo ? <img src={form.logo} alt="Logo" className="w-20 h-20 object-contain" /> : <div className="w-20 h-20 rounded-full bg-gold/20 flex items-center justify-center border border-gold/30"><span className="font-display font-bold text-gold text-lg">BH</span></div>}
                <input type="text" value={form.logo || ''} onChange={e => setForm({ ...form, logo: e.target.value })} placeholder="Logo image URL" className="flex-1 bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" />
              </div>
            </div>

            <div className="bg-[#141414] border border-white/8 rounded-xl p-6">
              <h3 className="font-display text-lg font-semibold text-white mb-6">Site Information</h3>
              <div className="space-y-4">
                <div><label className="text-white/60 text-sm mb-1 block">Site Name</label><input type="text" value={form.siteName || ''} onChange={e => setForm({ ...form, siteName: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" /></div>
                <div><label className="text-white/60 text-sm mb-1 block flex items-center gap-2"><Mail className="w-4 h-4 text-gold" /> Contact Email</label><input type="email" value={form.contactEmail || ''} onChange={e => setForm({ ...form, contactEmail: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" /></div>
                <div><label className="text-white/60 text-sm mb-1 block flex items-center gap-2"><Phone className="w-4 h-4 text-gold" /> Contact Phone</label><input type="tel" value={form.contactPhone || ''} onChange={e => setForm({ ...form, contactPhone: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" /></div>
                <div><label className="text-white/60 text-sm mb-1 block flex items-center gap-2"><Phone className="w-4 h-4 text-gold" /> WhatsApp Number</label><input type="tel" value={form.whatsappNumber || ''} onChange={e => setForm({ ...form, whatsappNumber: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" /></div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Social Links Tab */}
        {activeTab === 'social' && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-[#141414] border border-white/8 rounded-xl p-6 space-y-4">
            <h3 className="font-display text-lg font-semibold text-white mb-4">Social Media Links</h3>
            {[
              { key: 'facebook', label: 'Facebook', icon: Facebook },
              { key: 'instagram', label: 'Instagram', icon: Instagram },
              { key: 'linkedin', label: 'LinkedIn', icon: Linkedin },
              { key: 'youtube', label: 'YouTube', icon: Youtube },
            ].map(social => (
              <div key={social.key}>
                <label className="text-white/60 text-sm mb-1 block flex items-center gap-2"><social.icon className="w-4 h-4 text-gold" /> {social.label}</label>
                <input
                  type="url"
                  value={(form.socialLinks as Record<string, string>)?.[social.key] || ''}
                  onChange={e => setForm({ ...form, socialLinks: { ...(form.socialLinks || {}), [social.key]: e.target.value } as SiteSettings['socialLinks'] })}
                  placeholder={`https://${social.key.toLowerCase()}.com/...`}
                  className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none"
                />
              </div>
            ))}
          </motion.div>
        )}

        {/* Rules Content Tab */}
        {activeTab === 'rules' && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-[#141414] border border-white/8 rounded-xl p-6">
            <h3 className="font-display text-lg font-semibold text-white mb-4 flex items-center gap-2"><FileText className="w-5 h-5 text-gold" /> Rules & Terms Content</h3>
            <p className="text-white/40 text-sm mb-4">Edit the HTML content that appears on the Rules page. You can use HTML tags for formatting.</p>
            <textarea
              value={form.rulesContent || ''}
              onChange={e => setForm({ ...form, rulesContent: e.target.value })}
              rows={20}
              className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none font-mono resize-none"
            />
            <div className="mt-4 p-4 bg-[#1A1A1A] rounded-lg border border-white/5">
              <p className="text-white/40 text-xs mb-2">Preview:</p>
              <div className="prose prose-invert max-w-none prose-headings:font-display prose-headings:text-gold prose-p:text-white/60" dangerouslySetInnerHTML={{ __html: form.rulesContent || '<p class="text-white/30">No content yet...</p>' }} />
            </div>
          </motion.div>
        )}

        {/* Save Button */}
        <div className="mt-8 sticky bottom-6">
          <button onClick={handleSave} className="w-full py-4 bg-gold text-[#0A0A0A] rounded-xl font-semibold text-lg hover:bg-gold-light transition-colors flex items-center justify-center gap-2 shadow-gold">
            <Save className="w-5 h-5" /> Save All Settings
          </button>
        </div>
      </div>
    </div>
  );
}
