import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Pencil, Trash2, X, BookOpen, Home, Plane, TrendingUp, Megaphone, Star, GripVertical } from 'lucide-react';
import { subscribeRooms, subscribePosts, addRoom, updateRoom, deleteRoom, addPost, updatePost, deletePost } from '@/lib/firebaseServices';
import { useToast } from '@/contexts/ToastContext';
import type { Room, Post } from '@/types';

const iconOptions = [
  { name: 'BookOpen', icon: BookOpen }, { name: 'Home', icon: Home }, { name: 'Plane', icon: Plane },
  { name: 'TrendingUp', icon: TrendingUp }, { name: 'Megaphone', icon: Megaphone }, { name: 'Star', icon: Star },
];

export default function AdminPostsRooms() {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [selectedRoom, setSelectedRoom] = useState<string>('all');
  const [roomModal, setRoomModal] = useState(false);
  const [postModal, setPostModal] = useState(false);
  const [editingRoom, setEditingRoom] = useState<Room | null>(null);
  const [editingPost, setEditingPost] = useState<Post | null>(null);
  const [roomForm, setRoomForm] = useState({ name: '', slug: '', description: '', icon: 'BookOpen', order: '0', isActive: true });
  const [postForm, setPostForm] = useState({ title: '', content: '', roomId: '', images: [] as string[] });
  const { addToast } = useToast();

  useEffect(() => {
    const unsub1 = subscribeRooms(setRooms);
    const unsub2 = subscribePosts(selectedRoom === 'all' ? undefined : selectedRoom, setPosts);
    return () => { unsub1(); unsub2(); };
  }, [selectedRoom]);

  const openRoomAdd = () => {
    setEditingRoom(null);
    setRoomForm({ name: '', slug: '', description: '', icon: 'BookOpen', order: String(rooms.length + 1), isActive: true });
    setRoomModal(true);
  };

  const openRoomEdit = (r: Room) => {
    setEditingRoom(r);
    setRoomForm({ name: r.name, slug: r.slug, description: r.description, icon: r.icon, order: String(r.order), isActive: r.isActive });
    setRoomModal(true);
  };

  const saveRoom = async () => {
    if (!roomForm.name) { addToast('error', 'Room name is required'); return; }
    const slug = roomForm.slug || roomForm.name.toLowerCase().replace(/\s+/g, '-');
    const data = { name: roomForm.name, slug, description: roomForm.description, icon: roomForm.icon, order: Number(roomForm.order), isActive: roomForm.isActive };
    try {
      if (editingRoom) { await updateRoom(editingRoom.id, data); addToast('success', 'Room updated'); }
      else { await addRoom(data); addToast('success', 'Room added'); }
      setRoomModal(false);
    } catch { addToast('error', 'Failed to save room'); }
  };

  const openPostAdd = () => {
    setEditingPost(null);
    setPostForm({ title: '', content: '', roomId: rooms[0]?.id || '', images: [] });
    setPostModal(true);
  };

  const openPostEdit = (p: Post) => {
    setEditingPost(p);
    setPostForm({ title: p.title, content: p.content, roomId: p.roomId, images: p.images });
    setPostModal(true);
  };

  const savePost = async () => {
    if (!postForm.title || !postForm.roomId) { addToast('error', 'Title and room are required'); return; }
    try {
      if (editingPost) { await updatePost(editingPost.id, { title: postForm.title, content: postForm.content, roomId: postForm.roomId, images: postForm.images }); addToast('success', 'Post updated'); }
      else { await addPost({ title: postForm.title, content: postForm.content, roomId: postForm.roomId, images: postForm.images.length > 0 ? postForm.images : ['https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=800&q=80'] }); addToast('success', 'Post added'); }
      setPostModal(false);
    } catch { addToast('error', 'Failed to save post'); }
  };

  const addImageUrl = () => { const url = prompt('Enter image URL:'); if (url) setPostForm({ ...postForm, images: [...postForm.images, url] }); };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Rooms Panel */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-display text-lg font-semibold text-white">Rooms</h3>
          <button onClick={openRoomAdd} className="flex items-center gap-1 px-3 py-1.5 bg-gold text-[#0A0A0A] rounded-lg text-sm font-semibold hover:bg-gold-light transition-colors"><Plus className="w-3 h-3" /> Add</button>
        </div>
        <div className="bg-[#141414] border border-white/8 rounded-xl overflow-hidden">
          <div className="divide-y divide-white/5">
            {rooms.map(r => {
              const IconComp = iconOptions.find(i => i.name === r.icon)?.icon || BookOpen;
              return (
                <div key={r.id} className="flex items-center gap-3 px-4 py-3 hover:bg-[#1E1E1E] transition-colors">
                  <GripVertical className="w-4 h-4 text-white/20" />
                  <IconComp className="w-4 h-4 text-gold" />
                  <span className="text-white text-sm flex-1">{r.name}</span>
                  <button onClick={() => updateRoom(r.id, { isActive: !r.isActive })} className={`px-2 py-1 rounded text-xs ${r.isActive ? 'bg-green-500/20 text-green-500' : 'bg-white/10 text-white/40'}`}>{r.isActive ? 'Active' : 'Inactive'}</button>
                  <button onClick={() => openRoomEdit(r)} className="p-1.5 text-white/40 hover:text-gold"><Pencil className="w-3.5 h-3.5" /></button>
                  <button onClick={() => { if (confirm('Delete this room?')) deleteRoom(r.id).then(() => addToast('success', 'Room deleted')).catch(() => addToast('error', 'Failed')); }} className="p-1.5 text-white/40 hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Posts Panel */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-3">
            <h3 className="font-display text-lg font-semibold text-white">Posts</h3>
            <select value={selectedRoom} onChange={e => setSelectedRoom(e.target.value)} className="bg-[#1A1A1A] border border-white/10 rounded-lg px-3 py-1.5 text-white text-sm focus:border-gold focus:outline-none">
              <option value="all">All Rooms</option>
              {rooms.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
            </select>
          </div>
          <button onClick={openPostAdd} className="flex items-center gap-1 px-3 py-1.5 bg-gold text-[#0A0A0A] rounded-lg text-sm font-semibold hover:bg-gold-light transition-colors"><Plus className="w-3 h-3" /> Add</button>
        </div>
        <div className="bg-[#141414] border border-white/8 rounded-xl overflow-hidden">
          <div className="divide-y divide-white/5">
            {posts.map(p => (
              <div key={p.id} className="flex items-center gap-3 px-4 py-3 hover:bg-[#1E1E1E] transition-colors">
                <span className="text-white text-sm flex-1 truncate">{p.title}</span>
                <span className="text-white/30 text-xs">{rooms.find(r => r.id === p.roomId)?.name || 'General'}</span>
                <button onClick={() => openPostEdit(p)} className="p-1.5 text-white/40 hover:text-gold"><Pencil className="w-3.5 h-3.5" /></button>
                <button onClick={() => { if (confirm('Delete this post?')) deletePost(p.id).then(() => addToast('success', 'Post deleted')).catch(() => addToast('error', 'Failed')); }} className="p-1.5 text-white/40 hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            ))}
            {posts.length === 0 && <p className="text-center text-white/30 py-8 text-sm">No posts found</p>}
          </div>
        </div>
      </div>

      {/* Room Modal */}
      <AnimatePresence>
        {roomModal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setRoomModal(false)}>
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }} onClick={e => e.stopPropagation()} className="bg-[#141414] border border-white/8 rounded-xl p-6 max-w-md w-full">
              <div className="flex justify-between items-center mb-6"><h3 className="font-display text-xl font-semibold text-white">{editingRoom ? 'Edit Room' : 'Add Room'}</h3><button onClick={() => setRoomModal(false)} className="text-white/40 hover:text-white"><X className="w-5 h-5" /></button></div>
              <div className="space-y-4">
                <div><label className="text-white/60 text-sm mb-1 block">Name *</label><input type="text" value={roomForm.name} onChange={e => setRoomForm({ ...roomForm, name: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" /></div>
                <div><label className="text-white/60 text-sm mb-1 block">Slug</label><input type="text" value={roomForm.slug} onChange={e => setRoomForm({ ...roomForm, slug: e.target.value })} placeholder="auto-generated" className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" /></div>
                <div><label className="text-white/60 text-sm mb-1 block">Description</label><textarea value={roomForm.description} onChange={e => setRoomForm({ ...roomForm, description: e.target.value })} rows={2} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none resize-none" /></div>
                <div><label className="text-white/60 text-sm mb-2 block">Icon</label><div className="flex gap-2">{iconOptions.map(i => { const Icon = i.icon; return (<button key={i.name} onClick={() => setRoomForm({ ...roomForm, icon: i.name })} className={`w-10 h-10 rounded-lg flex items-center justify-center transition-all ${roomForm.icon === i.name ? 'bg-gold/20 border border-gold text-gold' : 'bg-[#1A1A1A] border border-white/10 text-white/40'}`}><Icon className="w-5 h-5" /></button>); })}</div></div>
                <div className="grid grid-cols-2 gap-4">
                  <div><label className="text-white/60 text-sm mb-1 block">Order</label><input type="number" value={roomForm.order} onChange={e => setRoomForm({ ...roomForm, order: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" /></div>
                  <div><label className="text-white/60 text-sm mb-1 block">Active</label><button onClick={() => setRoomForm({ ...roomForm, isActive: !roomForm.isActive })} className={`w-full py-3 rounded-lg text-sm font-medium transition-all ${roomForm.isActive ? 'bg-green-500/20 text-green-500' : 'bg-white/10 text-white/40'}`}>{roomForm.isActive ? 'Active' : 'Inactive'}</button></div>
                </div>
                <div className="flex gap-3 pt-2"><button onClick={() => setRoomModal(false)} className="flex-1 py-3 border border-white/20 text-white rounded-lg hover:bg-white/5">Cancel</button><button onClick={saveRoom} className="flex-1 py-3 bg-gold text-[#0A0A0A] rounded-lg font-semibold hover:bg-gold-light">Save Room</button></div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Post Modal */}
      <AnimatePresence>
        {postModal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setPostModal(false)}>
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }} onClick={e => e.stopPropagation()} className="bg-[#141414] border border-white/8 rounded-xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto">
              <div className="flex justify-between items-center mb-6"><h3 className="font-display text-xl font-semibold text-white">{editingPost ? 'Edit Post' : 'Add Post'}</h3><button onClick={() => setPostModal(false)} className="text-white/40 hover:text-white"><X className="w-5 h-5" /></button></div>
              <div className="space-y-4">
                <div><label className="text-white/60 text-sm mb-1 block">Title *</label><input type="text" value={postForm.title} onChange={e => setPostForm({ ...postForm, title: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" /></div>
                <div><label className="text-white/60 text-sm mb-1 block">Room *</label><select value={postForm.roomId} onChange={e => setPostForm({ ...postForm, roomId: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none">{rooms.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}</select></div>
                <div><label className="text-white/60 text-sm mb-1 block">Content</label><textarea value={postForm.content} onChange={e => setPostForm({ ...postForm, content: e.target.value })} rows={6} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none resize-none" /></div>
                <div><label className="text-white/60 text-sm mb-2 block">Images</label><div className="flex flex-wrap gap-2 mb-2">{postForm.images.map((img, i) => (<img key={i} src={img} alt="" className="w-16 h-16 rounded object-cover" />))}<button onClick={addImageUrl} className="w-16 h-16 rounded border-2 border-dashed border-white/20 flex items-center justify-center text-white/40 hover:border-gold/50"><Plus className="w-5 h-5" /></button></div></div>
                <div className="flex gap-3 pt-2"><button onClick={() => setPostModal(false)} className="flex-1 py-3 border border-white/20 text-white rounded-lg hover:bg-white/5">Cancel</button><button onClick={savePost} className="flex-1 py-3 bg-gold text-[#0A0A0A] rounded-lg font-semibold hover:bg-gold-light">Save Post</button></div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
