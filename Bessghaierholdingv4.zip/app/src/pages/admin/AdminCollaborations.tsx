import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, XCircle, DollarSign, MessageCircle, Send, X, Phone } from 'lucide-react';
import { subscribeCollaborations, updateCollaboration } from '@/lib/firebaseServices';
import { useToast } from '@/contexts/ToastContext';
import StatusBadge from '@/components/shared/StatusBadge';
import type { Collaboration } from '@/types';

export default function AdminCollaborations() {
  const [collabs, setCollabs] = useState<Collaboration[]>([]);
  const [statusFilter, setStatusFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [selectedCollab, setSelectedCollab] = useState<Collaboration | null>(null);
  const [price, setPrice] = useState('');
  const [note, setNote] = useState('');
  const [messageText, setMessageText] = useState('');
  const [rejectReason, setRejectReason] = useState('');
  const [showReject, setShowReject] = useState(false);
  const { addToast } = useToast();

  useEffect(() => {
    const unsub = subscribeCollaborations(setCollabs);
    return () => unsub();
  }, []);

  const filtered = collabs.filter(c => {
    const matchesStatus = statusFilter === 'all' || c.status === statusFilter;
    const matchesSearch = !search || c.name.toLowerCase().includes(search.toLowerCase()) || c.email.toLowerCase().includes(search.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const handleSetPrice = async () => {
    if (!selectedCollab || !price) { addToast('error', 'Enter a price'); return; }
    try {
      await updateCollaboration(selectedCollab.id, { price: Number(price), status: 'price_set', adminNotes: note, messages: [...selectedCollab.messages, { sender: 'admin', text: `Collaboration price set to $${price}. ${note}`, timestamp: new Date().toISOString() }] });
      addToast('success', 'Price set and notification sent');
      setPrice(''); setNote('');
      setSelectedCollab(null);
    } catch { addToast('error', 'Failed to set price'); }
  };

  const handleApprove = async () => {
    if (!selectedCollab) return;
    try {
      await updateCollaboration(selectedCollab.id, { status: 'approved', messages: [...selectedCollab.messages, { sender: 'admin', text: 'Your collaboration has been approved!', timestamp: new Date().toISOString() }] });
      addToast('success', 'Collaboration approved');
      setSelectedCollab(null);
    } catch { addToast('error', 'Failed to approve'); }
  };

  const handleReject = async () => {
    if (!selectedCollab) return;
    try {
      await updateCollaboration(selectedCollab.id, { status: 'rejected', adminNotes: rejectReason, messages: [...selectedCollab.messages, { sender: 'admin', text: `Collaboration rejected. Reason: ${rejectReason}`, timestamp: new Date().toISOString() }] });
      addToast('success', 'Collaboration rejected');
      setShowReject(false); setRejectReason('');
      setSelectedCollab(null);
    } catch { addToast('error', 'Failed to reject'); }
  };

  const handleSendMessage = async () => {
    if (!selectedCollab || !messageText.trim()) return;
    try {
      await updateCollaboration(selectedCollab.id, { messages: [...selectedCollab.messages, { sender: 'admin', text: messageText, timestamp: new Date().toISOString() }] });
      setMessageText('');
      addToast('success', 'Message sent');
    } catch { addToast('error', 'Failed to send message'); }
  };

  const handleMarkComplete = async () => {
    if (!selectedCollab) return;
    try {
      await updateCollaboration(selectedCollab.id, { status: 'completed', messages: [...selectedCollab.messages, { sender: 'admin', text: 'Collaboration completed! Thank you.', timestamp: new Date().toISOString() }] });
      addToast('success', 'Marked as completed');
      setSelectedCollab(null);
    } catch { addToast('error', 'Failed'); }
  };

  const statusFlow = ['applied', 'rules_signed', 'price_set', 'approved', 'completed'];

  const tabs = ['all', 'applied', 'rules_signed', 'price_set', 'approved', 'completed', 'rejected'];

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div className="flex flex-wrap gap-2">
          {tabs.map(tab => (
            <button key={tab} onClick={() => setStatusFilter(tab)} className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${statusFilter === tab ? 'bg-gold text-[#0A0A0A]' : 'bg-[#141414] text-white/60 border border-white/10 hover:border-gold/30'}`}>
              {tab === 'all' ? 'All' : tab === 'rules_signed' ? 'Rules Signed' : tab === 'price_set' ? 'Price Set' : tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>
        <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search..." className="bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:border-gold focus:outline-none w-56" />
      </div>

      <div className="bg-[#141414] border border-white/8 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="bg-[#1A1A1A]">{['Name', 'Email', 'WhatsApp', 'Status', 'Date', 'Actions'].map(h => <th key={h} className="text-left px-6 py-3 text-xs font-medium text-white/40 uppercase tracking-wider">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-white/5">
              {filtered.length === 0 ? <tr><td colSpan={6} className="text-center text-white/30 py-12">No collaborations found</td></tr> :
                filtered.map(c => (
                  <tr key={c.id} className="hover:bg-[#1E1E1E] transition-colors">
                    <td className="px-6 py-4 text-white text-sm font-medium">{c.name}</td>
                    <td className="px-6 py-4 text-white/50 text-sm">{c.email}</td>
                    <td className="px-6 py-4 text-white/50 text-sm">{c.whatsapp}</td>
                    <td className="px-6 py-4"><StatusBadge status={c.status} /></td>
                    <td className="px-6 py-4 text-white/40 text-sm">{new Date(c.createdAt).toLocaleDateString()}</td>
                    <td className="px-6 py-4"><button onClick={() => setSelectedCollab(c)} className="px-3 py-1.5 bg-gold/15 text-gold rounded-lg text-sm hover:bg-gold/25 transition-colors">View</button></td>
                  </tr>
                ))
              }
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail View */}
      <AnimatePresence>
        {selectedCollab && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setSelectedCollab(null)}>
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }} onClick={e => e.stopPropagation()} className="bg-[#141414] border border-white/8 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b border-white/8 flex justify-between items-center">
                <div><h3 className="font-display text-xl font-semibold text-white">{selectedCollab.name}</h3><p className="text-white/40 text-sm">{selectedCollab.email}</p></div>
                <button onClick={() => setSelectedCollab(null)} className="text-white/40 hover:text-white"><X className="w-5 h-5" /></button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 p-6">
                {/* Left: Info & Timeline */}
                <div className="lg:col-span-2 space-y-6">
                  {/* Info */}
                  <div className="bg-[#1A1A1A] rounded-lg p-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div><p className="text-white/40">Phone</p><p className="text-white">{selectedCollab.phone}</p></div>
                      <div><p className="text-white/40">WhatsApp</p><a href={`https://wa.me/${selectedCollab.whatsapp}`} target="_blank" rel="noopener noreferrer" className="text-gold hover:underline flex items-center gap-1"><Phone className="w-3 h-3" />{selectedCollab.whatsapp}</a></div>
                      <div><p className="text-white/40">Status</p><StatusBadge status={selectedCollab.status} /></div>
                      <div><p className="text-white/40">Price</p><p className="text-gold font-bold">${selectedCollab.price || 'Not set'}</p></div>
                    </div>
                  </div>

                  {/* Timeline */}
                  <div className="flex items-center gap-2">
                    {statusFlow.map((s, i) => {
                      const currentIdx = statusFlow.indexOf(selectedCollab.status);
                      const isCompleted = i <= currentIdx;
                      const isCurrent = i === currentIdx;
                      return (
                        <div key={s} className="flex items-center gap-2 flex-1">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${isCompleted ? 'bg-gold text-[#0A0A0A]' : 'bg-[#1A1A1A] text-white/30 border border-white/10'} ${isCurrent ? 'animate-pulse-gold' : ''}`}>{i + 1}</div>
                          {i < statusFlow.length - 1 && <div className={`flex-1 h-px ${i < currentIdx ? 'bg-gold' : 'bg-white/10'}`} />}
                        </div>
                      );
                    })}
                  </div>

                  {/* Messaging */}
                  <div className="bg-[#1A1A1A] rounded-lg p-4">
                    <h4 className="text-white font-medium mb-3 flex items-center gap-2"><MessageCircle className="w-4 h-4 text-gold" /> Messages</h4>
                    <div className="space-y-3 max-h-48 overflow-y-auto mb-4">
                      {selectedCollab.messages.length === 0 ? <p className="text-white/30 text-sm text-center py-4">No messages yet</p> :
                        selectedCollab.messages.map((m, i) => (
                          <div key={i} className={`flex ${m.sender === 'admin' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-[80%] px-4 py-2 rounded-xl text-sm ${m.sender === 'admin' ? 'bg-gold text-[#0A0A0A]' : 'bg-[#0A0A0A] text-white border border-white/10'}`}>
                              <p>{m.text}</p>
                              <p className={`text-[10px] mt-1 ${m.sender === 'admin' ? 'text-[#0A0A0A]/60' : 'text-white/30'}`}>{new Date(m.timestamp).toLocaleString()}</p>
                            </div>
                          </div>
                        ))
                      }
                    </div>
                    <div className="flex gap-2">
                      <input type="text" value={messageText} onChange={e => setMessageText(e.target.value)} placeholder="Type a message..." onKeyPress={e => e.key === 'Enter' && handleSendMessage()} className="flex-1 bg-[#0A0A0A] border border-white/10 rounded-lg px-4 py-2 text-white text-sm focus:border-gold focus:outline-none" />
                      <button onClick={handleSendMessage} className="px-4 py-2 bg-gold text-[#0A0A0A] rounded-lg hover:bg-gold-light transition-colors"><Send className="w-4 h-4" /></button>
                    </div>
                  </div>
                </div>

                {/* Right: Actions */}
                <div className="space-y-4">
                  {/* Set Price */}
                  {(selectedCollab.status === 'applied' || selectedCollab.status === 'rules_signed') && (
                    <div className="bg-[#1A1A1A] rounded-lg p-4">
                      <h4 className="text-white font-medium mb-3 flex items-center gap-2"><DollarSign className="w-4 h-4 text-gold" /> Set Price</h4>
                      <input type="number" value={price} onChange={e => setPrice(e.target.value)} placeholder="Enter price" className="w-full bg-[#0A0A0A] border border-white/10 rounded-lg px-4 py-2 text-white text-sm focus:border-gold focus:outline-none mb-3" />
                      <textarea value={note} onChange={e => setNote(e.target.value)} placeholder="Additional notes..." rows={2} className="w-full bg-[#0A0A0A] border border-white/10 rounded-lg px-4 py-2 text-white text-sm focus:border-gold focus:outline-none resize-none mb-3" />
                      <button onClick={handleSetPrice} className="w-full py-2.5 bg-gold text-[#0A0A0A] rounded-lg font-semibold text-sm hover:bg-gold-light transition-colors">Set Price & Send</button>
                    </div>
                  )}

                  {/* Approve/Reject */}
                  {selectedCollab.status === 'price_set' && (
                    <div className="bg-[#1A1A1A] rounded-lg p-4">
                      <p className="text-gold font-bold text-lg mb-1">${selectedCollab.price}</p>
                      <p className="text-white/40 text-sm mb-4">Price has been set</p>
                      <div className="space-y-2">
                        <button onClick={handleApprove} className="w-full py-2.5 bg-green-500 text-white rounded-lg font-semibold text-sm hover:bg-green-600 flex items-center justify-center gap-2"><CheckCircle className="w-4 h-4" /> Approve</button>
                        <button onClick={() => setShowReject(true)} className="w-full py-2.5 bg-red-500 text-white rounded-lg font-semibold text-sm hover:bg-red-600 flex items-center justify-center gap-2"><XCircle className="w-4 h-4" /> Reject</button>
                      </div>
                    </div>
                  )}

                  {selectedCollab.status === 'approved' && (
                    <div className="bg-[#1A1A1A] rounded-lg p-4 text-center">
                      <p className="text-green-500 font-medium mb-3">Approved</p>
                      <button onClick={handleMarkComplete} className="w-full py-2.5 bg-gold text-[#0A0A0A] rounded-lg font-semibold text-sm hover:bg-gold-light">Mark as Completed</button>
                    </div>
                  )}

                  {showReject && (
                    <div className="bg-[#1A1A1A] rounded-lg p-4">
                      <textarea value={rejectReason} onChange={e => setRejectReason(e.target.value)} placeholder="Reason for rejection..." rows={3} className="w-full bg-[#0A0A0A] border border-white/10 rounded-lg px-4 py-2 text-white text-sm focus:border-gold focus:outline-none resize-none mb-3" />
                      <div className="flex gap-2"><button onClick={() => setShowReject(false)} className="flex-1 py-2 border border-white/20 text-white rounded-lg text-sm">Cancel</button><button onClick={handleReject} className="flex-1 py-2 bg-red-500 text-white rounded-lg text-sm font-semibold">Confirm Reject</button></div>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
