import { useState, useEffect } from 'react';
import { Trash2, CheckCircle } from 'lucide-react';
import { subscribeReviews, updateReview, deleteReview } from '@/lib/firebaseServices';
import { useToast } from '@/contexts/ToastContext';
import StarRating from '@/components/shared/StarRating';
import type { Review } from '@/types';

export default function AdminReviews() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [statusFilter, setStatusFilter] = useState('all');
  const [search, setSearch] = useState('');
  const { addToast } = useToast();

  useEffect(() => {
    const unsub = subscribeReviews(setReviews);
    return () => unsub();
  }, []);

  const filtered = reviews.filter(r => {
    const matchesStatus = statusFilter === 'all' || (statusFilter === 'pending' ? !r.isApproved : r.isApproved);
    const matchesSearch = !search || r.name.toLowerCase().includes(search.toLowerCase()) || r.comment.toLowerCase().includes(search.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const handleApprove = async (id: string) => {
    try { await updateReview(id, { isApproved: true }); addToast('success', 'Review approved'); }
    catch { addToast('error', 'Failed'); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this review?')) return;
    try { await deleteReview(id); addToast('success', 'Review deleted'); }
    catch { addToast('error', 'Failed'); }
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div className="flex flex-wrap gap-2">
          {['all', 'pending', 'approved'].map(tab => (
            <button key={tab} onClick={() => setStatusFilter(tab)} className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${statusFilter === tab ? 'bg-gold text-[#0A0A0A]' : 'bg-[#141414] text-white/60 border border-white/10 hover:border-gold/30'}`}>
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>
        <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search reviews..." className="bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:border-gold focus:outline-none w-56" />
      </div>

      <div className="bg-[#141414] border border-white/8 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="bg-[#1A1A1A]">{['Name', 'Type', 'Rating', 'Comment', 'Date', 'Actions'].map(h => <th key={h} className="text-left px-6 py-3 text-xs font-medium text-white/40 uppercase tracking-wider">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-white/5">
              {filtered.length === 0 ? <tr><td colSpan={6} className="text-center text-white/30 py-12">No reviews found</td></tr> :
                filtered.map(r => (
                  <tr key={r.id} className="hover:bg-[#1E1E1E] transition-colors">
                    <td className="px-6 py-4 text-white text-sm font-medium">{r.name}</td>
                    <td className="px-6 py-4"><span className="px-2 py-1 bg-white/10 rounded-full text-xs text-white/60 capitalize">{r.type}</span></td>
                    <td className="px-6 py-4"><StarRating rating={r.rating} size={14} /></td>
                    <td className="px-6 py-4 text-white/50 text-sm max-w-xs truncate">{r.comment}</td>
                    <td className="px-6 py-4 text-white/40 text-sm">{new Date(r.createdAt).toLocaleDateString()}</td>
                    <td className="px-6 py-4">
                      <div className="flex gap-1">
                        {!r.isApproved && <button onClick={() => handleApprove(r.id)} className="p-2 text-white/40 hover:text-green-500 transition-colors" title="Approve"><CheckCircle className="w-4 h-4" /></button>}
                        <button onClick={() => handleDelete(r.id)} className="p-2 text-white/40 hover:text-red-500 transition-colors" title="Delete"><Trash2 className="w-4 h-4" /></button>
                      </div>
                    </td>
                  </tr>
                ))
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
