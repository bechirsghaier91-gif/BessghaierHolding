import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Pencil, Trash2, X, ExternalLink } from 'lucide-react';
import { subscribeBooks, addBook, updateBook, deleteBook } from '@/lib/firebaseServices';
import { useToast } from '@/contexts/ToastContext';
import type { Book } from '@/types';

export default function AdminBooks() {
  const [books, setBooks] = useState<Book[]>([]);
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Book | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [form, setForm] = useState({ title: '', author: '', description: '', price: '', currency: 'USD', image: '', kindleLink: '' });
  const { addToast } = useToast();

  useEffect(() => {
    const unsub = subscribeBooks(setBooks);
    return () => unsub();
  }, []);

  const filtered = books.filter(b => !search || b.title.toLowerCase().includes(search.toLowerCase()) || b.author.toLowerCase().includes(search.toLowerCase()));

  const openAdd = () => {
    setEditing(null);
    setForm({ title: '', author: '', description: '', price: '', currency: 'USD', image: '', kindleLink: '' });
    setModalOpen(true);
  };

  const openEdit = (b: Book) => {
    setEditing(b);
    setForm({ title: b.title, author: b.author, description: b.description, price: b.price.toString(), currency: b.currency, image: b.image, kindleLink: b.kindleLink });
    setModalOpen(true);
  };

  const handleSave = async () => {
    if (!form.title || !form.author || !form.price || !form.kindleLink) {
      addToast('error', 'Please fill in all required fields');
      return;
    }
    const data = { title: form.title, author: form.author, description: form.description, price: Number(form.price), currency: form.currency, image: form.image || 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&q=80', kindleLink: form.kindleLink };
    try {
      if (editing) { await updateBook(editing.id, data); addToast('success', 'Book updated'); }
      else { await addBook(data); addToast('success', 'Book added'); }
      setModalOpen(false);
    } catch { addToast('error', 'Failed to save book'); }
  };

  const handleDelete = async (id: string) => {
    try { await deleteBook(id); addToast('success', 'Book deleted'); setConfirmDelete(null); }
    catch { addToast('error', 'Failed to delete book'); }
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by title or author" className="bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:border-gold focus:outline-none w-64" />
        <button onClick={openAdd} className="flex items-center gap-2 px-5 py-2.5 bg-gold text-[#0A0A0A] rounded-lg font-semibold text-sm hover:bg-gold-light transition-colors">
          <Plus className="w-4 h-4" /> Add Book
        </button>
      </div>

      <div className="bg-[#141414] border border-white/8 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="bg-[#1A1A1A]">{['Cover', 'Title', 'Author', 'Price', 'Kindle', 'Actions'].map(h => <th key={h} className="text-left px-6 py-3 text-xs font-medium text-white/40 uppercase tracking-wider">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-white/5">
              {filtered.length === 0 ? <tr><td colSpan={6} className="text-center text-white/30 py-12">No books found</td></tr> :
                filtered.map(b => (
                  <tr key={b.id} className="hover:bg-[#1E1E1E] transition-colors">
                    <td className="px-6 py-4"><img src={b.image} alt="" className="w-10 h-14 rounded object-cover" /></td>
                    <td className="px-6 py-4 text-white text-sm font-medium">{b.title}</td>
                    <td className="px-6 py-4 text-white/50 text-sm">{b.author}</td>
                    <td className="px-6 py-4 text-gold font-semibold text-sm">${b.price} {b.currency}</td>
                    <td className="px-6 py-4"><a href={b.kindleLink} target="_blank" rel="noopener noreferrer" className="text-gold text-sm hover:underline flex items-center gap-1"><ExternalLink className="w-3 h-3" /> View</a></td>
                    <td className="px-6 py-4"><div className="flex gap-2"><button onClick={() => openEdit(b)} className="p-2 text-white/40 hover:text-gold transition-colors"><Pencil className="w-4 h-4" /></button><button onClick={() => setConfirmDelete(b.id)} className="p-2 text-white/40 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button></div></td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>

      <AnimatePresence>
        {modalOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setModalOpen(false)}>
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }} onClick={e => e.stopPropagation()} className="bg-[#141414] border border-white/8 rounded-xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto">
              <div className="flex justify-between items-center mb-6"><h3 className="font-display text-xl font-semibold text-white">{editing ? 'Edit Book' : 'Add Book'}</h3><button onClick={() => setModalOpen(false)} className="text-white/40 hover:text-white"><X className="w-5 h-5" /></button></div>
              <div className="space-y-4">
                <div><label className="text-white/60 text-sm mb-1 block">Cover Image URL</label><input type="text" value={form.image} onChange={e => setForm({ ...form, image: e.target.value })} placeholder="https://..." className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" /></div>
                <div><label className="text-white/60 text-sm mb-1 block">Title *</label><input type="text" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" /></div>
                <div><label className="text-white/60 text-sm mb-1 block">Author *</label><input type="text" value={form.author} onChange={e => setForm({ ...form, author: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" /></div>
                <div><label className="text-white/60 text-sm mb-1 block">Description</label><textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} rows={3} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none resize-none" /></div>
                <div className="grid grid-cols-2 gap-4">
                  <div><label className="text-white/60 text-sm mb-1 block">Price *</label><input type="number" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" /></div>
                  <div><label className="text-white/60 text-sm mb-1 block">Currency</label><select value={form.currency} onChange={e => setForm({ ...form, currency: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none"><option value="USD">USD</option><option value="EUR">EUR</option><option value="TND">TND</option></select></div>
                </div>
                <div><label className="text-white/60 text-sm mb-1 block">Kindle Link *</label><input type="url" value={form.kindleLink} onChange={e => setForm({ ...form, kindleLink: e.target.value })} placeholder="https://amazon.com/..." className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" /></div>
                <div className="flex gap-3 pt-2"><button onClick={() => setModalOpen(false)} className="flex-1 py-3 border border-white/20 text-white rounded-lg hover:bg-white/5">Cancel</button><button onClick={handleSave} className="flex-1 py-3 bg-gold text-[#0A0A0A] rounded-lg font-semibold hover:bg-gold-light">Save Book</button></div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {confirmDelete && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setConfirmDelete(null)}>
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }} onClick={e => e.stopPropagation()} className="bg-[#141414] border border-white/8 rounded-xl p-6 max-w-sm w-full text-center">
              <div className="w-12 h-12 rounded-full bg-red-500/15 flex items-center justify-center mx-auto mb-4"><Trash2 className="w-6 h-6 text-red-500" /></div>
              <h3 className="font-display text-lg font-semibold text-white mb-2">Confirm Delete</h3>
              <p className="text-white/50 text-sm mb-6">Are you sure you want to delete this book?</p>
              <div className="flex gap-3"><button onClick={() => setConfirmDelete(null)} className="flex-1 py-2.5 border border-white/20 text-white rounded-lg text-sm hover:bg-white/5">Cancel</button><button onClick={() => handleDelete(confirmDelete)} className="flex-1 py-2.5 bg-red-500 text-white rounded-lg text-sm font-semibold hover:bg-red-600">Delete</button></div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
