import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Eye, CheckCircle, XCircle, X, Calendar, Phone, Mail, MessageSquare } from 'lucide-react';
import { subscribeBookings, updateBooking } from '@/lib/firebaseServices';
import { useToast } from '@/contexts/ToastContext';
import StatusBadge from '@/components/shared/StatusBadge';
import type { Booking } from '@/types';

export default function AdminBookings() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [statusFilter, setStatusFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [detailBooking, setDetailBooking] = useState<Booking | null>(null);
  const [rejectModal, setRejectModal] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const { addToast } = useToast();

  useEffect(() => {
    const unsub = subscribeBookings(setBookings);
    return () => unsub();
  }, []);

  const filtered = bookings.filter(b => {
    const matchesStatus = statusFilter === 'all' || b.status === statusFilter;
    const matchesSearch = !search || b.name.toLowerCase().includes(search.toLowerCase()) || b.propertyTitle.toLowerCase().includes(search.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const handleApprove = async (id: string) => {
    try { await updateBooking(id, { status: 'approved' }); addToast('success', 'Booking approved'); }
    catch { addToast('error', 'Failed to approve'); }
  };

  const handleReject = async (id: string) => {
    try { await updateBooking(id, { status: 'rejected' }); addToast('success', 'Booking rejected'); setRejectModal(null); setRejectReason(''); }
    catch { addToast('error', 'Failed to reject'); }
  };

  const tabs = ['all', 'pending', 'approved', 'rejected'];

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div className="flex flex-wrap gap-2">
          {tabs.map(tab => (
            <button key={tab} onClick={() => setStatusFilter(tab)} className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${statusFilter === tab ? 'bg-gold text-[#0A0A0A]' : 'bg-[#141414] text-white/60 border border-white/10 hover:border-gold/30'}`}>
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
              {tab === 'pending' && <span className="ml-1.5 bg-yellow-500 text-[#0A0A0A] text-[10px] font-bold px-1.5 py-0.5 rounded-full">{bookings.filter(b => b.status === 'pending').length}</span>}
            </button>
          ))}
        </div>
        <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search bookings..." className="bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:border-gold focus:outline-none w-56" />
      </div>

      <div className="bg-[#141414] border border-white/8 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="bg-[#1A1A1A]">{['Property', 'Guest', 'Phone', 'Check-in', 'Check-out', 'Status', 'Actions'].map(h => <th key={h} className="text-left px-6 py-3 text-xs font-medium text-white/40 uppercase tracking-wider">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-white/5">
              {filtered.length === 0 ? (
                <tr><td colSpan={7} className="text-center text-white/30 py-12">No bookings found</td></tr>
              ) : (
                filtered.map(b => (
                  <tr key={b.id} className="hover:bg-[#1E1E1E] transition-colors">
                    <td className="px-6 py-4 text-white text-sm">{b.propertyTitle}</td>
                    <td className="px-6 py-4 text-white text-sm font-medium">{b.name}</td>
                    <td className="px-6 py-4 text-white/50 text-sm">{b.phone}</td>
                    <td className="px-6 py-4 text-white/50 text-sm">{b.checkIn}</td>
                    <td className="px-6 py-4 text-white/50 text-sm">{b.checkOut}</td>
                    <td className="px-6 py-4"><StatusBadge status={b.status} /></td>
                    <td className="px-6 py-4">
                      <div className="flex gap-1">
                        <button onClick={() => setDetailBooking(b)} className="p-2 text-white/40 hover:text-gold transition-colors" title="View"><Eye className="w-4 h-4" /></button>
                        {b.status === 'pending' && (
                          <>
                            <button onClick={() => handleApprove(b.id)} className="p-2 text-white/40 hover:text-green-500 transition-colors" title="Approve"><CheckCircle className="w-4 h-4" /></button>
                            <button onClick={() => setRejectModal(b.id)} className="p-2 text-white/40 hover:text-red-500 transition-colors" title="Reject"><XCircle className="w-4 h-4" /></button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal */}
      <AnimatePresence>
        {detailBooking && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setDetailBooking(null)}>
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }} onClick={e => e.stopPropagation()} className="bg-[#141414] border border-white/8 rounded-xl p-6 max-w-md w-full">
              <div className="flex justify-between items-center mb-6"><h3 className="font-display text-xl font-semibold text-white">Booking Details</h3><button onClick={() => setDetailBooking(null)} className="text-white/40 hover:text-white"><X className="w-5 h-5" /></button></div>
              <div className="space-y-4">
                <div className="bg-gold/10 border border-gold/20 rounded-lg p-4">
                  <p className="text-gold font-medium">{detailBooking.propertyTitle}</p>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div><p className="text-white/40 mb-1">Guest Name</p><p className="text-white">{detailBooking.name}</p></div>
                  <div><p className="text-white/40 mb-1">Phone</p><p className="text-white flex items-center gap-1"><Phone className="w-3 h-3 text-gold" />{detailBooking.phone}</p></div>
                  <div><p className="text-white/40 mb-1">Email</p><p className="text-white flex items-center gap-1"><Mail className="w-3 h-3 text-gold" />{detailBooking.email || 'N/A'}</p></div>
                  <div><p className="text-white/40 mb-1">Status</p><StatusBadge status={detailBooking.status} /></div>
                  <div><p className="text-white/40 mb-1">Check-in</p><p className="text-white flex items-center gap-1"><Calendar className="w-3 h-3 text-gold" />{detailBooking.checkIn}</p></div>
                  <div><p className="text-white/40 mb-1">Check-out</p><p className="text-white flex items-center gap-1"><Calendar className="w-3 h-3 text-gold" />{detailBooking.checkOut}</p></div>
                </div>
                {detailBooking.message && <div><p className="text-white/40 mb-1">Message</p><p className="text-white/60 text-sm bg-[#1A1A1A] rounded-lg p-3 flex items-start gap-2"><MessageSquare className="w-4 h-4 text-gold shrink-0 mt-0.5" />{detailBooking.message}</p></div>}
                {detailBooking.status === 'pending' && (
                  <div className="flex gap-3 pt-2">
                    <button onClick={() => { handleApprove(detailBooking.id); setDetailBooking(null); }} className="flex-1 py-3 bg-green-500 text-white rounded-lg font-semibold hover:bg-green-600 transition-colors flex items-center justify-center gap-2"><CheckCircle className="w-4 h-4" /> Approve</button>
                    <button onClick={() => { setDetailBooking(null); setRejectModal(detailBooking.id); }} className="flex-1 py-3 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600 transition-colors flex items-center justify-center gap-2"><XCircle className="w-4 h-4" /> Reject</button>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Reject Modal */}
      <AnimatePresence>
        {rejectModal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setRejectModal(null)}>
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }} onClick={e => e.stopPropagation()} className="bg-[#141414] border border-white/8 rounded-xl p-6 max-w-sm w-full">
              <h3 className="font-display text-lg font-semibold text-white mb-4">Reject Booking</h3>
              <textarea value={rejectReason} onChange={e => setRejectReason(e.target.value)} placeholder="Reason for rejection (optional)" rows={3} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none resize-none mb-4" />
              <div className="flex gap-3"><button onClick={() => setRejectModal(null)} className="flex-1 py-2.5 border border-white/20 text-white rounded-lg hover:bg-white/5">Cancel</button><button onClick={() => handleReject(rejectModal)} className="flex-1 py-2.5 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600">Reject</button></div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
