import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Pencil, Trash2, X, MapPin, XCircle } from 'lucide-react';
import { subscribeProperties, addProperty, updateProperty, deleteProperty } from '@/lib/firebaseServices';
import { useToast } from '@/contexts/ToastContext';
import StatusBadge from '@/components/shared/StatusBadge';
import type { Property } from '@/types';

export default function AdminProperties() {
  const [properties, setProperties] = useState<Property[]>([]);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Property | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [form, setForm] = useState({ title: '', description: '', price: '', location: '', type: 'rent' as 'rent' | 'sale', status: 'available' as 'available' | 'reserved' | 'unavailable', images: [] as string[], features: '', featureInput: '' });
  const { addToast } = useToast();

  useEffect(() => {
    const unsub = subscribeProperties(setProperties);
    return () => unsub();
  }, []);

  const filtered = properties.filter(p => {
    const matchesSearch = !search || p.title.toLowerCase().includes(search.toLowerCase()) || p.location.toLowerCase().includes(search.toLowerCase());
    const matchesType = typeFilter === 'all' || p.type === typeFilter;
    const matchesStatus = statusFilter === 'all' || p.status === statusFilter;
    return matchesSearch && matchesType && matchesStatus;
  });

  const openAdd = () => {
    setEditing(null);
    setForm({ title: '', description: '', price: '', location: '', type: 'rent', status: 'available', images: [], features: '', featureInput: '' });
    setModalOpen(true);
  };

  const openEdit = (p: Property) => {
    setEditing(p);
    setForm({ title: p.title, description: p.description, price: p.price.toString(), location: p.location, type: p.type, status: p.status, images: p.images, features: p.features.join(', '), featureInput: '' });
    setModalOpen(true);
  };

  const handleSave = async () => {
    if (!form.title || !form.price || !form.location) {
      addToast('error', 'Please fill in all required fields');
      return;
    }
    const data = {
      title: form.title,
      description: form.description,
      price: Number(form.price),
      location: form.location,
      type: form.type,
      status: form.status,
      images: form.images.length > 0 ? form.images : ['https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80'],
      features: form.features.split(',').map(f => f.trim()).filter(Boolean),
    };
    try {
      if (editing) {
        await updateProperty(editing.id, data);
        addToast('success', 'Property updated successfully');
      } else {
        await addProperty(data);
        addToast('success', 'Property added successfully');
      }
      setModalOpen(false);
    } catch {
      addToast('error', 'Failed to save property');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteProperty(id);
      addToast('success', 'Property deleted successfully');
      setConfirmDelete(null);
    } catch {
      addToast('error', 'Failed to delete property');
    }
  };

  const addImageUrl = () => {
    const url = prompt('Enter image URL:');
    if (url) setForm({ ...form, images: [...form.images, url] });
  };

  const removeImage = (idx: number) => {
    setForm({ ...form, images: form.images.filter((_, i) => i !== idx) });
  };

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div className="flex flex-wrap gap-3">
          <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by title or location" className="bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:border-gold focus:outline-none w-64" />
          <select value={typeFilter} onChange={e => setTypeFilter(e.target.value)} className="bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:border-gold focus:outline-none">
            <option value="all">All Types</option>
            <option value="rent">Rent</option>
            <option value="sale">Sale</option>
          </select>
          <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:border-gold focus:outline-none">
            <option value="all">All Status</option>
            <option value="available">Available</option>
            <option value="reserved">Reserved</option>
            <option value="unavailable">Unavailable</option>
          </select>
        </div>
        <button onClick={openAdd} className="flex items-center gap-2 px-5 py-2.5 bg-gold text-[#0A0A0A] rounded-lg font-semibold text-sm hover:bg-gold-light transition-colors">
          <Plus className="w-4 h-4" /> Add Property
        </button>
      </div>

      {/* Table */}
      <div className="bg-[#141414] border border-white/8 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[#1A1A1A]">
                <th className="text-left px-6 py-3 text-xs font-medium text-white/40 uppercase tracking-wider">Image</th>
                <th className="text-left px-6 py-3 text-xs font-medium text-white/40 uppercase tracking-wider">Title</th>
                <th className="text-left px-6 py-3 text-xs font-medium text-white/40 uppercase tracking-wider">Location</th>
                <th className="text-left px-6 py-3 text-xs font-medium text-white/40 uppercase tracking-wider">Type</th>
                <th className="text-left px-6 py-3 text-xs font-medium text-white/40 uppercase tracking-wider">Price</th>
                <th className="text-left px-6 py-3 text-xs font-medium text-white/40 uppercase tracking-wider">Status</th>
                <th className="text-left px-6 py-3 text-xs font-medium text-white/40 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filtered.length === 0 ? (
                <tr><td colSpan={7} className="text-center text-white/30 py-12">No properties found</td></tr>
              ) : (
                filtered.map(p => (
                  <tr key={p.id} className="hover:bg-[#1E1E1E] transition-colors">
                    <td className="px-6 py-4"><img src={p.images[0]} alt="" className="w-12 h-12 rounded-lg object-cover" /></td>
                    <td className="px-6 py-4 text-white text-sm font-medium">{p.title}</td>
                    <td className="px-6 py-4 text-white/50 text-sm flex items-center gap-1"><MapPin className="w-3 h-3" /> {p.location}</td>
                    <td className="px-6 py-4"><StatusBadge status={p.type} /></td>
                    <td className="px-6 py-4 text-gold font-semibold text-sm">${p.price.toLocaleString()}</td>
                    <td className="px-6 py-4"><StatusBadge status={p.status} /></td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        <button onClick={() => openEdit(p)} className="p-2 text-white/40 hover:text-gold transition-colors"><Pencil className="w-4 h-4" /></button>
                        <button onClick={() => setConfirmDelete(p.id)} className="p-2 text-white/40 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Modal */}
      <AnimatePresence>
        {modalOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setModalOpen(false)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} onClick={e => e.stopPropagation()} className="bg-[#141414] border border-white/8 rounded-xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto">
              <div className="flex justify-between items-center mb-6">
                <h3 className="font-display text-xl font-semibold text-white">{editing ? 'Edit Property' : 'Add Property'}</h3>
                <button onClick={() => setModalOpen(false)} className="text-white/40 hover:text-white"><X className="w-5 h-5" /></button>
              </div>
              <div className="space-y-4">
                {/* Images */}
                <div>
                  <label className="text-white/60 text-sm mb-2 block">Images</label>
                  <div className="flex flex-wrap gap-2 mb-2">
                    {form.images.map((img, i) => (
                      <div key={i} className="relative">
                        <img src={img} alt="" className="w-16 h-16 rounded object-cover" />
                        <button onClick={() => removeImage(i)} className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center"><XCircle className="w-3 h-3 text-white" /></button>
                      </div>
                    ))}
                    <button onClick={addImageUrl} className="w-16 h-16 rounded border-2 border-dashed border-white/20 flex items-center justify-center text-white/40 hover:border-gold/50 hover:text-gold transition-colors">
                      <Plus className="w-5 h-5" />
                    </button>
                  </div>
                </div>
                <div><label className="text-white/60 text-sm mb-1 block">Title *</label><input type="text" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" /></div>
                <div><label className="text-white/60 text-sm mb-1 block">Description</label><textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} rows={3} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none resize-none" /></div>
                <div className="grid grid-cols-2 gap-4">
                  <div><label className="text-white/60 text-sm mb-1 block">Price *</label><input type="number" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" /></div>
                  <div><label className="text-white/60 text-sm mb-1 block">Location *</label><input type="text" value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" /></div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-white/60 text-sm mb-2 block">Type</label>
                    <div className="flex gap-3">
                      {['rent', 'sale'].map(t => (
                        <button key={t} onClick={() => setForm({ ...form, type: t as 'rent' | 'sale' })} className={`px-4 py-2 rounded-lg text-sm capitalize transition-all ${form.type === t ? 'bg-gold text-[#0A0A0A]' : 'bg-[#1A1A1A] text-white/60 border border-white/10'}`}>{t}</button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-white/60 text-sm mb-2 block">Status</label>
                    <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value as 'available' | 'reserved' | 'unavailable' })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none">
                      <option value="available">Available</option>
                      <option value="reserved">Reserved</option>
                      <option value="unavailable">Unavailable</option>
                    </select>
                  </div>
                </div>
                <div><label className="text-white/60 text-sm mb-1 block">Features (comma-separated)</label><input type="text" value={form.features} onChange={e => setForm({ ...form, features: e.target.value })} placeholder="e.g. Pool, Garden, WiFi" className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" /></div>
                <div className="flex gap-3 pt-2">
                  <button onClick={() => setModalOpen(false)} className="flex-1 py-3 border border-white/20 text-white rounded-lg font-medium hover:bg-white/5 transition-colors">Cancel</button>
                  <button onClick={handleSave} className="flex-1 py-3 bg-gold text-[#0A0A0A] rounded-lg font-semibold hover:bg-gold-light transition-colors">Save Property</button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation */}
      <AnimatePresence>
        {confirmDelete && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setConfirmDelete(null)}>
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }} onClick={e => e.stopPropagation()} className="bg-[#141414] border border-white/8 rounded-xl p-6 max-w-sm w-full text-center">
              <div className="w-12 h-12 rounded-full bg-yellow-500/15 flex items-center justify-center mx-auto mb-4"><Trash2 className="w-6 h-6 text-yellow-500" /></div>
              <h3 className="font-display text-lg font-semibold text-white mb-2">Confirm Delete</h3>
              <p className="text-white/50 text-sm mb-6">Are you sure you want to delete this property? This action cannot be undone.</p>
              <div className="flex gap-3">
                <button onClick={() => setConfirmDelete(null)} className="flex-1 py-2.5 border border-white/20 text-white rounded-lg text-sm hover:bg-white/5 transition-colors">Cancel</button>
                <button onClick={() => handleDelete(confirmDelete)} className="flex-1 py-2.5 bg-red-500 text-white rounded-lg text-sm font-semibold hover:bg-red-600 transition-colors">Delete</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
