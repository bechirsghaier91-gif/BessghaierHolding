import { useState, useEffect } from 'react';
import { Trash2 } from 'lucide-react';
import { subscribeUsers, deleteUser } from '@/lib/firebaseServices';
import { useToast } from '@/contexts/ToastContext';
import StatusBadge from '@/components/shared/StatusBadge';
import type { User as UserType } from '@/types';

export default function AdminUsers() {
  const [users, setUsers] = useState<UserType[]>([]);
  const [search, setSearch] = useState('');
  const { addToast } = useToast();

  useEffect(() => {
    const unsub = subscribeUsers(setUsers);
    return () => unsub();
  }, []);

  const filtered = users.filter(u => !search || u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase()));

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this user?')) return;
    try { await deleteUser(id); addToast('success', 'User deleted'); }
    catch { addToast('error', 'Failed to delete user'); }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search users..." className="bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:border-gold focus:outline-none w-64" />
      </div>

      <div className="bg-[#141414] border border-white/8 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="bg-[#1A1A1A]">{['Name', 'Email', 'Phone', 'Role', 'Joined', 'Actions'].map(h => <th key={h} className="text-left px-6 py-3 text-xs font-medium text-white/40 uppercase tracking-wider">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-white/5">
              {filtered.length === 0 ? <tr><td colSpan={6} className="text-center text-white/30 py-12">No users found</td></tr> :
                filtered.map(u => (
                  <tr key={u.id} className="hover:bg-[#1E1E1E] transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-gold/15 flex items-center justify-center text-gold font-display font-bold text-sm">{u.name.charAt(0)}</div>
                        <span className="text-white text-sm font-medium">{u.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-white/50 text-sm">{u.email}</td>
                    <td className="px-6 py-4 text-white/50 text-sm">{u.phone || 'N/A'}</td>
                    <td className="px-6 py-4"><StatusBadge status={u.role} /></td>
                    <td className="px-6 py-4 text-white/40 text-sm">{new Date(u.createdAt).toLocaleDateString()}</td>
                    <td className="px-6 py-4"><button onClick={() => handleDelete(u.id)} className="p-2 text-white/40 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button></td>
                  </tr>
                ))
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
