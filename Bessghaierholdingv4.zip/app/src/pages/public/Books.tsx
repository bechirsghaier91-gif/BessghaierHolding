import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, BookOpen } from 'lucide-react';
import SectionHeader from '@/components/shared/SectionHeader';
import { subscribeBooks } from '@/lib/firebaseServices';
import type { Book } from '@/types';

export default function Books() {
  const [books, setBooks] = useState<Book[]>([]);

  useEffect(() => {
    const unsub = subscribeBooks(setBooks);
    return () => unsub();
  }, []);

  const displayBooks = books.length > 0 ? books : [
    { id: '1', title: 'The Art of Investment', author: 'Ahmed Bessghaier', price: 19.99, currency: 'USD', image: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&q=80', kindleLink: 'https://amazon.com/kindle', description: 'A comprehensive guide to real estate investment strategies in North Africa.' },
    { id: '2', title: 'Desert Tourism Guide', author: 'Sara Bessghaier', price: 14.99, currency: 'USD', image: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&q=80', kindleLink: 'https://amazon.com/kindle', description: 'Discover the magic of Tunisian desert tourism.' },
    { id: '3', title: 'Digital Marketing Mastery', author: 'Mohamed Bessghaier', price: 24.99, currency: 'USD', image: 'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=400&q=80', kindleLink: 'https://amazon.com/kindle', description: 'Master the art of digital marketing.' },
  ];

  return (
    <div className="min-h-screen pt-32 pb-20">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
        <SectionHeader
          eyebrow="OUR BOOKS"
          title="Bessghaier Publishing"
          subtitle="Discover our collection of published works"
        />

        {displayBooks.length === 0 ? (
          <div className="text-center py-20">
            <BookOpen className="w-16 h-16 text-white/20 mx-auto mb-4" />
            <p className="text-white/40 text-lg">No books available yet. Check back soon!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {displayBooks.map((book, i) => (
              <motion.div
                key={book.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.5 }}
                className="group bg-[#141414] border border-white/8 rounded-xl overflow-hidden hover:border-gold/30 hover:-translate-y-1 hover:shadow-elevated transition-all duration-400"
              >
                <div className="relative aspect-[3/4] overflow-hidden">
                  <img
                    src={book.image}
                    alt={book.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-transparent to-transparent" />
                </div>
                <div className="p-6">
                  <h3 className="font-display text-xl font-semibold text-white mb-1">{book.title}</h3>
                  <p className="text-white/40 text-sm mb-3">by {book.author}</p>
                  <p className="text-gold text-2xl font-bold mb-3">
                    ${book.price} <span className="text-sm text-white/40 font-normal">{book.currency}</span>
                  </p>
                  <p className="text-white/50 text-sm line-clamp-3 mb-4">{book.description}</p>
                  <a
                    href={book.kindleLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-3 bg-gold text-[#0A0A0A] rounded-full font-semibold text-sm hover:bg-gold-light transition-colors"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Buy on Kindle
                  </a>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
