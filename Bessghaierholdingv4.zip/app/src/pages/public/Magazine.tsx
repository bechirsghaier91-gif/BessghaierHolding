import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, X } from 'lucide-react';
import SectionHeader from '@/components/shared/SectionHeader';
import { subscribePosts, subscribeRooms } from '@/lib/firebaseServices';
import type { Post, Room } from '@/types';

export default function Magazine() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [selectedRoom, setSelectedRoom] = useState<string>('all');
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);

  useEffect(() => {
    const unsubPosts = subscribePosts(undefined, setPosts);
    const unsubRooms = subscribeRooms(setRooms);
    return () => { unsubPosts(); unsubRooms(); };
  }, []);

  const activeRooms = rooms.filter(r => r.isActive);
  const filteredPosts = selectedRoom === 'all' ? posts : posts.filter(p => p.roomId === selectedRoom);

  const formatDate = (date: string) => new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

  return (
    <div className="min-h-screen pt-32 pb-20">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
        <SectionHeader
          eyebrow="MAGAZINE"
          title="Bessghaier Magazine"
          subtitle="Stay updated with our latest news"
        />

        {/* Room Filters */}
        <div className="flex flex-wrap gap-2 mb-10">
          <button
            onClick={() => setSelectedRoom('all')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
              selectedRoom === 'all' ? 'bg-gold text-[#0A0A0A]' : 'bg-[#141414] text-white/60 border border-white/10 hover:border-gold/30'
            }`}
          >
            All
          </button>
          {activeRooms.map(room => (
            <button
              key={room.id}
              onClick={() => setSelectedRoom(room.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                selectedRoom === room.id ? 'bg-gold text-[#0A0A0A]' : 'bg-[#141414] text-white/60 border border-white/10 hover:border-gold/30'
              }`}
            >
              {room.name}
            </button>
          ))}
        </div>

        {/* Posts Grid */}
        {filteredPosts.length === 0 ? (
          <div className="text-center py-20 text-white/40">No articles available yet.</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((post, i) => {
              const room = rooms.find(r => r.id === post.roomId);
              return (
                <motion.article
                  key={post.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1, duration: 0.5 }}
                  className="group bg-[#141414] border border-white/8 rounded-xl overflow-hidden hover:border-gold/30 hover:-translate-y-1 hover:shadow-elevated transition-all duration-400 cursor-pointer"
                  onClick={() => setSelectedPost(post)}
                >
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={post.images[0] || 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=800&q=80'}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    {room && (
                      <div className="absolute top-4 left-4">
                        <span className="px-3 py-1 bg-gold/90 text-[#0A0A0A] rounded-full text-xs font-medium">{room.name}</span>
                      </div>
                    )}
                  </div>
                  <div className="p-6">
                    <h3 className="font-display text-lg font-semibold text-white mb-2 group-hover:text-gold transition-colors">{post.title}</h3>
                    <p className="text-white/40 text-sm line-clamp-2 mb-4">{post.content}</p>
                    <div className="flex items-center gap-2 text-white/30 text-xs">
                      <Clock className="w-3 h-3" />
                      {formatDate(post.createdAt)}
                    </div>
                  </div>
                </motion.article>
              );
            })}
          </div>
        )}
      </div>

      {/* Post Detail Modal */}
      <AnimatePresence>
        {selectedPost && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setSelectedPost(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={e => e.stopPropagation()}
              className="bg-[#141414] border border-white/8 rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto"
            >
              {selectedPost.images[0] && (
                <div className="relative h-72">
                  <img src={selectedPost.images[0]} alt={selectedPost.title} className="w-full h-full object-cover" />
                  <button onClick={() => setSelectedPost(null)} className="absolute top-4 right-4 w-8 h-8 bg-black/50 rounded-full flex items-center justify-center text-white hover:bg-black/70"><X className="w-5 h-5" /></button>
                </div>
              )}
              <div className="p-8">
                {!selectedPost.images[0] && (
                  <div className="flex justify-end mb-4">
                    <button onClick={() => setSelectedPost(null)} className="w-8 h-8 bg-black/50 rounded-full flex items-center justify-center text-white hover:bg-black/70"><X className="w-5 h-5" /></button>
                  </div>
                )}
                {rooms.find(r => r.id === selectedPost.roomId) && (
                  <span className="px-3 py-1 bg-gold/15 text-gold rounded-full text-xs font-medium mb-4 inline-block">
                    {rooms.find(r => r.id === selectedPost.roomId)?.name}
                  </span>
                )}
                <h2 className="font-display text-2xl font-semibold text-white mb-4">{selectedPost.title}</h2>
                <div className="flex items-center gap-2 text-white/30 text-sm mb-6">
                  <Clock className="w-4 h-4" />
                  {formatDate(selectedPost.createdAt)}
                </div>
                <div className="text-white/60 leading-relaxed whitespace-pre-line">{selectedPost.content}</div>
                {selectedPost.images.length > 1 && (
                  <div className="grid grid-cols-2 gap-4 mt-6">
                    {selectedPost.images.slice(1).map((img, i) => (
                      <img key={i} src={img} alt="" className="rounded-lg w-full h-48 object-cover" />
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
