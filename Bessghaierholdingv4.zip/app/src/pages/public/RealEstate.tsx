import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MapPin, Bed, Bath, Maximize, X, Send } from 'lucide-react';
import SectionHeader from '@/components/shared/SectionHeader';
import StatusBadge from '@/components/shared/StatusBadge';
import { subscribeProperties, addBooking } from '@/lib/firebaseServices';
import { useToast } from '@/contexts/ToastContext';
import type { Property } from '@/types';

export default function RealEstate() {
  const [properties, setProperties] = useState<Property[]>([]);
  const [filterType, setFilterType] = useState<string>('all');
  const [bookingProperty, setBookingProperty] = useState<Property | null>(null);
  const [bookingForm, setBookingForm] = useState({ name: '', phone: '', email: '', checkIn: '', checkOut: '', message: '' });
  const [detailProperty, setDetailProperty] = useState<Property | null>(null);
  const { addToast } = useToast();

  useEffect(() => {
    const unsub = subscribeProperties(setProperties);
    return () => unsub();
  }, []);

  const filtered = filterType === 'all' ? properties : properties.filter(p => p.type === filterType);

  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingProperty) return;
    if (!bookingForm.name || !bookingForm.phone || !bookingForm.checkIn || !bookingForm.checkOut) {
      addToast('error', 'Please fill in all required fields');
      return;
    }
    try {
      await addBooking({
        propertyId: bookingProperty.id,
        propertyTitle: bookingProperty.title,
        name: bookingForm.name,
        phone: bookingForm.phone,
        email: bookingForm.email,
        checkIn: bookingForm.checkIn,
        checkOut: bookingForm.checkOut,
        message: bookingForm.message,
        status: 'pending',
      });
      addToast('success', 'Booking request sent successfully! We will contact you soon.');
      setBookingProperty(null);
      setBookingForm({ name: '', phone: '', email: '', checkIn: '', checkOut: '', message: '' });
    } catch (err) {
      addToast('error', 'Failed to send booking request');
    }
  };

  return (
    <div className="min-h-screen pt-32 pb-20">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
        <SectionHeader
          eyebrow="REAL ESTATE"
          title="Company Bechir"
          subtitle="Find your perfect property"
        />

        {/* Filters */}
        <div className="flex flex-wrap gap-3 mb-10">
          {['all', 'rent', 'sale'].map(type => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all ${
                filterType === type
                  ? 'bg-gold text-[#0A0A0A]'
                  : 'bg-[#141414] text-white/60 border border-white/10 hover:border-gold/30'
              }`}
            >
              {type === 'all' ? 'All' : type === 'rent' ? 'For Rent' : 'For Sale'}
            </button>
          ))}
        </div>

        {/* Properties Grid */}
        {filtered.length === 0 ? (
          <p className="text-center text-white/40 py-20">No properties match your criteria.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filtered.map((property, i) => (
              <motion.div
                key={property.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.5 }}
                className="group bg-[#141414] border border-white/8 rounded-xl overflow-hidden hover:border-gold/30 hover:-translate-y-1 hover:shadow-elevated transition-all duration-400"
              >
                <div
                  className="relative h-56 overflow-hidden cursor-pointer"
                  onClick={() => setDetailProperty(property)}
                >
                  <img
                    src={property.images[0] || 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80'}
                    alt={property.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-4 left-4 flex gap-2">
                    <StatusBadge status={property.type} label={property.type === 'rent' ? 'For Rent' : 'For Sale'} />
                    <StatusBadge status={property.status} />
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="font-display text-lg font-semibold text-white mb-1">{property.title}</h3>
                  <p className="text-white/40 text-sm flex items-center gap-1 mb-3">
                    <MapPin className="w-4 h-4" /> {property.location}
                  </p>
                  <div className="flex items-center gap-4 mb-4 text-white/40 text-sm">
                    {property.features.slice(0, 3).map((f, idx) => (
                      <span key={idx} className="flex items-center gap-1">
                        {idx === 0 ? <Bed className="w-4 h-4" /> : idx === 1 ? <Bath className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
                        {f}
                      </span>
                    ))}
                  </div>
                  <div className="flex items-center justify-between">
                    <p className="text-gold text-xl font-bold">
                      ${property.price.toLocaleString()}
                      {property.type === 'rent' && <span className="text-sm text-white/40 font-normal">/mo</span>}
                    </p>
                    {property.type === 'rent' && property.status === 'available' && (
                      <button
                        onClick={() => setBookingProperty(property)}
                        className="px-5 py-2 bg-gold text-[#0A0A0A] rounded-full text-sm font-semibold hover:bg-gold-light transition-colors"
                      >
                        Book Now
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Booking Modal */}
      <AnimatePresence>
        {bookingProperty && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setBookingProperty(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={e => e.stopPropagation()}
              className="bg-[#141414] border border-white/8 rounded-xl p-6 max-w-md w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="font-display text-xl font-semibold text-white">Book Property</h3>
                <button onClick={() => setBookingProperty(null)} className="text-white/40 hover:text-white"><X className="w-5 h-5" /></button>
              </div>
              <div className="bg-gold/10 border border-gold/20 rounded-lg p-3 mb-6">
                <p className="text-gold text-sm font-medium">{bookingProperty.title}</p>
                <p className="text-white/40 text-xs">{bookingProperty.location}</p>
              </div>
              <form onSubmit={handleBookingSubmit} className="space-y-4">
                <div>
                  <label className="text-white/60 text-sm mb-1 block">Full Name *</label>
                  <input type="text" value={bookingForm.name} onChange={e => setBookingForm({ ...bookingForm, name: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" required />
                </div>
                <div>
                  <label className="text-white/60 text-sm mb-1 block">Phone Number *</label>
                  <input type="tel" value={bookingForm.phone} onChange={e => setBookingForm({ ...bookingForm, phone: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" required />
                </div>
                <div>
                  <label className="text-white/60 text-sm mb-1 block">Email</label>
                  <input type="email" value={bookingForm.email} onChange={e => setBookingForm({ ...bookingForm, email: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-white/60 text-sm mb-1 block">Check-in *</label>
                    <input type="date" value={bookingForm.checkIn} onChange={e => setBookingForm({ ...bookingForm, checkIn: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" required />
                  </div>
                  <div>
                    <label className="text-white/60 text-sm mb-1 block">Check-out *</label>
                    <input type="date" value={bookingForm.checkOut} onChange={e => setBookingForm({ ...bookingForm, checkOut: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" required />
                  </div>
                </div>
                <div>
                  <label className="text-white/60 text-sm mb-1 block">Message</label>
                  <textarea value={bookingForm.message} onChange={e => setBookingForm({ ...bookingForm, message: e.target.value })} rows={3} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none resize-none" />
                </div>
                <button type="submit" className="w-full py-3 bg-gold text-[#0A0A0A] rounded-full font-semibold hover:bg-gold-light transition-colors flex items-center justify-center gap-2">
                  <Send className="w-4 h-4" /> Send Booking Request
                </button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Detail Modal */}
      <AnimatePresence>
        {detailProperty && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setDetailProperty(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={e => e.stopPropagation()}
              className="bg-[#141414] border border-white/8 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="relative h-72">
                <img src={detailProperty.images[0]} alt={detailProperty.title} className="w-full h-full object-cover" />
                <button onClick={() => setDetailProperty(null)} className="absolute top-4 right-4 w-8 h-8 bg-black/50 rounded-full flex items-center justify-center text-white hover:bg-black/70"><X className="w-5 h-5" /></button>
              </div>
              <div className="p-6">
                <div className="flex gap-2 mb-3">
                  <StatusBadge status={detailProperty.type} label={detailProperty.type === 'rent' ? 'For Rent' : 'For Sale'} />
                  <StatusBadge status={detailProperty.status} />
                </div>
                <h3 className="font-display text-2xl font-semibold text-white mb-2">{detailProperty.title}</h3>
                <p className="text-white/40 flex items-center gap-1 mb-4"><MapPin className="w-4 h-4" /> {detailProperty.location}</p>
                <p className="text-gold text-2xl font-bold mb-4">${detailProperty.price.toLocaleString()}{detailProperty.type === 'rent' && <span className="text-sm text-white/40">/mo</span>}</p>
                <p className="text-white/60 text-sm leading-relaxed mb-4">{detailProperty.description}</p>
                <div className="flex flex-wrap gap-2">
                  {detailProperty.features.map(f => (
                    <span key={f} className="px-3 py-1 bg-gold/10 border border-gold/20 rounded-full text-gold text-xs">{f}</span>
                  ))}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
