import { motion } from 'framer-motion';
import { Search, Lightbulb, BarChart3, Phone } from 'lucide-react';
import SectionHeader from '@/components/shared/SectionHeader';

const services = [
  {
    icon: <BarChart3 className="w-8 h-8 text-gold" />,
    title: 'Revenue Optimization',
    description: 'We analyze your business model and identify opportunities to increase revenue by 10% to over 40%.',
    process: ['Discovery', 'Analysis', 'Strategy', 'Implementation', 'Results'],
  },
  {
    icon: <Search className="w-8 h-8 text-gold" />,
    title: 'Market Expansion',
    description: 'Enter new markets with confidence. We provide market research, entry strategy, and execution support.',
    process: ['Research', 'Planning', 'Entry', 'Growth'],
  },
  {
    icon: <Lightbulb className="w-8 h-8 text-gold" />,
    title: 'Operational Excellence',
    description: 'Streamline operations and maximize efficiency across your organization.',
    process: ['Audit', 'Design', 'Implement', 'Optimize'],
  },
];

export default function Consulting() {
  return (
    <div className="min-h-screen pt-32 pb-20">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
        <SectionHeader
          eyebrow="CONSULTING"
          title="Business Growth"
          subtitle="Take your business to the next level"
        />

        <div className="space-y-20 mb-20">
          {services.map((service, i) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${i % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}
            >
              <div className={i % 2 === 1 ? 'lg:order-2' : ''}>
                <div className="w-16 h-16 rounded-full bg-gold/10 flex items-center justify-center mb-6">
                  {service.icon}
                </div>
                <h3 className="font-display text-2xl font-semibold text-white mb-4">{service.title}</h3>
                <p className="text-white/50 leading-relaxed mb-6">{service.description}</p>
                <div className="flex flex-wrap gap-3">
                  {service.process.map((step, idx) => (
                    <div key={step} className="flex items-center gap-2">
                      <span className="w-8 h-8 rounded-full bg-gold/15 text-gold text-xs font-bold flex items-center justify-center">{idx + 1}</span>
                      <span className="text-white/60 text-sm">{step}</span>
                      {idx < service.process.length - 1 && <div className="w-4 h-px bg-gold/30 ml-2 hidden sm:block" />}
                    </div>
                  ))}
                </div>
              </div>
              <div className={i % 2 === 1 ? 'lg:order-1' : ''}>
                <div className="bg-[#141414] border border-white/8 rounded-xl p-8 h-64 flex items-center justify-center">
                  <div className="text-center">
                    <service.icon.type {...service.icon.props} className="w-16 h-16 text-gold/30 mx-auto mb-4" />
                    <p className="text-white/20 font-display text-lg">{service.title}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-[#141414] border border-gold/20 rounded-2xl p-12 text-center"
        >
          <h2 className="font-display text-3xl font-bold text-white mb-4">Ready to Grow Your Business?</h2>
          <p className="text-white/50 mb-8">Schedule a free consultation call with our experts.</p>
          <a
            href="https://wa.me/21692644215"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 bg-gold text-[#0A0A0A] rounded-full font-semibold hover:bg-gold-light transition-colors"
          >
            <Phone className="w-5 h-5" />
            Contact Us on WhatsApp
          </a>
        </motion.div>
      </div>
    </div>
  );
}
