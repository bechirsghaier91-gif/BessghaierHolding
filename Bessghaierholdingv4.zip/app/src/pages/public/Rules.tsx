import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FileText, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import SectionHeader from '@/components/shared/SectionHeader';
import { subscribeSiteSettings } from '@/lib/firebaseServices';
import type { SiteSettings } from '@/types';

export default function Rules() {
  const [settings, setSettings] = useState<SiteSettings | null>(null);

  useEffect(() => {
    const unsub = subscribeSiteSettings(setSettings);
    return () => unsub();
  }, []);

  return (
    <div className="min-h-screen pt-32 pb-20">
      <div className="max-w-[900px] mx-auto px-6 lg:px-10">
        <SectionHeader
          eyebrow="RULES"
          title="Collaboration Terms"
          subtitle="Terms and conditions for partners and collaborators"
        />

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="bg-[#141414] border border-white/8 rounded-xl p-8 md:p-12"
        >
          {settings?.rulesContent ? (
            <div
              className="prose prose-invert max-w-none prose-headings:font-display prose-headings:text-gold prose-h2:text-xl prose-h2:mt-8 prose-h2:mb-4 prose-h3:text-lg prose-h3:text-gold-light prose-p:text-white/60 prose-p:leading-relaxed prose-ul:text-white/60 prose-ul:space-y-2 prose-strong:text-gold-light"
              dangerouslySetInnerHTML={{ __html: settings.rulesContent }}
            />
          ) : (
            <div className="text-center py-12">
              <FileText className="w-16 h-16 text-white/20 mx-auto mb-4" />
              <p className="text-white/40 text-lg">Rules and terms will be updated soon.</p>
            </div>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-12 bg-gold/10 border border-gold/30 rounded-xl p-8 text-center"
        >
          <p className="text-white/70 mb-4">By applying for collaboration, you agree to these terms.</p>
          <Link
            to="/apply"
            className="inline-flex items-center gap-2 px-8 py-4 bg-gold text-[#0A0A0A] rounded-full font-semibold hover:bg-gold-light transition-colors"
          >
            Apply for Collaboration <ArrowRight className="w-5 h-5" />
          </Link>
        </motion.div>
      </div>
    </div>
  );
}
