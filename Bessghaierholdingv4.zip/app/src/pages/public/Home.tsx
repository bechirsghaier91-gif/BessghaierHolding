import { useEffect, useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Home as HomeIcon, BookOpen, Plane, TrendingUp, Megaphone, Star, MapPin, ArrowRight, Building2, Users, BookCopy, Award, Phone } from 'lucide-react';
import SectionHeader from '@/components/shared/SectionHeader';
import StarRating from '@/components/shared/StarRating';
import StatusBadge from '@/components/shared/StatusBadge';
import { subscribeProperties, subscribeReviews, subscribeRooms } from '@/lib/firebaseServices';
import type { Property, Review, Room } from '@/types';

/* ─── Animated Gold Particles ─── */
function GoldParticles() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    let animId: number;

    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    interface Particle {
      x: number; y: number; r: number; speed: number; opacity: number;
    }
    const particles: Particle[] = Array.from({ length: 40 }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      r: Math.random() * 2 + 1,
      speed: Math.random() * 0.3 + 0.1,
      opacity: Math.random() * 0.4 + 0.2,
    }));

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach(p => {
        p.y -= p.speed;
        if (p.y < -10) { p.y = canvas.height + 10; p.x = Math.random() * canvas.width; }
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(201,168,76,${p.opacity})`;
        ctx.fill();
      });
      animId = requestAnimationFrame(draw);
    };
    draw();
    return () => { cancelAnimationFrame(animId); window.removeEventListener('resize', resize); };
  }, []);
  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />;
}

/* ─── Hero Section ─── */
function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center bg-[#0A0A0A] overflow-hidden">
      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(201,168,76,0.08)_0%,transparent_70%)]" />
      <GoldParticles />

      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="text-gold text-sm uppercase tracking-[0.2em] mb-6 inline-flex items-center gap-2 px-4 py-2 rounded-full border border-gold/30 bg-gold/5"
        >
          <span className="w-2 h-2 rounded-full bg-gold animate-pulse" />
          Global Investments - International
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="font-display text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold text-white leading-[0.95] mb-2"
        >
          Building the Future
        </motion.h1>
        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.65, duration: 0.8 }}
          className="font-display text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold leading-[0.95] mb-8"
        >
          <span className="text-gold">With Excellence</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9, duration: 0.8 }}
          className="text-white/50 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed"
        >
          Bessghaier Holding is a multi-activity entity combining real estate investment, publishing, and desert tourism. We create added value in every project.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.1, duration: 0.8 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <Link
            to="/real-estate"
            className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gold text-[#0A0A0A] rounded-full font-semibold hover:bg-gold-light hover:shadow-gold transition-all"
          >
            <Building2 className="w-5 h-5" />
            Explore Properties
          </Link>
          <a
            href="https://wa.me/21692644215"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-8 py-4 border border-white/20 text-white rounded-full font-medium hover:border-gold/50 hover:text-gold transition-all"
          >
            <Phone className="w-5 h-5" />
            Contact Us
          </a>
        </motion.div>
      </div>
    </section>
  );
}

/* ─── Services Section ─── */
function Services() {
  const [rooms, setRooms] = useState<Room[]>([]);

  useEffect(() => {
    const unsub = subscribeRooms(setRooms);
    return () => unsub();
  }, []);

  const iconMap: Record<string, React.ReactNode> = {
    BookOpen: <BookOpen className="w-6 h-6 text-gold" />,
    Home: <HomeIcon className="w-6 h-6 text-gold" />,
    Plane: <Plane className="w-6 h-6 text-gold" />,
    TrendingUp: <TrendingUp className="w-6 h-6 text-gold" />,
    Megaphone: <Megaphone className="w-6 h-6 text-gold" />,
    Star: <Star className="w-6 h-6 text-gold" />,
  };

  const linkMap: Record<string, string> = {
    'Publishing': '/books',
    'Real Estate': '/real-estate',
    'Travel': '/travel',
    'Consulting': '/consulting',
    'Marketing': '/marketing',
  };

  const descriptions: Record<string, string> = {
    'Publishing': 'Amazon Kindle Publishing with dedicated marketing. Paperback copies available!',
    'Real Estate': 'Complete real estate services: Sales, Rentals, and Property Management.',
    'Travel': 'Desert tourism with multiple options: Full Package, Guide Only, and more!',
    'Consulting': 'Improve revenue from 10% to over 40%. Expert consulting for all projects!',
    'Marketing': 'Marketing & Influencers — Professional marketing with well-known influencers for any brand!',
  };

  const activeRooms = rooms.filter(r => r.isActive);
  const displayRooms = activeRooms.length > 0 ? activeRooms : [
    { name: 'Publishing', icon: 'BookOpen', description: descriptions['Publishing'] },
    { name: 'Real Estate', icon: 'Home', description: descriptions['Real Estate'] },
    { name: 'Travel', icon: 'Plane', description: descriptions['Travel'] },
    { name: 'Consulting', icon: 'TrendingUp', description: descriptions['Consulting'] },
    { name: 'Marketing', icon: 'Megaphone', description: descriptions['Marketing'] },
    { name: 'Dedicated', icon: 'Star', description: 'Want a dedicated website? Your name will appear here! Contact us.' },
  ];

  return (
    <section className="py-32 bg-[#0A0A0A]">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
        <SectionHeader
          eyebrow="WHAT WE DO"
          title="Our Services"
          subtitle="Discover our diverse range of professional services"
        />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayRooms.map((room, i) => (
            <motion.div
              key={room.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className="group bg-[#141414] border border-white/8 rounded-xl p-8 hover:border-gold/30 hover:-translate-y-1 hover:shadow-elevated transition-all duration-400"
            >
              <div className="w-14 h-14 rounded-full bg-gold/10 flex items-center justify-center mb-6 group-hover:bg-gold/20 transition-colors">
                {iconMap[room.icon] || <Star className="w-6 h-6 text-gold" />}
              </div>
              <h3 className="font-display text-xl font-semibold text-white mb-3">{room.name}</h3>
              <p className="text-white/50 text-sm leading-relaxed mb-4">{room.description || descriptions[room.name] || 'Professional services by Bessghaier Holding.'}</p>
              <Link
                to={linkMap[room.name] || '/magazine'}
                className="inline-flex items-center gap-2 text-gold text-sm font-medium hover:gap-3 transition-all"
              >
                View Details <ArrowRight className="w-4 h-4" />
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── About Section ─── */
function About() {
  return (
    <section className="py-32 bg-[#0A0A0A]">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <SectionHeader
              eyebrow="ABOUT US"
              title="Bessghaier Holding"
              subtitle="Integrated Investment Vision"
              align="left"
            />
            <div className="-mt-8">
              <p className="text-white/60 leading-relaxed mb-4">
                Bessghaier Holding was founded to diversify investments and provide integrated services in real estate, publishing, and tourism.
              </p>
              <p className="text-white/60 leading-relaxed mb-6">
                We aim to be a leader in the Tunisian and international markets, through innovative solutions and high-quality services.
              </p>
              <Link
                to="/real-estate"
                className="inline-flex items-center gap-2 px-6 py-3 border border-gold/50 text-gold rounded-full font-medium hover:bg-gold/10 transition-all"
              >
                Learn More <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="grid grid-cols-2 gap-4"
          >
            {[
              'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=400&q=80',
              'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&q=80',
              'https://images.unsplash.com/photo-1509316785289-025f5b846b35?w=400&q=80',
              'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=400&q=80',
            ].map((img, i) => (
              <div
                key={i}
                className={`rounded-lg overflow-hidden border border-gold/20 ${i % 2 === 1 ? 'mt-8' : ''}`}
              >
                <img src={img} alt={`About ${i + 1}`} className="w-full h-40 object-cover hover:scale-105 transition-transform duration-500" />
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}

/* ─── Stats Section ─── */
function Stats() {
  const stats = [
    { icon: <Building2 className="w-6 h-6" />, value: '500+', label: 'Properties Managed' },
    { icon: <BookCopy className="w-6 h-6" />, value: '50+', label: 'Books Published' },
    { icon: <Users className="w-6 h-6" />, value: '1000+', label: 'Happy Clients' },
    { icon: <Award className="w-6 h-6" />, value: '10+', label: 'Years of Experience' },
  ];

  return (
    <section className="py-20 bg-[#141414]">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className="text-center"
            >
              <div className="w-14 h-14 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-4 text-gold">
                {stat.icon}
              </div>
              <p className="font-display text-4xl md:text-5xl font-bold text-gold mb-2">{stat.value}</p>
              <p className="text-white/50 text-sm">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Featured Properties Section ─── */
function FeaturedProperties() {
  const [properties, setProperties] = useState<Property[]>([]);

  useEffect(() => {
    const unsub = subscribeProperties(setProperties);
    return () => unsub();
  }, []);

  const featured = properties.filter(p => p.status === 'available').slice(0, 3);

  return (
    <section className="py-32 bg-[#0A0A0A]">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
        <SectionHeader
          eyebrow="FEATURED LISTINGS"
          title="Latest Properties"
          subtitle="Explore our newest real estate opportunities"
        />

        {featured.length === 0 ? (
          <p className="text-center text-white/40">No properties available yet.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featured.map((property, i) => (
              <motion.div
                key={property.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.5 }}
                className="group bg-[#141414] border border-white/8 rounded-xl overflow-hidden hover:border-gold/30 hover:-translate-y-1 hover:shadow-elevated transition-all duration-400"
              >
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={property.images[0] || 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80'}
                    alt={property.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4">
                    <StatusBadge status={property.type} label={property.type === 'rent' ? 'For Rent' : 'For Sale'} />
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="font-display text-xl font-semibold text-white mb-2">{property.title}</h3>
                  <p className="text-white/40 text-sm flex items-center gap-1 mb-3">
                    <MapPin className="w-4 h-4" /> {property.location}
                  </p>
                  <div className="flex items-center justify-between">
                    <p className="text-gold text-xl font-bold">
                      ${property.price.toLocaleString()}
                      {property.type === 'rent' && <span className="text-sm text-white/40 font-normal">/mo</span>}
                    </p>
                    <StatusBadge status={property.status} />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        <div className="text-center mt-12">
          <Link
            to="/real-estate"
            className="inline-flex items-center gap-2 px-8 py-4 bg-gold text-[#0A0A0A] rounded-full font-semibold hover:bg-gold-light transition-colors"
          >
            View All Properties <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </div>
    </section>
  );
}

/* ─── Testimonials Section ─── */
function Testimonials() {
  const [reviews, setReviews] = useState<Review[]>([]);

  useEffect(() => {
    const unsub = subscribeReviews(setReviews);
    return () => unsub();
  }, []);

  const approved = reviews.filter(r => r.isApproved).slice(0, 3);

  const demoReviews = approved.length > 0 ? approved : [
    { id: '1', name: 'Khaled M.', rating: 5, comment: 'Excellent service! The team at Bessghaier Holding helped me find the perfect property. Highly recommended!', createdAt: new Date().toISOString() },
    { id: '2', name: 'Fatima B.', rating: 5, comment: 'Amazing desert travel experience. Everything was perfectly organized from start to finish. Will definitely book again!', createdAt: new Date().toISOString() },
    { id: '3', name: 'Youssef A.', rating: 4, comment: 'Great consulting services. They helped increase our revenue by 25% in just 3 months.', createdAt: new Date().toISOString() },
  ];

  return (
    <section className="py-32 bg-[#0A0A0A]">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
        <SectionHeader
          eyebrow="TESTIMONIALS"
          title="What Our Clients Say"
        />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {demoReviews.map((review, i) => (
            <motion.div
              key={review.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className="bg-[#141414] border border-white/8 rounded-xl p-8"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-gold/20 flex items-center justify-center text-gold font-display font-bold">
                  {review.name.charAt(0)}
                </div>
                <div>
                  <p className="text-white font-medium">{review.name}</p>
                  <StarRating rating={review.rating} size={16} />
                </div>
              </div>
              <p className="text-white/60 text-sm leading-relaxed">{review.comment}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── CTA Section ─── */
function CTASection() {
  return (
    <section className="py-28 bg-[#141414]">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="font-display text-4xl md:text-5xl font-bold text-white mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-white/50 text-lg mb-8 max-w-xl mx-auto">
            Contact us today to discuss your next project or property investment.
          </p>
          <a
            href="https://wa.me/21692644215"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 bg-gold text-[#0A0A0A] rounded-full font-semibold hover:bg-gold-light hover:shadow-gold transition-all"
          >
            <Phone className="w-5 h-5" />
            Contact on WhatsApp
          </a>
        </motion.div>
      </div>
    </section>
  );
}

/* ─── Home Page ─── */
export default function Home() {
  return (
    <>
      <Hero />
      <Services />
      <About />
      <Stats />
      <FeaturedProperties />
      <Testimonials />
      <CTASection />
    </>
  );
}
