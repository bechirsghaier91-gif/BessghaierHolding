import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, ArrowRight, ArrowLeft, Pen, FileText, Send, CheckCircle } from 'lucide-react';
import { getSiteSettings, addCollaboration } from '@/lib/firebaseServices';
import { useToast } from '@/contexts/ToastContext';
import type { SiteSettings } from '@/types';

export default function Apply() {
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ name: '', email: '', phone: '', whatsapp: '', description: '' });
  const [rulesAccepted, setRulesAccepted] = useState(false);
  const [signatureData, setSignatureData] = useState('');
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [refId, setRefId] = useState('');
  const [isDrawing, setIsDrawing] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { addToast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    getSiteSettings().then(setSettings);
  }, []);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.beginPath();
    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;
    ctx.moveTo(x, y);
    setIsDrawing(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;
    ctx.lineTo(x, y);
    ctx.strokeStyle = '#C9A84C';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    const canvas = canvasRef.current;
    if (canvas) {
      setSignatureData(canvas.toDataURL());
    }
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setSignatureData('');
  };

  const handleSubmit = async () => {
    if (!signatureData) {
      addToast('error', 'Please provide your signature');
      return;
    }
    try {
      const id = await addCollaboration({
        name: form.name,
        email: form.email,
        phone: form.phone,
        whatsapp: form.whatsapp,
        status: 'applied',
        rulesAccepted: true,
        signatureData,
        price: 0,
        rulesContent: settings?.rulesContent || '',
        adminNotes: '',
        messages: [],
      });
      setRefId(id);
      setStep(4);
      addToast('success', 'Application submitted successfully!');
    } catch {
      addToast('error', 'Failed to submit application');
    }
  };

  return (
    <div className="min-h-screen pt-32 pb-20">
      <div className="max-w-[700px] mx-auto px-6 lg:px-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <p className="text-gold text-sm uppercase tracking-[0.2em] mb-4">APPLY</p>
          <h1 className="font-display text-4xl md:text-5xl font-bold text-white mb-4">Collaboration Application</h1>
          <p className="text-white/50">Join us as a partner or collaborator</p>
        </motion.div>

        {/* Step Indicator */}
        <div className="flex items-center justify-center gap-4 mb-12">
          {[1, 2, 3, 4].map((s) => (
            <div key={s} className="flex items-center gap-4">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold transition-all ${
                step >= s ? 'bg-gold text-[#0A0A0A]' : 'bg-[#1A1A1A] text-white/40 border border-white/10'
              }`}>
                {step > s ? <Check className="w-5 h-5" /> : s}
              </div>
              {s < 4 && <div className={`w-12 h-px ${step > s ? 'bg-gold' : 'bg-white/10'}`} />}
            </div>
          ))}
        </div>

        <AnimatePresence mode="wait">
          {/* Step 1: Personal Info */}
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="bg-[#141414] border border-white/8 rounded-xl p-8"
            >
              <h2 className="font-display text-xl font-semibold text-white mb-6">Personal Information</h2>
              <div className="space-y-4">
                <div>
                  <label className="text-white/60 text-sm mb-1 block">Full Name *</label>
                  <input type="text" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" required />
                </div>
                <div>
                  <label className="text-white/60 text-sm mb-1 block">Email *</label>
                  <input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" required />
                </div>
                <div>
                  <label className="text-white/60 text-sm mb-1 block">Phone Number *</label>
                  <input type="tel" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" required />
                </div>
                <div>
                  <label className="text-white/60 text-sm mb-1 block">WhatsApp Number *</label>
                  <input type="tel" value={form.whatsapp} onChange={e => setForm({ ...form, whatsapp: e.target.value })} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none" required />
                </div>
                <div>
                  <label className="text-white/60 text-sm mb-1 block">Project/Interest Description</label>
                  <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} rows={3} className="w-full bg-[#1A1A1A] border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-gold focus:outline-none resize-none" />
                </div>
              </div>
              <button
                onClick={() => {
                  if (!form.name || !form.email || !form.phone || !form.whatsapp) {
                    addToast('error', 'Please fill in all required fields');
                    return;
                  }
                  setStep(2);
                }}
                className="w-full mt-6 py-3 bg-gold text-[#0A0A0A] rounded-full font-semibold hover:bg-gold-light transition-colors flex items-center justify-center gap-2"
              >
                Next <ArrowRight className="w-4 h-4" />
              </button>
            </motion.div>
          )}

          {/* Step 2: Rules */}
          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="bg-[#141414] border border-white/8 rounded-xl p-8"
            >
              <h2 className="font-display text-xl font-semibold text-white mb-6 flex items-center gap-2">
                <FileText className="w-5 h-5 text-gold" /> Review Rules
              </h2>
              <div className="bg-[#0A0A0A] rounded-lg p-6 mb-6 max-h-64 overflow-y-auto border border-white/5">
                {settings?.rulesContent ? (
                  <div className="text-white/60 text-sm leading-relaxed" dangerouslySetInnerHTML={{ __html: settings.rulesContent }} />
                ) : (
                  <p className="text-white/40">Rules will be updated soon.</p>
                )}
              </div>
              <label className="flex items-center gap-3 cursor-pointer">
                <div
                  onClick={() => setRulesAccepted(!rulesAccepted)}
                  className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${
                    rulesAccepted ? 'bg-gold border-gold' : 'border-white/30'
                  }`}
                >
                  {rulesAccepted && <Check className="w-3 h-3 text-[#0A0A0A]" />}
                </div>
                <span className="text-white/70 text-sm">I have read and agree to the collaboration terms</span>
              </label>
              <div className="flex gap-3 mt-6">
                <button onClick={() => setStep(1)} className="flex-1 py-3 border border-white/20 text-white rounded-full font-medium hover:bg-white/5 transition-colors flex items-center justify-center gap-2">
                  <ArrowLeft className="w-4 h-4" /> Back
                </button>
                <button
                  onClick={() => {
                    if (!rulesAccepted) {
                      addToast('error', 'Please accept the rules to continue');
                      return;
                    }
                    setStep(3);
                  }}
                  className="flex-1 py-3 bg-gold text-[#0A0A0A] rounded-full font-semibold hover:bg-gold-light transition-colors flex items-center justify-center gap-2"
                >
                  Next <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          )}

          {/* Step 3: Signature */}
          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="bg-[#141414] border border-white/8 rounded-xl p-8"
            >
              <h2 className="font-display text-xl font-semibold text-white mb-2 flex items-center gap-2">
                <Pen className="w-5 h-5 text-gold" /> Digital Signature
              </h2>
              <p className="text-white/50 text-sm mb-6">Please sign below using your mouse or finger</p>

              <div className="relative bg-white rounded-lg overflow-hidden mb-4" style={{ height: 200 }}>
                <canvas
                  ref={canvasRef}
                  width={600}
                  height={200}
                  className="w-full h-full cursor-crosshair touch-none"
                  onMouseDown={startDrawing}
                  onMouseMove={draw}
                  onMouseUp={stopDrawing}
                  onMouseLeave={stopDrawing}
                  onTouchStart={startDrawing}
                  onTouchMove={draw}
                  onTouchEnd={stopDrawing}
                />
                {!signatureData && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <span className="text-gray-300 font-display text-lg">Sign here</span>
                  </div>
                )}
              </div>

              <button onClick={clearSignature} className="text-white/50 text-sm hover:text-white transition-colors mb-6">
                Clear Signature
              </button>

              <div className="flex gap-3">
                <button onClick={() => setStep(2)} className="flex-1 py-3 border border-white/20 text-white rounded-full font-medium hover:bg-white/5 transition-colors flex items-center justify-center gap-2">
                  <ArrowLeft className="w-4 h-4" /> Back
                </button>
                <button onClick={handleSubmit} className="flex-1 py-3 bg-gold text-[#0A0A0A] rounded-full font-semibold hover:bg-gold-light transition-colors flex items-center justify-center gap-2">
                  <Send className="w-4 h-4" /> Submit Application
                </button>
              </div>
            </motion.div>
          )}

          {/* Step 4: Success */}
          {step === 4 && (
            <motion.div
              key="step4"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-[#141414] border border-gold/30 rounded-xl p-12 text-center"
            >
              <div className="w-20 h-20 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-10 h-10 text-green-500" />
              </div>
              <h2 className="font-display text-2xl font-semibold text-white mb-3">Application Submitted!</h2>
              <p className="text-white/50 mb-2">We will review your application and contact you via email and WhatsApp.</p>
              <p className="text-gold text-sm mb-8">Your reference: {refId}</p>
              <button
                onClick={() => navigate('/')}
                className="px-8 py-3 bg-gold text-[#0A0A0A] rounded-full font-semibold hover:bg-gold-light transition-colors"
              >
                Return to Home
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
