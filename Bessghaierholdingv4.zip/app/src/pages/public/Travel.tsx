import { motion } from 'framer-motion';
import { Check, Phone } from 'lucide-react';
import SectionHeader from '@/components/shared/SectionHeader';

const packages = [
  {
    title: 'Full Package Tour',
    description: 'Complete desert experience with guide, meals, and accommodation.',
    image: 'https://images.unsplash.com/photo-1509316785289-025f5b846b35?w=800&q=80',
    price: 'From $299/person',
    features: ['Private Guide', 'Traditional Meals', 'Desert Camp', 'Camel Trek', 'Star Gazing'],
  },
  {
    title: 'Guide Only',
    description: 'Professional local guide to show you the best spots.',
    image: 'https://images.unsplash.com/photo-1542259681-d91182a5334d?w=800&q=80',
    price: 'From $99/day',
    features: ['Expert Local Guide', 'Custom Itinerary', 'Transportation Advice', 'Hidden Gems'],
  },
  {
    title: 'Airport Transfer + Private House',
    description: 'Comfortable transfer and private accommodation.',
    image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800&q=80',
    price: 'From $149/night',
    features: ['Airport Pickup', 'Private House', 'WiFi', 'Kitchen', '24/7 Support'],
  },
];

export default function Travel() {
  return (
    <div className="min-h-screen pt-32 pb-20">
      {/* Hero */}
      <div className="relative h-[60vh] mb-20 -mt-8">
        <img src="https://images.unsplash.com/photo-1509316785289-025f5b846b35?w=1600&q=80" alt="Desert" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-[#0A0A0A]/60 to-transparent" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center px-6">
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-gold text-sm uppercase tracking-[0.2em] mb-4"
            >
              DJERID TRAVEL
            </motion.p>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="font-display text-5xl md:text-6xl font-bold text-white mb-4"
            >
              Desert Tourism
            </motion.h1>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-white/60 text-lg max-w-xl mx-auto"
            >
              Explore the magic of the Tunisian desert
            </motion.p>
          </div>
        </div>
      </div>

      <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
        <SectionHeader
          eyebrow="OUR PACKAGES"
          title="Travel Packages"
          subtitle="Choose the perfect experience for your desert adventure"
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {packages.map((pkg, i) => (
            <motion.div
              key={pkg.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className="group bg-[#141414] border border-white/8 rounded-xl overflow-hidden hover:border-gold/30 hover:-translate-y-1 hover:shadow-elevated transition-all duration-400"
            >
              <div className="relative h-56 overflow-hidden">
                <img src={pkg.image} alt={pkg.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              </div>
              <div className="p-6">
                <h3 className="font-display text-xl font-semibold text-white mb-2">{pkg.title}</h3>
                <p className="text-white/50 text-sm mb-4">{pkg.description}</p>
                <ul className="space-y-2 mb-6">
                  {pkg.features.map(f => (
                    <li key={f} className="flex items-center gap-2 text-white/60 text-sm">
                      <Check className="w-4 h-4 text-gold" /> {f}
                    </li>
                  ))}
                </ul>
                <div className="flex items-center justify-between">
                  <p className="text-gold font-bold">{pkg.price}</p>
                  <a
                    href="https://wa.me/21692644215"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-5 py-2.5 bg-gold text-[#0A0A0A] rounded-full text-sm font-semibold hover:bg-gold-light transition-colors"
                  >
                    <Phone className="w-4 h-4" />
                    Book Now
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
