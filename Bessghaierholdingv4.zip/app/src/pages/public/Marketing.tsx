import { motion } from 'framer-motion';
import { Instagram, Globe, Target, TrendingUp, Sparkles, Phone } from 'lucide-react';
import SectionHeader from '@/components/shared/SectionHeader';

const services = [
  {
    icon: <Instagram className="w-8 h-8 text-gold" />,
    title: 'Influencer Marketing',
    description: 'Connect with well-known influencers to promote your brand authentically across social media platforms.',
  },
  {
    icon: <Globe className="w-8 h-8 text-gold" />,
    title: 'Social Media Management',
    description: 'Full-service social media strategy, content creation, and community management for your brand.',
  },
  {
    icon: <Target className="w-8 h-8 text-gold" />,
    title: 'Brand Strategy',
    description: 'Build a brand that resonates. From positioning to visual identity, we create memorable brands.',
  },
];

export default function Marketing() {
  return (
    <div className="min-h-screen pt-32 pb-20">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
        <SectionHeader
          eyebrow="MARKETING"
          title="Influencer Marketing"
          subtitle="Amplify your brand with the right voices"
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          {services.map((service, i) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className="bg-[#141414] border border-white/8 rounded-xl p-8 hover:border-gold/30 hover:-translate-y-1 hover:shadow-elevated transition-all duration-400 text-center"
            >
              <div className="w-16 h-16 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-6">
                {service.icon}
              </div>
              <h3 className="font-display text-xl font-semibold text-white mb-3">{service.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{service.description}</p>
            </motion.div>
          ))}
        </div>

        {/* Publishing Marketing Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-[#141414] border border-gold/20 rounded-2xl p-8 md:p-12 mb-20"
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="w-5 h-5 text-gold" />
                <span className="text-gold text-sm uppercase tracking-wider">Publishing</span>
              </div>
              <h2 className="font-display text-3xl font-bold text-white mb-4">Publishing Marketing</h2>
              <p className="text-white/50 leading-relaxed mb-6">
                We market your books through our publishing network. From Amazon Kindle optimization to social media promotion, we ensure your work reaches the right audience.
              </p>
              <div className="grid grid-cols-2 gap-3">
                {['Kindle SEO', 'Social Media Campaigns', 'Email Marketing', 'Influencer Reviews'].map(f => (
                  <div key={f} className="flex items-center gap-2 text-white/60 text-sm">
                    <TrendingUp className="w-4 h-4 text-gold" /> {f}
                  </div>
                ))}
              </div>
            </div>
            <div className="flex justify-center">
              <div className="w-full max-w-sm bg-[#0A0A0A] border border-white/8 rounded-xl p-8 text-center">
                <BookOpenIcon />
                <p className="font-display text-white text-lg mt-4">Book Marketing Solutions</p>
                <p className="text-white/40 text-sm mt-2">Reach millions of readers worldwide</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <h2 className="font-display text-3xl font-bold text-white mb-4">Start Your Campaign</h2>
          <p className="text-white/50 mb-8">Let us help you reach your target audience effectively.</p>
          <a
            href="https://wa.me/21692644215"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 bg-gold text-[#0A0A0A] rounded-full font-semibold hover:bg-gold-light transition-colors"
          >
            <Phone className="w-5 h-5" />
            Contact Us
          </a>
        </motion.div>
      </div>
    </div>
  );
}

function BookOpenIcon() {
  return (
    <div className="w-20 h-20 rounded-full bg-gold/10 flex items-center justify-center mx-auto">
      <svg className="w-10 h-10 text-gold" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
      </svg>
    </div>
  );
}
