import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Home } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <p className="font-display text-[120px] md:text-[180px] font-bold text-gold/20 leading-none mb-4">404</p>
        <h1 className="font-display text-3xl font-bold text-white mb-4">Page Not Found</h1>
        <p className="text-white/50 mb-8 max-w-md mx-auto">The page you are looking for does not exist or has been moved.</p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 px-8 py-4 bg-gold text-[#0A0A0A] rounded-full font-semibold hover:bg-gold-light transition-colors"
        >
          <Home className="w-5 h-5" />
          Return to Home
        </Link>
      </motion.div>
    </div>
  );
}
