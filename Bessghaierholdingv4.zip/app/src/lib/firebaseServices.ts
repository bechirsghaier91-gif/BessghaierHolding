import {
  collection, doc, getDocs, getDoc, addDoc, updateDoc, deleteDoc, query, orderBy, where, onSnapshot, serverTimestamp, Timestamp
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { db, storage } from './firebase';
import type { Property, Book, Room, Post, Booking, Review, User, Collaboration, Notification, SiteSettings } from '@/types';

const timestampToString = (ts: any): string => {
  if (!ts) return new Date().toISOString();
  if (ts instanceof Timestamp) return ts.toDate().toISOString();
  if (typeof ts === 'string') return ts;
  return new Date().toISOString();
};

const addTimestamps = (data: any) => ({
  ...data,
  createdAt: serverTimestamp(),
  updatedAt: serverTimestamp(),
});

const updateTimestamps = (data: any) => ({
  ...data,
  updatedAt: serverTimestamp(),
});

// Image Upload
export const uploadImage = async (file: File, path: string): Promise<string> => {
  const storageRef = ref(storage, `${path}/${Date.now()}_${file.name}`);
  await uploadBytes(storageRef, file);
  return getDownloadURL(storageRef);
};

export const deleteImage = async (url: string): Promise<void> => {
  try {
    const imageRef = ref(storage, url);
    await deleteObject(imageRef);
  } catch (e) {
    console.error('Error deleting image:', e);
  }
};

// Properties
export const propertiesCollection = collection(db, 'properties');

export const getProperties = async (): Promise<Property[]> => {
  const q = query(propertiesCollection, orderBy('createdAt', 'desc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(d => {
    const data = d.data();
    return { id: d.id, ...data, createdAt: timestampToString(data.createdAt), updatedAt: timestampToString(data.updatedAt) } as Property;
  });
};

export const subscribeProperties = (callback: (props: Property[]) => void) => {
  const q = query(propertiesCollection, orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const props = snapshot.docs.map(d => {
      const data = d.data();
      return { id: d.id, ...data, createdAt: timestampToString(data.createdAt), updatedAt: timestampToString(data.updatedAt) } as Property;
    });
    callback(props);
  });
};

export const addProperty = async (data: Omit<Property, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> => {
  const docRef = await addDoc(propertiesCollection, addTimestamps(data));
  return docRef.id;
};

export const updateProperty = async (id: string, data: Partial<Property>): Promise<void> => {
  await updateDoc(doc(db, 'properties', id), updateTimestamps(data));
};

export const deleteProperty = async (id: string): Promise<void> => {
  await deleteDoc(doc(db, 'properties', id));
};

// Books
export const booksCollection = collection(db, 'books');

export const getBooks = async (): Promise<Book[]> => {
  const q = query(booksCollection, orderBy('createdAt', 'desc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(d => {
    const data = d.data();
    return { id: d.id, ...data, createdAt: timestampToString(data.createdAt), updatedAt: timestampToString(data.updatedAt) } as Book;
  });
};

export const subscribeBooks = (callback: (books: Book[]) => void) => {
  const q = query(booksCollection, orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const books = snapshot.docs.map(d => {
      const data = d.data();
      return { id: d.id, ...data, createdAt: timestampToString(data.createdAt), updatedAt: timestampToString(data.updatedAt) } as Book;
    });
    callback(books);
  });
};

export const addBook = async (data: Omit<Book, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> => {
  const docRef = await addDoc(booksCollection, addTimestamps(data));
  return docRef.id;
};

export const updateBook = async (id: string, data: Partial<Book>): Promise<void> => {
  await updateDoc(doc(db, 'books', id), updateTimestamps(data));
};

export const deleteBook = async (id: string): Promise<void> => {
  await deleteDoc(doc(db, 'books', id));
};

// Rooms
export const roomsCollection = collection(db, 'rooms');

export const getRooms = async (): Promise<Room[]> => {
  const q = query(roomsCollection, orderBy('order', 'asc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(d => {
    const data = d.data();
    return { id: d.id, ...data, createdAt: timestampToString(data.createdAt) } as Room;
  });
};

export const subscribeRooms = (callback: (rooms: Room[]) => void) => {
  const q = query(roomsCollection, orderBy('order', 'asc'));
  return onSnapshot(q, (snapshot) => {
    const rooms = snapshot.docs.map(d => {
      const data = d.data();
      return { id: d.id, ...data, createdAt: timestampToString(data.createdAt) } as Room;
    });
    callback(rooms);
  });
};

export const addRoom = async (data: Omit<Room, 'id' | 'createdAt'>): Promise<string> => {
  const docRef = await addDoc(roomsCollection, { ...data, createdAt: serverTimestamp() });
  return docRef.id;
};

export const updateRoom = async (id: string, data: Partial<Room>): Promise<void> => {
  await updateDoc(doc(db, 'rooms', id), data);
};

export const deleteRoom = async (id: string): Promise<void> => {
  await deleteDoc(doc(db, 'rooms', id));
};

// Posts
export const postsCollection = collection(db, 'posts');

export const getPosts = async (roomId?: string): Promise<Post[]> => {
  let q = query(postsCollection, orderBy('createdAt', 'desc'));
  if (roomId) {
    q = query(postsCollection, where('roomId', '==', roomId), orderBy('createdAt', 'desc'));
  }
  const snapshot = await getDocs(q);
  return snapshot.docs.map(d => {
    const data = d.data();
    return { id: d.id, ...data, createdAt: timestampToString(data.createdAt), updatedAt: timestampToString(data.updatedAt) } as Post;
  });
};

export const subscribePosts = (roomId: string | undefined, callback: (posts: Post[]) => void) => {
  let q = query(postsCollection, orderBy('createdAt', 'desc'));
  if (roomId) {
    q = query(postsCollection, where('roomId', '==', roomId), orderBy('createdAt', 'desc'));
  }
  return onSnapshot(q, (snapshot) => {
    const posts = snapshot.docs.map(d => {
      const data = d.data();
      return { id: d.id, ...data, createdAt: timestampToString(data.createdAt), updatedAt: timestampToString(data.updatedAt) } as Post;
    });
    callback(posts);
  });
};

export const addPost = async (data: Omit<Post, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> => {
  const docRef = await addDoc(postsCollection, addTimestamps(data));
  return docRef.id;
};

export const updatePost = async (id: string, data: Partial<Post>): Promise<void> => {
  await updateDoc(doc(db, 'posts', id), updateTimestamps(data));
};

export const deletePost = async (id: string): Promise<void> => {
  await deleteDoc(doc(db, 'posts', id));
};

// Bookings
export const bookingsCollection = collection(db, 'bookings');

export const getBookings = async (status?: string): Promise<Booking[]> => {
  let q = query(bookingsCollection, orderBy('createdAt', 'desc'));
  if (status) {
    q = query(bookingsCollection, where('status', '==', status), orderBy('createdAt', 'desc'));
  }
  const snapshot = await getDocs(q);
  return snapshot.docs.map(d => {
    const data = d.data();
    return { id: d.id, ...data, createdAt: timestampToString(data.createdAt), updatedAt: timestampToString(data.updatedAt) } as Booking;
  });
};

export const subscribeBookings = (callback: (bookings: Booking[]) => void) => {
  const q = query(bookingsCollection, orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const bookings = snapshot.docs.map(d => {
      const data = d.data();
      return { id: d.id, ...data, createdAt: timestampToString(data.createdAt), updatedAt: timestampToString(data.updatedAt) } as Booking;
    });
    callback(bookings);
  });
};

export const addBooking = async (data: Omit<Booking, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> => {
  const docRef = await addDoc(bookingsCollection, addTimestamps(data));
  return docRef.id;
};

export const updateBooking = async (id: string, data: Partial<Booking>): Promise<void> => {
  await updateDoc(doc(db, 'bookings', id), updateTimestamps(data));
};

export const deleteBooking = async (id: string): Promise<void> => {
  await deleteDoc(doc(db, 'bookings', id));
};

// Reviews
export const reviewsCollection = collection(db, 'reviews');

export const getReviews = async (type?: string): Promise<Review[]> => {
  let q = query(reviewsCollection, orderBy('createdAt', 'desc'));
  if (type) {
    q = query(reviewsCollection, where('type', '==', type), orderBy('createdAt', 'desc'));
  }
  const snapshot = await getDocs(q);
  return snapshot.docs.map(d => {
    const data = d.data();
    return { id: d.id, ...data, createdAt: timestampToString(data.createdAt) } as Review;
  });
};

export const subscribeReviews = (callback: (reviews: Review[]) => void) => {
  const q = query(reviewsCollection, orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const reviews = snapshot.docs.map(d => {
      const data = d.data();
      return { id: d.id, ...data, createdAt: timestampToString(data.createdAt) } as Review;
    });
    callback(reviews);
  });
};

export const addReview = async (data: Omit<Review, 'id' | 'createdAt'>): Promise<string> => {
  const docRef = await addDoc(reviewsCollection, { ...data, createdAt: serverTimestamp() });
  return docRef.id;
};

export const updateReview = async (id: string, data: Partial<Review>): Promise<void> => {
  await updateDoc(doc(db, 'reviews', id), data);
};

export const deleteReview = async (id: string): Promise<void> => {
  await deleteDoc(doc(db, 'reviews', id));
};

// Users
export const usersCollection = collection(db, 'users');

export const getUsers = async (): Promise<User[]> => {
  const q = query(usersCollection, orderBy('createdAt', 'desc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(d => {
    const data = d.data();
    return { id: d.id, ...data, createdAt: timestampToString(data.createdAt) } as User;
  });
};

export const subscribeUsers = (callback: (users: User[]) => void) => {
  const q = query(usersCollection, orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const users = snapshot.docs.map(d => {
      const data = d.data();
      return { id: d.id, ...data, createdAt: timestampToString(data.createdAt) } as User;
    });
    callback(users);
  });
};

export const addUser = async (data: Omit<User, 'id' | 'createdAt'>): Promise<string> => {
  const docRef = await addDoc(usersCollection, { ...data, createdAt: serverTimestamp() });
  return docRef.id;
};

export const updateUser = async (id: string, data: Partial<User>): Promise<void> => {
  await updateDoc(doc(db, 'users', id), data);
};

export const deleteUser = async (id: string): Promise<void> => {
  await deleteDoc(doc(db, 'users', id));
};

// Collaborations
export const collaborationsCollection = collection(db, 'collaborations');

export const getCollaborations = async (status?: string): Promise<Collaboration[]> => {
  let q = query(collaborationsCollection, orderBy('createdAt', 'desc'));
  if (status) {
    q = query(collaborationsCollection, where('status', '==', status), orderBy('createdAt', 'desc'));
  }
  const snapshot = await getDocs(q);
  return snapshot.docs.map(d => {
    const data = d.data();
    return { id: d.id, ...data, createdAt: timestampToString(data.createdAt), updatedAt: timestampToString(data.updatedAt) } as Collaboration;
  });
};

export const subscribeCollaborations = (callback: (collabs: Collaboration[]) => void) => {
  const q = query(collaborationsCollection, orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const collabs = snapshot.docs.map(d => {
      const data = d.data();
      return { id: d.id, ...data, createdAt: timestampToString(data.createdAt), updatedAt: timestampToString(data.updatedAt) } as Collaboration;
    });
    callback(collabs);
  });
};

export const addCollaboration = async (data: Omit<Collaboration, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> => {
  const docRef = await addDoc(collaborationsCollection, addTimestamps(data));
  return docRef.id;
};

export const updateCollaboration = async (id: string, data: Partial<Collaboration>): Promise<void> => {
  await updateDoc(doc(db, 'collaborations', id), updateTimestamps(data));
};

export const deleteCollaboration = async (id: string): Promise<void> => {
  await deleteDoc(doc(db, 'collaborations', id));
};

// Notifications
export const notificationsCollection = collection(db, 'notifications');

export const getNotifications = async (userId?: string): Promise<Notification[]> => {
  let q = query(notificationsCollection, orderBy('createdAt', 'desc'));
  if (userId) {
    q = query(notificationsCollection, where('userId', '==', userId), orderBy('createdAt', 'desc'));
  }
  const snapshot = await getDocs(q);
  return snapshot.docs.map(d => {
    const data = d.data();
    return { id: d.id, ...data, createdAt: timestampToString(data.createdAt) } as Notification;
  });
};

export const subscribeNotifications = (userId: string, callback: (notifs: Notification[]) => void) => {
  const q = query(notificationsCollection, where('userId', '==', userId), orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const notifs = snapshot.docs.map(d => {
      const data = d.data();
      return { id: d.id, ...data, createdAt: timestampToString(data.createdAt) } as Notification;
    });
    callback(notifs);
  });
};

export const addNotification = async (data: Omit<Notification, 'id' | 'createdAt'>): Promise<string> => {
  const docRef = await addDoc(notificationsCollection, { ...data, createdAt: serverTimestamp() });
  return docRef.id;
};

export const markNotificationRead = async (id: string): Promise<void> => {
  await updateDoc(doc(db, 'notifications', id), { isRead: true });
};

// Site Settings
export const getSiteSettings = async (): Promise<SiteSettings | null> => {
  const docRef = doc(db, 'siteSettings', 'default');
  const snapshot = await getDoc(docRef);
  if (!snapshot.exists()) return null;
  const data = snapshot.data();
  return { id: snapshot.id, ...data, updatedAt: timestampToString(data.updatedAt) } as SiteSettings;
};

export const subscribeSiteSettings = (callback: (settings: SiteSettings | null) => void) => {
  const docRef = doc(db, 'siteSettings', 'default');
  return onSnapshot(docRef, (snapshot) => {
    if (!snapshot.exists()) {
      callback(null);
      return;
    }
    const data = snapshot.data();
    callback({ id: snapshot.id, ...data, updatedAt: timestampToString(data.updatedAt) } as SiteSettings);
  });
};

export const updateSiteSettings = async (data: Partial<SiteSettings>): Promise<void> => {
  const docRef = doc(db, 'siteSettings', 'default');
  await updateDoc(docRef, { ...data, updatedAt: serverTimestamp() });
};

export const createDefaultSiteSettings = async (): Promise<void> => {
  const docRef = doc(db, 'siteSettings', 'default');
  const snapshot = await getDoc(docRef);
  if (!snapshot.exists()) {
    await updateDoc(docRef, {
      id: 'default',
      logo: '',
      siteName: 'Bessghaier Holding',
      contactEmail: 'contact@bessghaier.com',
      contactPhone: '',
      whatsappNumber: '21692644215',
      rulesContent: '<h2>Collaboration Rules</h2><p>Please read and accept our terms before applying.</p>',
      socialLinks: { facebook: '', instagram: '', linkedin: '', youtube: '' },
      updatedAt: serverTimestamp(),
    });
  }
};
