import { db } from './firebase';
import { doc, setDoc, collection, addDoc, serverTimestamp, getDocs } from 'firebase/firestore';

const seedIfEmpty = async (collectionName: string, seedFn: () => Promise<void>) => {
  const snapshot = await getDocs(collection(db, collectionName));
  if (snapshot.empty) {
    await seedFn();
    console.log(`Seeded ${collectionName}`);
  }
};

export const seedAllData = async () => {
  try {
    // Site Settings
    await setDoc(doc(db, 'siteSettings', 'default'), {
      id: 'default',
      logo: '',
      siteName: 'Bessghaier Holding',
      contactEmail: 'contact@bessghaier.com',
      contactPhone: '+216 92 644 215',
      whatsappNumber: '21692644215',
      rulesContent: `<h2 style="color: #C9A84C; font-size: 24px; margin-bottom: 16px;">Bessghaier Holding - Collaboration Rules</h2>
<h3 style="color: #E5C76B; font-size: 18px; margin: 20px 0 12px;">1. General Terms</h3>
<p>By applying for collaboration with Bessghaier Holding, you agree to the following terms and conditions. These rules are designed to ensure a professional and mutually beneficial partnership.</p>
<h3 style="color: #E5C76B; font-size: 18px; margin: 20px 0 12px;">2. Eligibility</h3>
<ul style="margin-left: 20px; line-height: 1.8;">
<li>Must be at least 18 years old</li>
<li>Must provide accurate personal and contact information</li>
<li>Must have a valid WhatsApp number for communication</li>
</ul>
<h3 style="color: #E5C76B; font-size: 18px; margin: 20px 0 12px;">3. Collaboration Process</h3>
<ul style="margin-left: 20px; line-height: 1.8;">
<li>Submit your application with complete details</li>
<li>Review and accept the collaboration rules</li>
<li>Provide your digital signature as confirmation</li>
<li>Wait for admin review and approval</li>
<li>Upon approval, payment terms will be communicated</li>
</ul>
<h3 style="color: #E5C76B; font-size: 18px; margin: 20px 0 12px;">4. Payment Terms</h3>
<p>Payment details and collaboration fees will be discussed individually after application review. All payments must be completed before collaboration begins.</p>
<h3 style="color: #E5C76B; font-size: 18px; margin: 20px 0 12px;">5. Communication</h3>
<p>All official communication will be through WhatsApp and the messaging system on this platform. Response time is typically within 24-48 hours.</p>
<h3 style="color: #E5C76B; font-size: 18px; margin: 20px 0 12px;">6. Termination</h3>
<p>Either party may terminate the collaboration with written notice. Bessghaier Holding reserves the right to terminate any collaboration that violates these rules.</p>
<p style="margin-top: 24px; padding-top: 16px; border-top: 1px solid rgba(201,168,76,0.3); color: #A0A0A0; font-size: 14px;">Last updated: 2026. Bessghaier Holding Team.</p>`,
      socialLinks: {
        facebook: 'https://facebook.com/bessghaier',
        instagram: 'https://instagram.com/bessghaier',
        linkedin: 'https://linkedin.com/company/bessghaier',
        youtube: 'https://youtube.com/bessghaier',
      },
      updatedAt: serverTimestamp(),
    }).catch(() => {});

    // Properties
    await seedIfEmpty('properties', async () => {
      const propertiesRef = collection(db, 'properties');
      await addDoc(propertiesRef, {
        title: 'Luxury Villa in Sidi Bou Said',
        description: 'Stunning 4-bedroom villa with panoramic sea views, private pool, and modern amenities. Perfect for families or luxury vacation rentals.',
        price: 2500,
        location: 'Sidi Bou Said, Tunisia',
        type: 'rent',
        status: 'available',
        images: ['https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800&q=80'],
        features: ['4 Bedrooms', '3 Bathrooms', 'Private Pool', 'Sea View', 'Garden'],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await addDoc(propertiesRef, {
        title: 'Modern Apartment in La Marsa',
        description: 'Beautiful 2-bedroom apartment in the heart of La Marsa. Close to beaches, restaurants, and shops. Fully furnished.',
        price: 800,
        location: 'La Marsa, Tunisia',
        type: 'rent',
        status: 'available',
        images: ['https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&q=80'],
        features: ['2 Bedrooms', '2 Bathrooms', 'Furnished', 'Near Beach', 'Parking'],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await addDoc(propertiesRef, {
        title: 'Beachfront Property for Sale',
        description: 'Prime beachfront land with building permit. Perfect for hotel or residential development. 2000 sqm.',
        price: 450000,
        location: 'Hammamet, Tunisia',
        type: 'sale',
        status: 'available',
        images: ['https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=80'],
        features: ['2000 sqm', 'Beachfront', 'Building Permit', 'Investment'],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await addDoc(propertiesRef, {
        title: 'Desert Camp Property',
        description: 'Unique desert camp property in Tozeur. Ready for tourism business with existing infrastructure.',
        price: 180000,
        location: 'Tozeur, Tunisia',
        type: 'sale',
        status: 'available',
        images: ['https://images.unsplash.com/photo-1542259681-d91182a5334d?w=800&q=80'],
        features: ['Desert Camp', 'Tourism Ready', 'Infrastructure', 'Investment'],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await addDoc(propertiesRef, {
        title: 'Cozy Studio in Tunis Center',
        description: 'Fully furnished studio apartment in the center of Tunis. Ideal for short-term rentals.',
        price: 350,
        location: 'Tunis, Tunisia',
        type: 'rent',
        status: 'reserved',
        images: ['https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&q=80'],
        features: ['Studio', 'Furnished', 'City Center', 'WiFi'],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    });

    // Books
    await seedIfEmpty('books', async () => {
      const booksRef = collection(db, 'books');
      await addDoc(booksRef, {
        title: 'The Art of Investment',
        description: 'A comprehensive guide to real estate investment strategies in North Africa. Learn how to build wealth through property investment.',
        price: 19.99,
        currency: 'USD',
        image: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&q=80',
        kindleLink: 'https://amazon.com/kindle',
        author: 'Ahmed Bessghaier',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await addDoc(booksRef, {
        title: 'Desert Tourism Guide',
        description: 'Discover the magic of Tunisian desert tourism. From planning to execution, this book covers everything you need to know.',
        price: 14.99,
        currency: 'USD',
        image: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&q=80',
        kindleLink: 'https://amazon.com/kindle',
        author: 'Sara Bessghaier',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await addDoc(booksRef, {
        title: 'Digital Marketing Mastery',
        description: 'Master the art of digital marketing. From social media to influencer partnerships, learn strategies that actually work.',
        price: 24.99,
        currency: 'USD',
        image: 'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=400&q=80',
        kindleLink: 'https://amazon.com/kindle',
        author: 'Mohamed Bessghaier',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    });

    // Rooms
    await seedIfEmpty('rooms', async () => {
      const roomsRef = collection(db, 'rooms');
      await addDoc(roomsRef, { name: 'Publishing', slug: 'publishing', description: 'Book publishing news and updates', icon: 'BookOpen', order: 1, isActive: true, createdAt: serverTimestamp() });
      await addDoc(roomsRef, { name: 'Real Estate', slug: 'real-estate', description: 'Property listings and market news', icon: 'Home', order: 2, isActive: true, createdAt: serverTimestamp() });
      await addDoc(roomsRef, { name: 'Travel', slug: 'travel', description: 'Desert tourism and travel packages', icon: 'Plane', order: 3, isActive: true, createdAt: serverTimestamp() });
      await addDoc(roomsRef, { name: 'Consulting', slug: 'consulting', description: 'Business consulting insights', icon: 'TrendingUp', order: 4, isActive: true, createdAt: serverTimestamp() });
      await addDoc(roomsRef, { name: 'Marketing', slug: 'marketing', description: 'Marketing strategies and tips', icon: 'Megaphone', order: 5, isActive: true, createdAt: serverTimestamp() });
    });

    // Posts
    await seedIfEmpty('posts', async () => {
      const postsRef = collection(db, 'posts');
      await addDoc(postsRef, {
        roomId: '',
        title: 'New Book Published: The Art of Investment',
        content: 'We are excited to announce the publication of our latest book "The Art of Investment" by Ahmed Bessghaier. This comprehensive guide covers real estate investment strategies in North Africa. Available now on Amazon Kindle.',
        images: ['https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=800&q=80'],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await addDoc(postsRef, {
        roomId: '',
        title: 'Summer Travel Packages Now Available',
        content: 'Plan your desert adventure with our exclusive summer packages. Full package tours, guide-only options, and private house rentals available at competitive prices.',
        images: ['https://images.unsplash.com/photo-1509316785289-025f5b846b35?w=800&q=80'],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await addDoc(postsRef, {
        roomId: '',
        title: 'New Luxury Villa Listed in Sidi Bou Said',
        content: 'A stunning 4-bedroom villa with panoramic sea views and private pool is now available for rent. Book your stay today!',
        images: ['https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800&q=80'],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    });

    // Reviews
    await seedIfEmpty('reviews', async () => {
      const reviewsRef = collection(db, 'reviews');
      await addDoc(reviewsRef, {
        type: 'general',
        targetId: '',
        name: 'Khaled M.',
        email: 'khaled@email.com',
        rating: 5,
        comment: 'Excellent service! The team at Bessghaier Holding helped me find the perfect property. Highly recommended!',
        isApproved: true,
        createdAt: serverTimestamp(),
      });
      await addDoc(reviewsRef, {
        type: 'general',
        targetId: '',
        name: 'Fatima B.',
        email: 'fatima@email.com',
        rating: 5,
        comment: 'Amazing desert travel experience. Everything was perfectly organized from start to finish. Will definitely book again!',
        isApproved: true,
        createdAt: serverTimestamp(),
      });
      await addDoc(reviewsRef, {
        type: 'general',
        targetId: '',
        name: 'Youssef A.',
        email: 'youssef@email.com',
        rating: 4,
        comment: 'Great consulting services. They helped increase our revenue by 25% in just 3 months.',
        isApproved: true,
        createdAt: serverTimestamp(),
      });
    });

    // Demo Bookings
    await seedIfEmpty('bookings', async () => {
      const bookingsRef = collection(db, 'bookings');
      await addDoc(bookingsRef, {
        propertyId: 'demo1',
        propertyTitle: 'Luxury Villa in Sidi Bou Said',
        name: 'John Smith',
        phone: '+44 7700 900123',
        email: 'john@email.com',
        checkIn: '2026-07-15',
        checkOut: '2026-07-22',
        message: 'Looking forward to our stay!',
        status: 'pending',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await addDoc(bookingsRef, {
        propertyId: 'demo2',
        propertyTitle: 'Modern Apartment in La Marsa',
        name: 'Marie Dubois',
        phone: '+33 6 12 34 56 78',
        email: 'marie@email.com',
        checkIn: '2026-08-01',
        checkOut: '2026-08-10',
        message: 'Business trip, need quiet place.',
        status: 'approved',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    });

    // Demo Collaborations
    await seedIfEmpty('collaborations', async () => {
      const collabsRef = collection(db, 'collaborations');
      await addDoc(collabsRef, {
        name: 'Ali Hassan',
        email: 'ali@email.com',
        phone: '+216 98 765 432',
        whatsapp: '21698765432',
        status: 'applied',
        rulesAccepted: false,
        signatureData: '',
        price: 0,
        rulesContent: '',
        adminNotes: '',
        messages: [],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await addDoc(collabsRef, {
        name: 'Sarah Johnson',
        email: 'sarah@email.com',
        phone: '+1 555 123 4567',
        whatsapp: '15551234567',
        status: 'price_set',
        rulesAccepted: true,
        signatureData: '',
        price: 500,
        rulesContent: 'Collaboration rules accepted',
        adminNotes: 'Publishing collaboration for new book',
        messages: [
          { sender: 'admin', text: 'Welcome! We have reviewed your application and set a collaboration price of $500.', timestamp: new Date(Date.now() - 86400000).toISOString() }
        ],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    });

    console.log('All demo data seeded successfully');
  } catch (error) {
    console.error('Error seeding data:', error);
  }
};
