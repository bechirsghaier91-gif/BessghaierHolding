import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
    Globe,
    Home,
    Phone,
    BookOpen,
    Building2,
    Plane,
    TrendingUp,
    Megaphone,
    Star,
    Bell,
    Gavel,
    Newspaper,
    TreePalm,
    Mountain,
    Waves,
    Binoculars,
    Landmark,
    Clapperboard,
    Mail,
    Instagram,
    Facebook,
    User,
    Star as StarIcon,
    Pen,
    Send,
    Calendar,
    Check
} from 'lucide-react';
import WhatsAppIcon from '@/components/WhatsAppIcon';

export default function HomePage() {
    const [rating, setRating] = useState(0);
    const [reviewName, setReviewName] = useState('');
    const [reviewText, setReviewText] = useState('');
    const [reviews, setReviews] = useState([
        { stars: 5, text: 'Excellent service! The real estate team helped me find my dream home in Tozeur. Highly recommended!', author: 'Ahmed K.', date: 'January 2026' },
        { stars: 5, text: 'Amazing desert tour with Djerid Travel! The full package was worth every penny. Will definitely come back!', author: 'Sarah M.', date: 'December 2025' },
        { stars: 4, text: 'Professional publishing service. My book is now available on Amazon thanks to Bessghaier Publishing!', author: 'Mohamed B.', date: 'November 2025' },
    ]);

    const handleSubmitReview = () => {
        if (!reviewName || !reviewText || rating === 0) {
            alert('Please fill all fields and select a rating!');
            return;
        }
        setReviews([...reviews, { stars: rating, text: reviewText, author: reviewName, date: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) }]);
        setReviewName('');
        setReviewText('');
        setRating(0);
    };

    const rooms = [
        {
            icon: <BookOpen size={32} className="text-[var(--gold)]" />,
            badge: 'Publishing',
            title: 'Bessghaier Publishing',
            desc: 'Amazon Kindle Publishing with dedicated marketing. Paperback copies available!',
            features: ['Amazon Kindle Publishing', 'Dedicated Marketing', 'Paperback Available', 'Global Distribution'],
            link: '/books'
        },
        {
            icon: <Building2 size={32} className="text-[var(--gold)]" />,
            badge: 'Real Estate',
            title: 'Company Bechir Real Estate',
            desc: 'Complete real estate services: Sales, Rentals, and Property Management.',
            features: ['Property Sales', 'Rental Booking System', 'Date Selection', 'Email Notifications'],
            link: '/real-estate'
        },
        {
            icon: <Plane size={32} className="text-[var(--gold)]" />,
            badge: 'Travel',
            title: 'Djerid Travel',
            desc: 'Desert tourism with multiple options: Full Package, Guide Only, and more!',
            features: ['Full Package Tours', 'Guide Only', 'Airport Transfer', 'Private House'],
            link: '/travel'
        },
        {
            icon: <TrendingUp size={32} className="text-[var(--gold)]" />,
            badge: 'Consulting',
            title: 'Business Consulting',
            desc: 'Improve revenue from 10% to over 40%. Expert consulting for all projects!',
            features: ['Revenue Optimization', '10% to 40%+ Growth', 'All Project Types', 'Expert Analysis'],
            link: '/consulting'
        },
        {
            icon: <Megaphone size={32} className="text-[var(--gold)]" />,
            badge: 'Marketing',
            title: 'Marketing & Influencers',
            desc: 'Professional marketing with well-known influencers for any brand!',
            features: ['Influencer Marketing', 'Brand Promotion', 'Social Media', 'Global Reach'],
            link: '/marketing'
        },
        {
            icon: <Star size={32} className="text-[var(--gold)]" />,
            badge: 'Dedicated',
            title: 'Dedicated For You',
            desc: 'Want a dedicated website? Your name will appear here! Contact us.',
            features: ['Custom Solutions', 'Your Brand Name', 'Full Integration', 'Premium Support'],
            link: '/magazine'
        },
        {
            icon: <Bell size={32} className="text-[var(--dark)]" />,
            badge: 'What is New',
            title: 'What is New',
            isGold: true,
            desc: 'Stay updated with our latest news, deals, and announcements directly on WhatsApp!',
            features: ['Latest Updates & News', 'Exclusive Deals', 'New Properties Alerts', 'Special Offers'],
            link: null
        },
        {
            icon: <Gavel size={32} className="text-[var(--gold)]" />,
            badge: 'Rules & Collab',
            title: 'Collaboration Rules',
            isRules: true,
            desc: 'Terms and conditions for partners, collaborators, and business associates.',
            features: [],
            link: '/rules'
        },
    ];

    const destinations = [
        { tag: 'Tozeur', icon: <TreePalm size={16} />, title: 'Tozeur Oasis', desc: 'Famous palm oasis with natural beauty and rich history.' },
        { tag: 'Nefta', icon: <Mountain size={16} />, title: 'Nefta', desc: 'City of palms and cultural heritage. Gateway to the Sahara.' },
        { tag: 'Landscape', icon: <Waves size={16} />, title: 'Chott el Djerid', desc: 'Largest salt lake in the Tunisian desert.' },
        { tag: 'Adventure', icon: <Binoculars size={16} />, title: 'Desert Safari', desc: 'Explore the magic of the Tunisian Sahara.' },
        { tag: 'Heritage', icon: <Landmark size={16} />, title: 'Traditional Architecture', desc: 'Unique traditional architecture of Tozeur and Nefta.' },
        { tag: 'Cinema', icon: <Clapperboard size={16} />, title: 'Star Wars Locations', desc: 'Visit famous Star Wars filming locations in Tozeur.' },
    ];

    return (
        <div>
            {/* Hero */}
            <section className="min-h-screen flex items-center justify-center text-center bg-[radial-gradient(ellipse_at_20%_50%,rgba(201,169,110,0.08)_0%,transparent_50%),radial-gradient(ellipse_at_80%_20%,rgba(201,169,110,0.05)_0%,transparent_40%),var(--darker)] pt-20 px-8 relative">
                <div>
                    <div className="inline-flex items-center gap-2 bg-[var(--gold)]/10 border border-[var(--gold)]/20 px-5 py-2 rounded-full text-xs text-[var(--gold)] mb-6">
                        <Globe size={14} /> Global Investments - International
                    </div>
                    <h1 className="text-4xl sm:text-5xl md:text-7xl font-extrabold leading-tight mb-6 bg-gradient-to-br from-white via-[var(--gold-light)] to-[var(--gold)] bg-clip-text text-transparent" style={{ fontFamily: "'Playfair Display', serif" }}>
                        Building the Future<br />
                        <span className="text-[var(--gold)]">With Excellence</span>
                    </h1>
                    <p className="text-[var(--text-muted)] max-w-[600px] mx-auto mb-8 text-base md:text-lg">
                        Bessghaier Holding is a multi-activity entity combining real estate investment, publishing, and desert tourism. We create added value in every project.
                    </p>
                    <div className="flex gap-4 justify-center flex-wrap">
                        <Link to="/real-estate" className="btn-gold">
                            <Home size={16} /> Explore Properties
                        </Link>
                        <a href="#contact" className="btn-outline">
                            <Phone size={16} /> Contact Us
                        </a>
                    </div>
                </div>
            </section>

            {/* About */}
            <section id="about" className="py-20 px-8">
                <div className="text-center mb-12">
                    <span className="section-label">ABOUT US</span>
                    <h2 className="section-title">Bessghaier Holding</h2>
                    <div className="gold-line" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-[1200px] mx-auto items-center">
                    <div className="h-[300px] md:h-[400px] bg-[var(--dark-surface)] rounded-2xl flex items-center justify-center border border-[var(--gold)]/10 relative overflow-hidden">
                        <img src="https://i.postimg.cc/jS0wHFYF/IMG-1699.jpg" alt="Bessghaier Holding" className="w-40 h-40 md:w-52 md:h-52 rounded-full object-cover border-3 border-[var(--gold)] shadow-[0_10px_40px_rgba(201,169,110,0.3)]" />
                    </div>
                    <div>
                        <h3 className="text-2xl md:text-3xl mb-5 text-white font-bold">Integrated Investment Vision</h3>
                        <p className="text-[var(--text-muted)] mb-4 text-base leading-relaxed">
                            Bessghaier Holding was founded to diversify investments and provide integrated services in real estate, publishing, and tourism.
                        </p>
                        <p className="text-[var(--text-muted)] mb-4 text-base leading-relaxed">
                            We aim to be a leader in the Tunisian and international markets, through innovative solutions and high-quality services.
                        </p>
                        <div className="grid grid-cols-3 gap-4 mt-8">
                            <div className="text-center p-5 bg-[var(--dark-card)] rounded-2xl border border-[var(--gold)]/[0.08]">
                                <div className="text-2xl font-bold text-[var(--gold)]">+3</div>
                                <div className="text-[var(--text-dim)] text-xs mt-2">Subsidiaries</div>
                            </div>
                            <div className="text-center p-5 bg-[var(--dark-card)] rounded-2xl border border-[var(--gold)]/[0.08]">
                                <div className="text-2xl font-bold text-[var(--gold)]">+500</div>
                                <div className="text-[var(--text-dim)] text-xs mt-2">Happy Clients</div>
                            </div>
                            <div className="text-center p-5 bg-[var(--dark-card)] rounded-2xl border border-[var(--gold)]/[0.08]">
                                <div className="text-2xl font-bold text-[var(--gold)]">+10</div>
                                <div className="text-[var(--text-dim)] text-xs mt-2">Years Exp.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Rooms */}
            <section id="rooms" className="py-20 px-8 bg-[var(--darker)]">
                <div className="text-center mb-12">
                    <span className="section-label">OUR ROOMS</span>
                    <h2 className="section-title">Specialized Rooms</h2>
                    <div className="gold-line" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-[1200px] mx-auto">
                    {rooms.map((room, i) => (
                        <div key={i} className="card-dark">
                            <div className={`h-[160px] flex items-center justify-center relative ${
                                room.isGold
                                    ? 'bg-gradient-to-br from-[var(--gold)] to-[var(--gold-light)]'
                                    : room.isRules
                                    ? 'bg-gradient-to-br from-[#2c1810] to-[#4a2c1a]'
                                    : 'bg-gradient-to-br from-[#1a1a1a] to-[#2d2d2d]'
                            }`}>
                                <div className="text-4xl">{room.icon}</div>
                                <div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-[0.65rem] font-semibold ${
                                    room.isGold ? 'bg-black/20 text-[var(--dark)]' : 'bg-[var(--gold)]/15 text-[var(--gold)]'
                                }`}>
                                    {room.badge}
                                </div>
                            </div>
                            <div className="p-6">
                                <h3 className="text-lg mb-3 text-white font-semibold">{room.title}</h3>
                                <p className="text-[var(--text-muted)] text-sm mb-4 leading-relaxed">{room.desc}</p>
                                {room.features.length > 0 && (
                                    <ul className="list-none mb-5">
                                        {room.features.map((f, j) => (
                                            <li key={j} className="flex items-center gap-2 text-[var(--text-muted)] text-xs mb-2">
                                                <Check size={12} className="text-[var(--gold)] font-bold" /> {f}
                                            </li>
                                        ))}
                                    </ul>
                                )}
                                <div className="flex gap-2 flex-wrap">
                                    {room.link ? (
                                        <Link to={room.link} className="btn-gold text-xs py-2 px-4">
                                            View Details
                                        </Link>
                                    ) : (
                                        <button onClick={() => alert('Coming soon!')} className="btn-gold text-xs py-2 px-4">
                                            <Bell size={12} /> Subscribe
                                        </button>
                                    )}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            {/* Magazine */}
            <section id="magazine" className="py-20 px-8 bg-[var(--dark)]">
                <div className="text-center mb-12">
                    <span className="section-label">MAGAZINE</span>
                    <h2 className="section-title">Bessghaier Magazine</h2>
                    <div className="gold-line" />
                </div>
                <div className="card-dark max-w-[1200px] mx-auto">
                    <div className="h-[160px] bg-gradient-to-br from-[#1a1a1a] to-[#2d2d2d] flex items-center justify-center relative">
                        <Newspaper size={48} className="text-[var(--gold)]" />
                        <div className="absolute top-4 right-4 bg-[var(--gold)]/15 px-3 py-1 rounded-full text-[0.65rem] text-[var(--gold)] font-semibold">
                            Coming Soon
                        </div>
                    </div>
                    <div className="p-8 text-center">
                        <h3 className="text-xl text-white mb-4">All in One Place</h3>
                        <p className="text-[var(--text-muted)] mb-5">
                            Find all properties for sale, ongoing projects, tourism experiences, and investment opportunities with Bessghaier Holding!
                        </p>
                        <p className="text-[var(--gold)] text-sm mb-6">
                            <Calendar size={14} className="inline mr-2" /> Launching Soon - Stay Tuned!
                        </p>
                        <Link to="/magazine" className="btn-gold">
                            <Bell size={16} /> Get Notified
                        </Link>
                    </div>
                </div>
            </section>

            {/* Team */}
            <section id="team" className="py-20 px-8">
                <div className="text-center mb-12">
                    <span className="section-label">OUR TEAM</span>
                    <h2 className="section-title">Meet The Team</h2>
                    <p className="text-[var(--text-muted)] text-center max-w-[600px] mx-auto">Dedicated to excellence</p>
                    <div className="gold-line" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-[800px] mx-auto">
                    <div className="bg-[var(--dark-card)] rounded-2xl p-8 text-center border border-[var(--gold)]/[0.08] transition-all hover:-translate-y-1 hover:border-[var(--gold)]/20 hover:shadow-[0_15px_40px_rgba(0,0,0,0.3)]">
                        <div className="w-20 h-20 rounded-full bg-[var(--dark-surface)] flex items-center justify-center mx-auto mb-4 border-2 border-[var(--gold)] text-3xl text-[var(--gold)]">
                            <User size={32} />
                        </div>
                        <h4 className="text-white text-lg mb-1">Aziz Mazioud</h4>
                        <div className="text-[var(--gold)] text-sm font-semibold mb-3">Influencers Manager</div>
                        <p className="text-[var(--text-muted)] text-sm">Managing our network of influencers and brand partnerships</p>
                    </div>
                    <div className="bg-[var(--dark-card)] rounded-2xl p-8 text-center border border-[var(--gold)]/[0.08] transition-all hover:-translate-y-1 hover:border-[var(--gold)]/20 hover:shadow-[0_15px_40px_rgba(0,0,0,0.3)]">
                        <div className="w-20 h-20 rounded-full bg-[var(--dark-surface)] flex items-center justify-center mx-auto mb-4 border-2 border-[var(--gold)] text-3xl text-[var(--gold)]">
                            <SettingsIcon />
                        </div>
                        <h4 className="text-white text-lg mb-1">Ramzi Bouchrit</h4>
                        <div className="text-[var(--gold)] text-sm font-semibold mb-3">Configuration Team</div>
                        <p className="text-[var(--text-muted)] text-sm">Technical configuration and system management expert</p>
                    </div>
                </div>
            </section>

            {/* Reviews */}
            <section id="reviews" className="py-20 px-8 bg-[var(--darker)]">
                <div className="text-center mb-12">
                    <span className="section-label">REVIEWS</span>
                    <h2 className="section-title">Customer Reviews</h2>
                    <p className="text-[var(--text-muted)] text-center max-w-[600px] mx-auto">See what our clients say about us</p>
                    <div className="gold-line" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-5 max-w-[1200px] mx-auto mb-10">
                    {reviews.map((review, i) => (
                        <div key={i} className="bg-[var(--dark-card)] rounded-2xl p-6 border border-[var(--gold)]/[0.08]">
                            <div className="text-[var(--gold)] mb-4 text-sm flex gap-1">
                                {[...Array(5)].map((_, j) => (
                                    <StarIcon key={j} size={16} className={j < review.stars ? 'fill-[var(--gold)]' : 'text-[var(--text-dim)]'} />
                                ))}
                            </div>
                            <p className="text-[var(--text-muted)] text-sm leading-relaxed mb-4">{review.text}</p>
                            <div className="text-white font-semibold text-sm">{review.author}</div>
                            <div className="text-[var(--text-dim)] text-xs mt-1">{review.date}</div>
                        </div>
                    ))}
                </div>
                <div className="bg-[var(--dark-card)] rounded-2xl p-8 max-w-[600px] mx-auto border border-[var(--gold)]/[0.08]">
                    <h3 className="text-white text-center mb-5 text-lg flex items-center justify-center gap-2">
                        <Pen size={18} /> Leave a Review
                    </h3>
                    <div className="flex gap-2 justify-center mb-5">
                        {[1, 2, 3, 4, 5].map(r => (
                            <button key={r} onClick={() => setRating(r)} className="bg-transparent border-none cursor-pointer">
                                <StarIcon size={24} className={r <= rating ? 'text-[var(--gold)] fill-[var(--gold)]' : 'text-[var(--text-dim)]'} />
                            </button>
                        ))}
                    </div>
                    <div className="mb-4">
                        <input
                            type="text"
                            placeholder="Your Name"
                            value={reviewName}
                            onChange={e => setReviewName(e.target.value)}
                            className="w-full px-4 py-3 bg-[var(--dark-surface)] border border-white/8 rounded-xl text-[var(--text)] font-inherit text-sm outline-none focus:border-[var(--gold)]"
                        />
                    </div>
                    <div className="mb-4">
                        <textarea
                            placeholder="Write your review..."
                            value={reviewText}
                            onChange={e => setReviewText(e.target.value)}
                            className="w-full px-4 py-3 bg-[var(--dark-surface)] border border-white/8 rounded-xl text-[var(--text)] font-inherit text-sm outline-none focus:border-[var(--gold)] min-h-[100px] resize-y"
                        />
                    </div>
                    <button onClick={handleSubmitReview} className="w-full btn-gold justify-center">
                        <Send size={16} /> Submit Review
                    </button>
                </div>
            </section>

            {/* Destinations */}
            <section id="destinations" className="py-20 px-8">
                <div className="text-center mb-12">
                    <span className="section-label">DESTINATIONS</span>
                    <h2 className="section-title">Tozeur & Nefta</h2>
                    <div className="gold-line" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 max-w-[1200px] mx-auto">
                    {destinations.map((dest, i) => (
                        <div key={i} className="relative h-[250px] md:h-[300px] rounded-2xl overflow-hidden cursor-pointer bg-gradient-to-br from-[#1a1a1a] to-[#2d2d2d] transition-all hover:-translate-y-1 hover:shadow-[0_15px_40px_rgba(0,0,0,0.3)]">
                            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent flex flex-col justify-end p-6">
                                <span className="inline-block bg-[var(--gold)] text-[var(--dark)] px-3 py-1 rounded-full text-[0.65rem] font-bold mb-3 w-fit">
                                    {dest.tag}
                                </span>
                                <h4 className="text-lg text-white mb-2 flex items-center gap-2">{dest.icon} {dest.title}</h4>
                                <p className="text-[var(--text-muted)] text-sm">{dest.desc}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            {/* Contact */}
            <section id="contact" className="py-20 px-8 bg-[var(--dark)]">
                <div className="text-center mb-12">
                    <span className="section-label">CONTACT US</span>
                    <h2 className="section-title">We Are Here to Help</h2>
                    <div className="gold-line" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-[1200px] mx-auto">
                    <div>
                        <h3 className="text-2xl mb-5 text-white font-bold">Let's Start a Conversation</h3>
                        <p className="text-[var(--text-muted)] mb-8">We believe in direct communication with our clients.</p>

                        <div className="flex items-center gap-4 mb-5 p-5 bg-[var(--dark-card)] rounded-2xl border border-[var(--gold)]/[0.06] transition-all hover:border-[var(--gold)]/20">
                            <div className="w-11 h-11 min-w-[44px] bg-[var(--gold)]/10 rounded-xl flex items-center justify-center text-[var(--gold)]">
                                <WhatsAppIcon size={20} />
                            </div>
                            <div>
                                <h5 className="text-white text-sm mb-1">WhatsApp</h5>
                                <a href="https://wa.me/21692644215" target="_blank" className="text-[var(--text-muted)] text-sm no-underline hover:text-[var(--gold)] transition-colors">92644215</a>
                            </div>
                        </div>

                        <div className="flex items-center gap-4 mb-5 p-5 bg-[var(--dark-card)] rounded-2xl border border-[var(--gold)]/[0.06] transition-all hover:border-[var(--gold)]/20">
                            <div className="w-11 h-11 min-w-[44px] bg-[var(--gold)]/10 rounded-xl flex items-center justify-center text-[var(--gold)]">
                                <Mail size={20} />
                            </div>
                            <div>
                                <h5 className="text-white text-sm mb-1">Email</h5>
                                <a href="mailto:bechirsghaier91@gmail.com" className="text-[var(--text-muted)] text-sm no-underline hover:text-[var(--gold)] transition-colors">bechirsghaier91@gmail.com</a>
                            </div>
                        </div>

                        <div className="flex items-center gap-4 mb-5 p-5 bg-[var(--dark-card)] rounded-2xl border border-[var(--gold)]/[0.06] transition-all hover:border-[var(--gold)]/20">
                            <div className="w-11 h-11 min-w-[44px] bg-[var(--gold)]/10 rounded-xl flex items-center justify-center text-[var(--gold)]">
                                <Instagram size={20} />
                            </div>
                            <div>
                                <h5 className="text-white text-sm mb-1">Instagram</h5>
                                <span className="text-[var(--text-muted)] text-sm">@bessghaierholding</span>
                            </div>
                        </div>

                        <div className="flex items-center gap-4 mb-5 p-5 bg-[var(--dark-card)] rounded-2xl border border-[var(--gold)]/[0.06] transition-all hover:border-[var(--gold)]/20">
                            <div className="w-11 h-11 min-w-[44px] bg-[var(--gold)]/10 rounded-xl flex items-center justify-center text-[var(--gold)]">
                                <Facebook size={20} />
                            </div>
                            <div>
                                <h5 className="text-white text-sm mb-1">Facebook</h5>
                                <span className="text-[var(--text-muted)] text-sm">Societe bechir immobilier</span>
                            </div>
                        </div>
                    </div>

                    <div className="bg-[var(--dark-card)] p-9 rounded-3xl border border-[var(--gold)]/[0.08]">
                        <h3 className="text-[var(--gold)] mb-6 flex items-center gap-2">
                            <Send size={18} /> Send Message
                        </h3>
                        <div className="mb-4">
                            <label className="block text-[var(--text-muted)] text-sm mb-2">Full Name</label>
                            <input
                                type="text"
                                placeholder="Your name"
                                className="w-full px-4 py-3 bg-[var(--dark-surface)] border border-white/8 rounded-xl text-[var(--text)] font-inherit text-sm outline-none focus:border-[var(--gold)]"
                            />
                        </div>
                        <div className="mb-4">
                            <label className="block text-[var(--text-muted)] text-sm mb-2">Email</label>
                            <input
                                type="email"
                                placeholder="your@email.com"
                                className="w-full px-4 py-3 bg-[var(--dark-surface)] border border-white/8 rounded-xl text-[var(--text)] font-inherit text-sm outline-none focus:border-[var(--gold)]"
                            />
                        </div>
                        <div className="mb-4">
                            <label className="block text-[var(--text-muted)] text-sm mb-2">Message</label>
                            <textarea
                                placeholder="Your message..."
                                className="w-full px-4 py-3 bg-[var(--dark-surface)] border border-white/8 rounded-xl text-[var(--text)] font-inherit text-sm outline-none focus:border-[var(--gold)] min-h-[120px] resize-y"
                            />
                        </div>
                        <button className="w-full btn-gold justify-center" onClick={() => alert('Message sent! We will contact you soon.')}>
                            <Send size={16} /> Send Message
                        </button>
                    </div>
                </div>
            </section>
        </div>
    );
}

function SettingsIcon() {
    return (
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-[var(--gold)]">
            <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
            <circle cx="12" cy="12" r="3" />
        </svg>
    );
}
