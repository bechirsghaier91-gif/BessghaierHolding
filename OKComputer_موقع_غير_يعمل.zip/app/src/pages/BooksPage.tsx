import WhatsAppIcon from '@/components/WhatsAppIcon';
import { BookOpen, ShoppingCart, ExternalLink, Upload, Megaphone, Globe, Printer } from 'lucide-react';

const books = [
    { id: 1, title: 'Book Title 1', desc: 'Description of the book goes here. This is a placeholder for your Amazon Kindle book.', price: '$7.99', badge: 'Kindle' },
    { id: 2, title: 'Book Title 2', desc: 'Description of the book goes here. This is a placeholder for your Amazon Kindle book.', price: '$9.99', badge: 'Kindle' },
    { id: 3, title: 'Book Title 3', desc: 'Description of the book goes here. This is a placeholder for your Amazon Kindle book.', price: '$12.99', badge: 'Kindle' },
    { id: 4, title: 'Book Title 4', desc: 'Description of the book goes here. This is a placeholder for your paperback book.', price: '$14.99', badge: 'Paperback' },
];

const services = [
    { icon: <Upload size={28} className="text-[var(--gold)]" />, title: 'Amazon Kindle Publishing', desc: 'Professional formatting and publishing on Amazon Kindle platform.' },
    { icon: <Megaphone size={28} className="text-[var(--gold)]" />, title: 'Dedicated Marketing', desc: 'Targeted marketing campaigns to boost your book sales.' },
    { icon: <Globe size={28} className="text-[var(--gold)]" />, title: 'Global Distribution', desc: 'Your book available worldwide on Amazon platforms.' },
    { icon: <Printer size={28} className="text-[var(--gold)]" />, title: 'Paperback Printing', desc: 'High-quality paperback copies for physical distribution.' },
];

export default function BooksPage() {
    return (
        <div className="pt-20">
            {/* Hero */}
            <section className="min-h-[50vh] flex items-center justify-center text-center bg-[radial-gradient(ellipse_at_20%_50%,rgba(201,169,110,0.08)_0%,transparent_50%),radial-gradient(ellipse_at_80%_20%,rgba(201,169,110,0.05)_0%,transparent_40%),var(--darker)] pt-20 px-8">
                <div>
                    <span className="section-label">PUBLISHING</span>
                    <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold leading-tight mb-5 bg-gradient-to-br from-white via-[var(--gold-light)] to-[var(--gold)] bg-clip-text text-transparent" style={{ fontFamily: "'Playfair Display', serif" }}>
                        Bessghaier Publishing
                    </h1>
                    <p className="text-[var(--text-muted)] max-w-[600px] mx-auto mb-8 text-base">
                        Amazon Kindle Publishing with dedicated marketing. Paperback copies available!
                    </p>
                    <a href="https://wa.me/21692644215" target="_blank" className="btn-gold">
                        <WhatsAppIcon size={16} /> Contact Us
                    </a>
                </div>
            </section>

            {/* Books Grid */}
            <section className="py-20 px-8 bg-[var(--darker)]">
                <div className="text-center mb-12">
                    <span className="section-label">OUR BOOKS</span>
                    <h2 className="section-title text-3xl md:text-4xl">Available Books</h2>
                    <div className="gold-line" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-[1200px] mx-auto">
                    {books.map(book => (
                        <div key={book.id} className="card-dark">
                            <div className="h-[180px] bg-gradient-to-br from-[#1a1a1a] to-[#2d2d2d] flex items-center justify-center relative">
                                <BookOpen size={48} className="text-[var(--gold)]" />
                                <span className="absolute top-4 right-4 bg-[var(--gold)]/15 px-3 py-1 rounded-full text-[0.65rem] text-[var(--gold)] font-semibold">
                                    {book.badge}
                                </span>
                            </div>
                            <div className="p-6">
                                <h3 className="text-lg mb-2 text-white font-semibold">{book.title}</h3>
                                <p className="text-[var(--text-muted)] text-sm mb-4 leading-relaxed">{book.desc}</p>
                                <div className="text-xl font-bold text-[var(--gold)] mb-4">{book.price}</div>
                                <div className="flex gap-2">
                                    <button onClick={() => alert('Coming soon!')} className="btn-gold text-xs py-2 px-3 flex-1 justify-center">
                                        <ShoppingCart size={12} /> Buy
                                    </button>
                                    <button onClick={() => alert('Coming soon!')} className="btn-outline text-xs py-2 px-3 flex-1 justify-center">
                                        <ExternalLink size={12} /> Amazon
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            {/* Services */}
            <section className="py-20 px-8 bg-[var(--dark)]">
                <div className="text-center mb-12">
                    <span className="section-label">SERVICES</span>
                    <h2 className="section-title text-3xl md:text-4xl">Publishing Services</h2>
                    <div className="gold-line" />
                </div>
                <p className="text-[var(--text-muted)] text-center mb-8 max-w-[800px] mx-auto text-base">
                    We offer complete publishing services from manuscript to global distribution.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 max-w-[800px] mx-auto">
                    {services.map((s, i) => (
                        <div key={i} className="bg-[var(--dark-card)] p-7 rounded-2xl border border-[var(--gold)]/[0.08] text-center transition-all hover:-translate-y-1 hover:border-[var(--gold)]/20 hover:shadow-[0_15px_40px_rgba(0,0,0,0.3)]">
                            <div className="mb-4">{s.icon}</div>
                            <h4 className="text-white text-base mb-3 font-semibold">{s.title}</h4>
                            <p className="text-[var(--text-muted)] text-sm">{s.desc}</p>
                        </div>
                    ))}
                </div>
            </section>
        </div>
    );
}


