import {
    Gavel,
    Users,
    Building2,
    Plane,
    BookOpen,
    ShieldCheck,
    Lock,
    Percent
} from 'lucide-react';
import WhatsAppIcon from '@/components/WhatsAppIcon';

const ruleSections = [
    {
        icon: <Gavel size={20} className="text-[var(--gold)]" />,
        title: 'Pre-Approval Required',
        items: [
            'All collaborations must be pre-approved by Bessghaier Holding management.',
            'Submit your collaboration proposal via WhatsApp or email.',
            'Wait for approval before starting any joint activities.',
            'Unapproved collaborations will not be recognized.',
        ]
    },
    {
        icon: <ShieldCheck size={20} className="text-[var(--gold)]" />,
        title: 'Brand Standards',
        items: [
            'Partners must maintain Bessghaier Holding brand standards.',
            'Use official logos and branding materials only.',
            'Do not modify or alter brand assets without permission.',
            'All public communications must be approved.',
        ]
    },
    {
        icon: <Percent size={20} className="text-[var(--gold)]" />,
        title: 'Revenue Sharing',
        items: [
            'Revenue sharing terms will be defined in the collaboration agreement.',
            'Payments are processed monthly or per project.',
            'All financial transactions must be documented.',
            'Commission rates vary by collaboration type.',
        ]
    },
    {
        icon: <Lock size={20} className="text-[var(--gold)]" />,
        title: 'Confidentiality',
        items: [
            'Confidentiality agreement is required for all partners.',
            'Do not share sensitive business information.',
            'Protect customer data and privacy.',
            'Breach of confidentiality will terminate collaboration.',
        ]
    },
];

const collabTypes = [
    { icon: <Users size={24} className="text-[var(--gold)]" />, title: 'Influencer Partnerships', desc: 'Promote our services to your audience and earn commission.' },
    { icon: <Building2 size={24} className="text-[var(--gold)]" />, title: 'Real Estate Joint Ventures', desc: 'Partner on property sales and development projects.' },
    { icon: <Plane size={24} className="text-[var(--gold)]" />, title: 'Tourism Package Deals', desc: 'Create and sell combined tourism packages.' },
    { icon: <BookOpen size={24} className="text-[var(--gold)]" />, title: 'Publishing Distribution', desc: 'Distribute and market books in your region.' },
];

export default function RulesPage() {
    return (
        <div className="pt-20">
            {/* Hero */}
            <section className="min-h-[40vh] flex items-center justify-center text-center bg-[radial-gradient(ellipse_at_20%_50%,rgba(201,169,110,0.08)_0%,transparent_50%),radial-gradient(ellipse_at_80%_20%,rgba(201,169,110,0.05)_0%,transparent_40%),var(--darker)] pt-20 px-8">
                <div>
                    <span className="section-label">COLLABORATION</span>
                    <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold leading-tight mb-5 bg-gradient-to-br from-white via-[var(--gold-light)] to-[var(--gold)] bg-clip-text text-transparent" style={{ fontFamily: "'Playfair Display', serif" }}>
                        Collaboration Rules
                    </h1>
                    <p className="text-[var(--text-muted)] max-w-[600px] mx-auto mb-8 text-base">
                        Terms and conditions for partners, collaborators, and business associates.
                    </p>
                    <a href="https://wa.me/21692644215?text=I want to collaborate" target="_blank" className="btn-gold">
                        <WhatsAppIcon size={16} /> Apply for Collaboration
                    </a>
                </div>
            </section>

            {/* Rules */}
            <section className="py-20 px-8 bg-[var(--darker)]">
                <div className="text-center mb-12">
                    <span className="section-label">RULES</span>
                    <h2 className="section-title text-3xl md:text-4xl">General Rules</h2>
                    <div className="gold-line" />
                </div>
                <div className="max-w-[800px] mx-auto">
                    {ruleSections.map((section, i) => (
                        <div key={i} className="bg-[var(--dark-card)] rounded-2xl p-7 mb-5 border border-[var(--gold)]/[0.08] transition-all hover:border-[var(--gold)]/20 hover:shadow-[0_15px_40px_rgba(0,0,0,0.3)]">
                            <h3 className="text-[var(--gold)] text-base mb-4 flex items-center gap-3 font-semibold">
                                {section.icon} {section.title}
                            </h3>
                            <ul className="list-none">
                                {section.items.map((item, j) => (
                                    <li key={j} className="text-[var(--text-muted)] text-sm mb-2 pl-5 relative leading-relaxed">
                                        <span className="text-[var(--gold)] absolute left-0 text-lg">&bull;</span>
                                        {item}
                                    </li>
                                ))}
                            </ul>
                        </div>
                    ))}
                </div>
            </section>

            {/* Collaboration Types */}
            <section className="py-20 px-8 bg-[var(--dark)]">
                <div className="text-center mb-12">
                    <span className="section-label">TYPES</span>
                    <h2 className="section-title text-3xl md:text-4xl">Collaboration Types</h2>
                    <div className="gold-line" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 max-w-[800px] mx-auto">
                    {collabTypes.map((c, i) => (
                        <div key={i} className="bg-[var(--dark-card)] p-6 rounded-2xl border border-[var(--gold)]/[0.08] text-center transition-all hover:-translate-y-1 hover:border-[var(--gold)]/20 hover:shadow-[0_15px_40px_rgba(0,0,0,0.3)]">
                            <div className="mb-4">{c.icon}</div>
                            <h4 className="text-white text-sm mb-3 font-semibold">{c.title}</h4>
                            <p className="text-[var(--text-muted)] text-xs">{c.desc}</p>
                        </div>
                    ))}
                </div>
            </section>
        </div>
    );
}


