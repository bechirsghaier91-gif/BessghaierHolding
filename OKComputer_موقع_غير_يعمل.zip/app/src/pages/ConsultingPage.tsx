import {
    ChartLine,
    Target,
    Cog,
    Lightbulb,
    Users,
    Calculator
} from 'lucide-react';
import WhatsAppIcon from '@/components/WhatsAppIcon';

const stats = [
    { num: '10%', label: 'Minimum Revenue Increase' },
    { num: '40%', label: 'Maximum Revenue Increase' },
    { num: '+500', label: 'Clients Helped' },
    { num: '+10', label: 'Years Experience' },
];

const services = [
    { icon: <ChartLine size={28} className="text-[var(--gold)]" />, title: 'Revenue Optimization', desc: 'Strategic analysis to maximize your revenue streams and profitability.' },
    { icon: <Target size={28} className="text-[var(--gold)]" />, title: 'Market Analysis', desc: 'Deep market research and competitive analysis for your industry.' },
    { icon: <Cog size={28} className="text-[var(--gold)]" />, title: 'Process Improvement', desc: 'Streamline operations and improve efficiency across your business.' },
    { icon: <Lightbulb size={28} className="text-[var(--gold)]" />, title: 'Strategic Planning', desc: 'Long-term business strategy and growth planning.' },
    { icon: <Users size={28} className="text-[var(--gold)]" />, title: 'Team Training', desc: 'Professional training programs for your team members.' },
    { icon: <Calculator size={28} className="text-[var(--gold)]" />, title: 'Financial Analysis', desc: 'Complete financial health check and optimization.' },
];

const steps = [
    { num: '1', title: 'Analysis', desc: 'We analyze your current business situation and identify opportunities.' },
    { num: '2', title: 'Strategy', desc: 'We develop a customized strategy tailored to your specific needs.' },
    { num: '3', title: 'Implementation', desc: 'We help you implement the recommended changes step by step.' },
    { num: '4', title: 'Results', desc: 'We measure results and ensure continuous improvement.' },
];

export default function ConsultingPage() {
    return (
        <div className="pt-20">
            {/* Hero */}
            <section className="min-h-[50vh] flex items-center justify-center text-center bg-[radial-gradient(ellipse_at_20%_50%,rgba(201,169,110,0.08)_0%,transparent_50%),radial-gradient(ellipse_at_80%_20%,rgba(201,169,110,0.05)_0%,transparent_40%),var(--darker)] pt-20 px-8">
                <div>
                    <span className="section-label">CONSULTING</span>
                    <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold leading-tight mb-5 bg-gradient-to-br from-white via-[var(--gold-light)] to-[var(--gold)] bg-clip-text text-transparent" style={{ fontFamily: "'Playfair Display', serif" }}>
                        Business Consulting
                    </h1>
                    <p className="text-[var(--text-muted)] max-w-[600px] mx-auto mb-8 text-base">
                        Improve revenue from 10% to over 40%. Expert consulting for all types of projects.
                    </p>
                    <a href="https://wa.me/21692644215" target="_blank" className="btn-gold">
                        <WhatsAppIcon size={16} /> Free Consultation
                    </a>
                </div>
            </section>

            {/* Stats */}
            <section className="py-20 px-8 bg-[var(--darker)]">
                <div className="text-center mb-12">
                    <span className="section-label">RESULTS</span>
                    <h2 className="section-title text-3xl md:text-4xl">Proven Results</h2>
                    <div className="gold-line" />
                </div>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 max-w-[1000px] mx-auto">
                    {stats.map((s, i) => (
                        <div key={i} className="bg-[var(--dark-card)] p-6 md:p-8 rounded-2xl border border-[var(--gold)]/[0.08] text-center transition-all hover:-translate-y-1 hover:border-[var(--gold)]/20 hover:shadow-[0_15px_40px_rgba(0,0,0,0.3)]">
                            <div className="text-3xl md:text-4xl font-bold text-[var(--gold)] leading-none">{s.num}</div>
                            <div className="text-[var(--text-muted)] text-sm mt-3">{s.label}</div>
                        </div>
                    ))}
                </div>
            </section>

            {/* Services */}
            <section className="py-20 px-8 bg-[var(--dark)]">
                <div className="text-center mb-12">
                    <span className="section-label">SERVICES</span>
                    <h2 className="section-title text-3xl md:text-4xl">Consulting Services</h2>
                    <div className="gold-line" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 max-w-[800px] mx-auto">
                    {services.map((s, i) => (
                        <div key={i} className="bg-[var(--dark-card)] p-7 rounded-2xl border border-[var(--gold)]/[0.08] text-center transition-all hover:-translate-y-1 hover:border-[var(--gold)]/20 hover:shadow-[0_15px_40px_rgba(0,0,0,0.3)]">
                            <div className="mb-4">{s.icon}</div>
                            <h4 className="text-white text-base mb-3 font-semibold">{s.title}</h4>
                            <p className="text-[var(--text-muted)] text-sm">{s.desc}</p>
                        </div>
                    ))}
                </div>
            </section>

            {/* Process */}
            <section className="py-20 px-8 bg-[var(--darker)]">
                <div className="text-center mb-12">
                    <span className="section-label">PROCESS</span>
                    <h2 className="section-title text-3xl md:text-4xl">How We Work</h2>
                    <div className="gold-line" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 max-w-[1000px] mx-auto">
                    {steps.map((step, i) => (
                        <div key={i} className="bg-[var(--dark-card)] p-6 rounded-2xl border border-[var(--gold)]/[0.08] text-center relative">
                            <div className="w-10 h-10 rounded-full bg-[var(--gold)] text-[var(--dark)] flex items-center justify-center font-bold mx-auto mb-4 text-base">
                                {step.num}
                            </div>
                            <h4 className="text-white text-sm mb-3 font-semibold">{step.title}</h4>
                            <p className="text-[var(--text-muted)] text-xs leading-relaxed">{step.desc}</p>
                        </div>
                    ))}
                </div>
            </section>
        </div>
    );
}
