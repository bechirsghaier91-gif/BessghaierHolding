import { useState } from 'react';
import {
    Check,
    Calendar,
    User,
    Phone,
    Moon,
    X,
    Info
} from 'lucide-react';
import WhatsAppIcon from '@/components/WhatsAppIcon';

interface Property {
    id: string;
    title: string;
    description: string;
    price: string;
    priceLabel: string;
    badge: 'sale' | 'rent';
    features: string[];
    images: string[];
}

const properties: { forSale: Property[]; forRent: Property[] } = {
    forSale: [
        {
            id: 'villa-nefta',
            title: 'Villa Nefta',
            description: 'Beautiful villa with garden and pool in the heart of Tozeur oasis.',
            price: '350,000 TND',
            priceLabel: 'For Sale',
            badge: 'sale',
            features: ['4 Bedrooms', '3 Bathrooms', '500 m2 Garden', 'Swimming Pool'],
            images: [
                'https://i.postimg.cc/pLwwXK80/1d056bf9-58da-4e77-bab0-9ce7b3fe3b04.jpg',
                'https://i.postimg.cc/Jzff4jJK/0bf9f2f0-44cf-45e9-8ed8-9690f38f794a.jpg',
                'https://i.postimg.cc/8CLqFsBx/2e9c89ed-a44d-43f6-b9ce-cac1c37416fc.jpg',
                'https://i.postimg.cc/FHMMs0c2/b19eca96-e6f5-4c5c-9754-606470aabbbe.jpg',
            ]
        }
    ],
    forRent: [
        {
            id: 'traditional-house',
            title: 'Traditional House Tozeur',
            description: 'Authentic traditional house in Tozeur old city. Perfect for desert experience.',
            price: '150 TND/night',
            priceLabel: 'For Rent',
            badge: 'rent',
            features: ['3 Bedrooms', 'Courtyard', 'Traditional Style', 'Furnished'],
            images: [
                'https://i.postimg.cc/8CLqFsBx/2e9c89ed-a44d-43f6-b9ce-cac1c37416fc.jpg',
                'https://i.postimg.cc/pLwwXK80/1d056bf9-58da-4e77-bab0-9ce7b3fe3b04.jpg',
                'https://i.postimg.cc/Jzff4jJK/0bf9f2f0-44cf-45e9-8ed8-9690f38f794a.jpg',
                'https://i.postimg.cc/FHMMs0c2/b19eca96-e6f5-4c5c-9754-606470aabbbe.jpg',
            ]
        }
    ]
};

export default function RealEstatePage() {
    const [showBooking, setShowBooking] = useState(false);
    const [bookName, setBookName] = useState('');
    const [bookPhone, setBookPhone] = useState('');
    const [bookCheckin, setBookCheckin] = useState('');
    const [bookCheckout, setBookCheckout] = useState('');
    const [bookNights, setBookNights] = useState('');
    const [priceDisplay, setPriceDisplay] = useState<{ total: number; base: number; commission: number; rate: string } | null>(null);

    const calculatePrice = (nights: number) => {
        if (nights < 3) return null;
        const pricePerNight = 150;
        const basePrice = nights * pricePerNight;
        const commission = nights < 8 ? basePrice * 0.10 : basePrice * 0.07;
        const rate = nights < 8 ? '10% commission (less than 8 days)' : '7% commission (more than 8 days)';
        return { total: basePrice + commission, base: basePrice, commission, rate };
    };

    const handleNightsChange = (val: string) => {
        setBookNights(val);
        const n = parseInt(val);
        if (n >= 3) {
            setPriceDisplay(calculatePrice(n));
        } else {
            setPriceDisplay(null);
        }
    };

    const submitBooking = () => {
        if (!bookName || !bookPhone || !bookCheckin || !bookCheckout || !bookNights) {
            alert('Please fill all fields!');
            return;
        }
        const n = parseInt(bookNights);
        const calc = calculatePrice(n);
        if (!calc) { alert('Minimum stay is 3 nights!'); return; }

        const message = `New Booking Request:%0A%0AName: ${bookName}%0APhone: ${bookPhone}%0ACheck-in: ${bookCheckin}%0ACheck-out: ${bookCheckout}%0ANights: ${n}%0ABase Price: ${calc.base} TND%0ACommission: ${calc.commission.toFixed(0)} TND%0ATotal: ${calc.total.toFixed(0)} TND`;
        window.open(`https://wa.me/21692644215?text=${message}`, '_blank');
        setShowBooking(false);
    };

    const renderProperty = (property: Property) => (
        <div key={property.id} className="card-dark">
            <div className="h-[220px] bg-cover bg-center relative" style={{ backgroundImage: `url(${property.images[0]})` }}>
                <span className={`absolute top-4 right-4 px-3.5 py-1.5 rounded-full text-[0.7rem] font-semibold ${
                    property.badge === 'sale'
                        ? 'bg-[rgba(37,211,102,0.15)] text-[var(--success)]'
                        : 'bg-[rgba(52,152,219,0.15)] text-[var(--info)]'
                }`}>
                    {property.priceLabel}
                </span>
            </div>
            <div className="p-6">
                <h3 className="text-xl mb-3 text-white font-semibold">{property.title}</h3>
                <p className="text-[var(--text-muted)] text-sm mb-4 leading-relaxed">{property.description}</p>
                <div className="text-2xl font-bold text-[var(--gold)] mb-4">{property.price}</div>
                <ul className="list-none mb-5">
                    {property.features.map((f, j) => (
                        <li key={j} className="flex items-center gap-2 text-[var(--text-muted)] text-sm mb-2">
                            <Check size={14} className="text-[var(--gold)] font-bold" /> {f}
                        </li>
                    ))}
                </ul>
                <div className="grid grid-cols-2 gap-2 mb-4">
                    {property.images.slice(1).map((img, k) => (
                        <img key={k} src={img} alt="" className="w-full h-16 object-cover rounded-lg" />
                    ))}
                </div>
                {property.badge === 'rent' ? (
                    <button onClick={() => setShowBooking(true)} className="w-full btn-gold justify-center text-sm">
                        <Calendar size={16} /> Book Now
                    </button>
                ) : (
                    <a href={`https://wa.me/21692644215?text=I am interested in ${property.title}`} target="_blank" className="w-full btn-gold justify-center text-sm">
                        <WhatsAppIcon size={16} /> Contact
                    </a>
                )}
            </div>
        </div>
    );

    return (
        <div className="pt-20">
            {/* Hero */}
            <section className="min-h-[50vh] flex items-center justify-center text-center bg-[radial-gradient(ellipse_at_20%_50%,rgba(201,169,110,0.08)_0%,transparent_50%),radial-gradient(ellipse_at_80%_20%,rgba(201,169,110,0.05)_0%,transparent_40%),var(--darker)] pt-20 px-8">
                <div>
                    <span className="section-label">REAL ESTATE</span>
                    <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold leading-tight mb-5 bg-gradient-to-br from-white via-[var(--gold-light)] to-[var(--gold)] bg-clip-text text-transparent" style={{ fontFamily: "'Playfair Display', serif" }}>
                        Company Bechir Real Estate
                    </h1>
                    <p className="text-[var(--text-muted)] max-w-[600px] mx-auto mb-8 text-base">
                        Complete real estate services: Sales, Rentals, and Property Management in Tunisia.
                    </p>
                    <a href="https://wa.me/21692644215" target="_blank" className="btn-gold">
                        <WhatsAppIcon size={16} /> Contact Us
                    </a>
                </div>
            </section>

            {/* For Sale */}
            <section className="py-20 px-8 bg-[var(--darker)]">
                <div className="text-center mb-12">
                    <span className="section-label">FOR SALE</span>
                    <h2 className="section-title text-3xl md:text-4xl">Properties For Sale</h2>
                    <div className="gold-line" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-[1200px] mx-auto">
                    {properties.forSale.map(renderProperty)}
                </div>
            </section>

            {/* For Rent */}
            <section className="py-20 px-8 bg-[var(--dark)]">
                <div className="text-center mb-12">
                    <span className="section-label">FOR RENT</span>
                    <h2 className="section-title text-3xl md:text-4xl">Properties For Rent</h2>
                    <div className="gold-line" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-[1200px] mx-auto">
                    {properties.forRent.map(renderProperty)}
                </div>
            </section>

            {/* Booking Modal */}
            {showBooking && (
                <div
                    className="fixed inset-0 bg-black/85 z-[10000] flex items-center justify-center p-5 backdrop-blur-lg"
                    onClick={(e) => { if (e.target === e.currentTarget) setShowBooking(false); }}
                >
                    <div className="bg-[var(--dark-card)] rounded-3xl w-full max-w-[500px] p-8 border border-[var(--gold)]/15 relative max-h-[90vh] overflow-y-auto">
                        <button
                            onClick={() => setShowBooking(false)}
                            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-[var(--dark-surface)] border-none text-[var(--text-muted)] cursor-pointer flex items-center justify-center hover:bg-[var(--danger)] hover:text-white transition-all"
                        >
                            <X size={18} />
                        </button>
                        <h2 className="text-[var(--gold)] text-center mb-1 text-xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
                            <Calendar size={20} className="inline mr-2" /> Book Property
                        </h2>
                        <p className="text-[var(--text-muted)] text-center mb-6 text-sm">Fill in your details to book this property</p>

                        <div className="mb-4">
                            <label className="text-[var(--text-muted)] text-sm mb-2 block"><User size={14} className="inline mr-1 text-[var(--gold)]" /> Full Name</label>
                            <input type="text" value={bookName} onChange={e => setBookName(e.target.value)} placeholder="Your name" className="w-full px-4 py-3 bg-[var(--dark-surface)] border border-white/8 rounded-xl text-[var(--text)] text-sm outline-none focus:border-[var(--gold)]" />
                        </div>
                        <div className="mb-4">
                            <label className="text-[var(--text-muted)] text-sm mb-2 block"><Phone size={14} className="inline mr-1 text-[var(--gold)]" /> Phone</label>
                            <input type="tel" value={bookPhone} onChange={e => setBookPhone(e.target.value)} placeholder="+216 XX XXX XXX" className="w-full px-4 py-3 bg-[var(--dark-surface)] border border-white/8 rounded-xl text-[var(--text)] text-sm outline-none focus:border-[var(--gold)]" />
                        </div>
                        <div className="mb-4">
                            <label className="text-[var(--text-muted)] text-sm mb-2 block"><Calendar size={14} className="inline mr-1 text-[var(--gold)]" /> Check-in Date</label>
                            <input type="date" value={bookCheckin} onChange={e => setBookCheckin(e.target.value)} className="w-full px-4 py-3 bg-[var(--dark-surface)] border border-white/8 rounded-xl text-[var(--text)] text-sm outline-none focus:border-[var(--gold)]" />
                        </div>
                        <div className="mb-4">
                            <label className="text-[var(--text-muted)] text-sm mb-2 block"><Calendar size={14} className="inline mr-1 text-[var(--gold)]" /> Check-out Date</label>
                            <input type="date" value={bookCheckout} onChange={e => setBookCheckout(e.target.value)} className="w-full px-4 py-3 bg-[var(--dark-surface)] border border-white/8 rounded-xl text-[var(--text)] text-sm outline-none focus:border-[var(--gold)]" />
                        </div>
                        <div className="mb-4">
                            <label className="text-[var(--text-muted)] text-sm mb-2 block"><Moon size={14} className="inline mr-1 text-[var(--gold)]" /> Number of Nights (min 3)</label>
                            <input type="number" value={bookNights} onChange={e => handleNightsChange(e.target.value)} placeholder="Minimum 3 nights" min="3" className="w-full px-4 py-3 bg-[var(--dark-surface)] border border-white/8 rounded-xl text-[var(--text)] text-sm outline-none focus:border-[var(--gold)]" />
                        </div>

                        {priceDisplay && (
                            <div className="bg-[var(--dark-surface)] p-4 rounded-xl text-center my-4 border border-[var(--gold)]/10">
                                <div className="text-2xl font-bold text-[var(--gold)]">{priceDisplay.total.toFixed(0)} TND</div>
                                <div className="text-[var(--text-muted)] text-xs mt-2">
                                    {priceDisplay.base} TND (base) + {priceDisplay.commission.toFixed(0)} TND ({priceDisplay.rate})
                                </div>
                            </div>
                        )}

                        <button onClick={submitBooking} className="w-full btn-gold justify-center mt-4">
                            <WhatsAppIcon size={16} /> Book via WhatsApp
                        </button>

                        <div className="mt-4 p-4 bg-[var(--gold)]/5 rounded-xl border border-[var(--gold)]/10">
                            <h5 className="text-[var(--gold)] text-sm mb-2 flex items-center gap-2"><Info size={14} /> Commission & Fees</h5>
                            <ul className="list-none">
                                <li className="text-[var(--text-muted)] text-xs mb-1">- Minimum stay: 3 nights</li>
                                <li className="text-[var(--text-muted)] text-xs mb-1">- Less than 8 days: 10% commission</li>
                                <li className="text-[var(--text-muted)] text-xs mb-1">- More than 8 days: 7% commission</li>
                                <li className="text-[var(--text-muted)] text-xs">- Property viewing without rental: 50 TND</li>
                            </ul>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
