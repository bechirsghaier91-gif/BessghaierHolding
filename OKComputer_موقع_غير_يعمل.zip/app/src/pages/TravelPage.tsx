import {
    Luggage,
    UserCog,
    Car,
    Home,
    Route,
    Handshake,
    Calendar,
    Info,
    TreePalm,
    Mountain,
    Waves,
    Binoculars,
    Landmark,
    Clapperboard
} from 'lucide-react';
import WhatsAppIcon from '@/components/WhatsAppIcon';

const packages = [
    { icon: <Luggage size={32} className="text-[var(--gold)]" />, badge: 'Popular', title: 'Full Package', desc: 'Complete desert experience with accommodation, meals, guided tours, and transportation included.', price: 'From 150 TND/night', features: ['Accommodation included', 'All meals provided', 'Professional guide', 'Airport transfer', 'Desert activities'] },
    { icon: <UserCog size={32} className="text-[var(--gold)]" />, badge: 'Guide', title: 'Guide Only', desc: 'Professional local guide to show you the hidden gems of the Sahara at your own pace.', price: 'From 80 TND/day', features: ['Professional local guide', 'Custom itinerary', 'Hidden gems access', 'Flexible schedule', 'Local insights'] },
    { icon: <Car size={32} className="text-[var(--gold)]" />, badge: 'Transfer', title: 'Airport Transfer', desc: 'Private car pickup from the airport to your hotel or desert camp with professional driver.', price: 'From 50 TND', features: ['Private car', 'Professional driver', 'Airport pickup', 'Hotel/camp dropoff', '24/7 available'] },
    { icon: <Home size={32} className="text-[var(--gold)]" />, badge: 'Private', title: 'Private House', desc: 'Rent a traditional house or modern villa for your stay with full privacy and comfort.', price: 'From 200 TND/night', features: ['Traditional house', 'Modern villa option', 'Full privacy', 'Full comfort', 'Family friendly'] },
    { icon: <Route size={32} className="text-[var(--gold)]" />, badge: 'Short', title: 'Light Circuit', desc: 'Short desert excursion perfect for those with limited time. Half-day or full-day tours.', price: 'From 60 TND', features: ['Half-day tours', 'Full-day tours', 'Perfect for limited time', 'Key highlights', 'Photo opportunities'] },
    { icon: <Handshake size={32} className="text-[var(--gold)]" />, badge: 'Collab', title: 'Collaboration', desc: 'Want to partner with us? We offer collaboration opportunities for travel agencies and influencers.', price: 'Contact Us', features: ['Travel agencies', 'Influencers welcome', 'Revenue sharing', 'Marketing support', 'Exclusive deals'] },
];

const destinations = [
    { tag: 'Tozeur', icon: <TreePalm size={16} />, title: 'Tozeur Oasis', desc: 'Famous palm oasis with natural beauty and rich history.' },
    { tag: 'Nefta', icon: <Mountain size={16} />, title: 'Nefta', desc: 'City of palms and cultural heritage. Gateway to the Sahara.' },
    { tag: 'Landscape', icon: <Waves size={16} />, title: 'Chott el Djerid', desc: 'Largest salt lake in the Tunisian desert.' },
    { tag: 'Adventure', icon: <Binoculars size={16} />, title: 'Desert Safari', desc: 'Explore the magic of the Tunisian Sahara.' },
    { tag: 'Heritage', icon: <Landmark size={16} />, title: 'Traditional Architecture', desc: 'Unique traditional architecture of Tozeur and Nefta.' },
    { tag: 'Cinema', icon: <Clapperboard size={16} />, title: 'Star Wars Locations', desc: 'Visit famous Star Wars filming locations in Tozeur.' },
];

export default function TravelPage() {
    return (
        <div className="pt-20">
            {/* Hero */}
            <section className="min-h-[50vh] flex items-center justify-center text-center bg-[radial-gradient(ellipse_at_20%_50%,rgba(201,169,110,0.08)_0%,transparent_50%),radial-gradient(ellipse_at_80%_20%,rgba(201,169,110,0.05)_0%,transparent_40%),var(--darker)] pt-20 px-8">
                <div>
                    <span className="section-label">DESERT TOURISM</span>
                    <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold leading-tight mb-5 bg-gradient-to-br from-white via-[var(--gold-light)] to-[var(--gold)] bg-clip-text text-transparent" style={{ fontFamily: "'Playfair Display', serif" }}>
                        Djerid Travel
                    </h1>
                    <p className="text-[var(--text-muted)] max-w-[600px] mx-auto mb-8 text-base">
                        Unforgettable journeys through the heart of the Tunisian Sahara. From full package tours to personalized experiences.
                    </p>
                    <a href="https://wa.me/21692644215" target="_blank" className="btn-gold">
                        <WhatsAppIcon size={16} /> Book Now
                    </a>
                </div>
            </section>

            {/* Packages */}
            <section className="py-20 px-8 bg-[var(--darker)]">
                <div className="text-center mb-12">
                    <span className="section-label">TRAVEL PACKAGES</span>
                    <h2 className="section-title text-3xl md:text-4xl">Choose Your Experience</h2>
                    <div className="gold-line" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-[1200px] mx-auto">
                    {packages.map((pkg, i) => (
                        <div key={i} className="card-dark">
                            <div className="h-[160px] bg-gradient-to-br from-[#1a1a1a] to-[#2d2d2d] flex items-center justify-center relative">
                                <div className="text-4xl">{pkg.icon}</div>
                                <span className="absolute top-4 right-4 bg-[var(--gold)]/15 px-3 py-1 rounded-full text-[0.65rem] text-[var(--gold)] font-semibold">
                                    {pkg.badge}
                                </span>
                            </div>
                            <div className="p-6">
                                <h3 className="text-lg mb-2 text-white font-semibold">{pkg.title}</h3>
                                <p className="text-[var(--text-muted)] text-sm mb-4 leading-relaxed">{pkg.desc}</p>
                                <div className="text-xl font-bold text-[var(--gold)] mb-4">{pkg.price}</div>
                                <ul className="list-none mb-5">
                                    {pkg.features.map((f, j) => (
                                        <li key={j} className="flex items-center gap-2 text-[var(--text-muted)] text-xs mb-2">
                                            <span className="text-[var(--gold)] font-bold">&#10003;</span> {f}
                                        </li>
                                    ))}
                                </ul>
                                <div className="flex gap-2">
                                    <a href={`https://wa.me/21692644215?text=I want to book ${pkg.title}`} target="_blank" className="btn-gold text-xs py-2 px-4 flex-1 justify-center">
                                        <Calendar size={12} /> Book
                                    </a>
                                    <a href="https://wa.me/21692644215" target="_blank" className="btn-outline text-xs py-2 px-4 flex-1 justify-center">
                                        <Info size={12} /> Details
                                    </a>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            {/* Destinations */}
            <section className="py-20 px-8 bg-[var(--dark)]">
                <div className="text-center mb-12">
                    <span className="section-label">DESTINATIONS</span>
                    <h2 className="section-title text-3xl md:text-4xl">Explore Tozeur & Nefta</h2>
                    <div className="gold-line" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 max-w-[1200px] mx-auto">
                    {destinations.map((dest, i) => (
                        <div key={i} className="relative h-[220px] md:h-[250px] rounded-2xl overflow-hidden cursor-pointer bg-gradient-to-br from-[#1a1a1a] to-[#2d2d2d] transition-all hover:-translate-y-1 hover:shadow-[0_15px_40px_rgba(0,0,0,0.3)]">
                            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent flex flex-col justify-end p-6">
                                <span className="inline-block bg-[var(--gold)] text-[var(--dark)] px-3 py-1 rounded-full text-[0.65rem] font-bold mb-3 w-fit">
                                    {dest.tag}
                                </span>
                                <h4 className="text-lg text-white mb-2 flex items-center gap-2">{dest.icon} {dest.title}</h4>
                                <p className="text-[var(--text-muted)] text-sm">{dest.desc}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </section>
        </div>
    );
}
