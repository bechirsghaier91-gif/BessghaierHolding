import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/auth-context';
import {
    ShieldCheck,
    X,
    Inbox,
    CheckCircle,
    Clock,
    XCircle,
    User,
    Eye,
    LogOut,
    Home,
    ArrowLeft,
    Shield,
    AlertCircle
} from 'lucide-react';
import WhatsAppIcon from '@/components/WhatsAppIcon';

interface Booking {
    id: string;
    name: string;
    phone: string;
    email: string;
    checkin: string;
    checkout: string;
    nights: string;
    total: string;
    status: 'pending' | 'accepted' | 'rejected';
    createdAt: string;
}

// Mock bookings data (in production, this would come from Firestore)
const mockBookings: Booking[] = [
    {
        id: 'BK001',
        name: 'Ahmed Ben Ali',
        phone: '+21655443322',
        email: 'ahmed@email.com',
        checkin: '2026-06-15',
        checkout: '2026-06-20',
        nights: '5',
        total: '825',
        status: 'pending',
        createdAt: '2026-05-28'
    },
    {
        id: 'BK002',
        name: 'Sarah Mansour',
        phone: '+21699112233',
        email: 'sarah@email.com',
        checkin: '2026-07-01',
        checkout: '2026-07-10',
        nights: '9',
        total: '1445',
        status: 'accepted',
        createdAt: '2026-05-25'
    },
    {
        id: 'BK003',
        name: 'Mohamed Kheder',
        phone: '+21677665544',
        email: 'mohamed@email.com',
        checkin: '2026-06-22',
        checkout: '2026-06-24',
        nights: '2',
        total: 'N/A',
        status: 'rejected',
        createdAt: '2026-05-20'
    }
];

export default function AdminPage() {
    const { user, isAdmin, login, logout, isLoading } = useAuth();
    const navigate = useNavigate();

    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [loginError, setLoginError] = useState('');
    const [loggingIn, setLoggingIn] = useState(false);
    const [filter, setFilter] = useState<'all' | 'pending' | 'accepted' | 'rejected'>('all');
    const [bookings, setBookings] = useState<Booking[]>(mockBookings);
    const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);

    // If already logged in as admin, show dashboard
    const isLoggedInAdmin = isAdmin || (user?.email === 'admin@bessghaier.com');

    useEffect(() => {
        if (!isLoading && !user) {
            // Not logged in, show login form
        }
    }, [isLoading, user]);

    const handleAdminLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoginError('');
        if (!username || !password) {
            setLoginError('Please fill all fields!');
            return;
        }

        setLoggingIn(true);
        try {
            // The login function in auth-context will check for admin credentials
            await login(username, password);
            // If successful, isAdmin will be set to true
        } catch (err: any) {
            // If Firebase auth failed, also try the direct admin credentials
            if (username === 'admin' && password === 'bessghaier2026') {
                try {
                    await login('admin', password);
                } catch (innerErr: any) {
                    setLoginError('Invalid credentials. Please try again.');
                }
            } else {
                setLoginError(err.message || 'Invalid credentials. Please try again.');
            }
        }
        setLoggingIn(false);
    };

    const handleUpdateStatus = (bookingId: string, status: 'accepted' | 'rejected') => {
        setBookings(prev => prev.map(b => b.id === bookingId ? { ...b, status } : b));
    };

    const filteredBookings = filter === 'all' ? bookings : bookings.filter(b => b.status === filter);

    const stats = {
        total: bookings.length,
        accepted: bookings.filter(b => b.status === 'accepted').length,
        pending: bookings.filter(b => b.status === 'pending').length,
        rejected: bookings.filter(b => b.status === 'rejected').length,
    };

    if (isLoading) {
        return (
            <div className="min-h-screen bg-[var(--darker)] flex items-center justify-center">
                <div className="text-[var(--gold)] text-lg animate-pulse">Loading...</div>
            </div>
        );
    }

    // Show login form if not admin
    if (!isLoggedInAdmin) {
        return (
            <div className="min-h-screen bg-[var(--darker)] flex items-center justify-center p-5">
                <div className="bg-[var(--dark-card)] rounded-3xl w-full max-w-[450px] p-8 md:p-10 border border-[var(--gold)]/20 shadow-[0_25px_80px_rgba(0,0,0,0.6)]">
                    <div className="text-center mb-8">
                        <div className="w-[70px] h-[70px] rounded-full bg-[var(--gold)] flex items-center justify-center mx-auto mb-4 text-[var(--dark)]">
                            <ShieldCheck size={28} />
                        </div>
                        <h2 className="text-[var(--gold)] text-xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
                            Admin Access
                        </h2>
                        <p className="text-[var(--text-muted)] text-sm mt-2">Enter your credentials to access the dashboard</p>
                    </div>

                    <form onSubmit={handleAdminLogin}>
                        <div className="mb-5">
                            <label className="block text-[var(--text-muted)] text-sm mb-2">
                                <Shield size={14} className="inline mr-1 text-[var(--gold)]" /> Admin Username
                            </label>
                            <input
                                type="text"
                                value={username}
                                onChange={e => setUsername(e.target.value)}
                                placeholder="admin"
                                className="w-full px-4 py-3 bg-[var(--dark-surface)] border border-white/8 rounded-xl text-[var(--text)] text-sm outline-none focus:border-[var(--gold)] focus:shadow-[0_0_0_3px_rgba(201,169,110,0.1)]"
                            />
                        </div>
                        <div className="mb-5">
                            <label className="block text-[var(--text-muted)] text-sm mb-2">
                                <ShieldCheck size={14} className="inline mr-1 text-[var(--gold)]" /> Admin Password
                            </label>
                            <input
                                type="password"
                                value={password}
                                onChange={e => setPassword(e.target.value)}
                                placeholder="••••••"
                                className="w-full px-4 py-3 bg-[var(--dark-surface)] border border-white/8 rounded-xl text-[var(--text)] text-sm outline-none focus:border-[var(--gold)] focus:shadow-[0_0_0_3px_rgba(201,169,110,0.1)]"
                            />
                        </div>

                        {loginError && (
                            <div className="text-[var(--danger)] text-sm text-center mb-4 flex items-center justify-center gap-2">
                                <AlertCircle size={16} /> {loginError}
                            </div>
                        )}

                        <button
                            type="submit"
                            disabled={loggingIn}
                            className="w-full bg-[var(--gold)] text-[var(--dark)] py-3 rounded-xl font-semibold text-sm border-none cursor-pointer transition-all hover:bg-[var(--gold-light)] hover:-translate-y-0.5 hover:shadow-[0_8px_25px_rgba(201,169,110,0.3)] disabled:opacity-50"
                        >
                            {loggingIn ? 'Authenticating...' : <><ShieldCheck size={16} className="inline mr-2" /> Login to Dashboard</>}
                        </button>
                    </form>

                    <div className="text-center mt-6">
                        <button
                            onClick={() => navigate('/')}
                            className="text-[var(--text-muted)] text-xs no-underline hover:text-[var(--gold)] transition-colors flex items-center gap-1 mx-auto"
                        >
                            <ArrowLeft size={12} /> Back to Website
                        </button>
                    </div>

                    <div className="mt-6 p-3 bg-[var(--dark-surface)] rounded-xl text-center border border-[var(--gold)]/[0.06]">
                        <p className="text-[var(--text-dim)] text-xs">Default: admin / bessghaier2026</p>
                    </div>
                </div>
            </div>
        );
    }

    // Admin Dashboard
    return (
        <div className="min-h-screen bg-[var(--darker)]">
            {/* Admin Header */}
            <div className="fixed top-0 left-0 right-0 z-50 px-6 py-4 bg-[var(--dark)]/95 backdrop-blur-xl border-b border-[var(--gold)]/10 flex justify-between items-center">
                <h1 className="text-sm md:text-base text-[var(--gold)] flex items-center gap-2 font-semibold">
                    <ShieldCheck size={18} /> Admin Dashboard
                </h1>
                <div className="flex items-center gap-3">
                    <div className="hidden md:flex items-center gap-2 text-xs text-[var(--success)]">
                        <span className="w-2 h-2 bg-[var(--success)] rounded-full animate-pulse"></span> Online
                    </div>
                    <button
                        onClick={() => navigate('/')}
                        className="px-4 py-2 bg-[var(--dark-surface)] text-[var(--text)] border border-white/10 rounded-full text-xs no-underline hover:border-[var(--gold)] hover:text-[var(--gold)] transition-all flex items-center gap-1"
                    >
                        <Home size={12} /> Website
                    </button>
                    <button
                        onClick={logout}
                        className="px-4 py-2 bg-[var(--danger)] text-white border-none rounded-full text-xs font-semibold cursor-pointer hover:-translate-y-0.5 transition-all flex items-center gap-1"
                    >
                        <LogOut size={12} /> Logout
                    </button>
                </div>
            </div>

            {/* Admin Content */}
            <div className="max-w-[1400px] mx-auto pt-24 px-6 pb-10">
                {/* Stats */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                    <div className="bg-[var(--dark-card)] rounded-2xl p-5 border border-[var(--gold)]/10 transition-all hover:border-[var(--gold)]/30">
                        <div className="flex items-center gap-3 mb-3">
                            <div className="w-12 h-12 rounded-xl flex items-center justify-center text-lg bg-[rgba(52,152,219,0.1)] text-[var(--info)]">
                                <Inbox size={20} />
                            </div>
                            <div>
                                <h3 className="text-[var(--text-muted)] text-xs">Total Bookings</h3>
                                <div className="text-white text-2xl font-bold">{stats.total}</div>
                            </div>
                        </div>
                    </div>
                    <div className="bg-[var(--dark-card)] rounded-2xl p-5 border border-[var(--gold)]/10 transition-all hover:border-[var(--gold)]/30">
                        <div className="flex items-center gap-3 mb-3">
                            <div className="w-12 h-12 rounded-xl flex items-center justify-center text-lg bg-[rgba(37,211,102,0.1)] text-[var(--success)]">
                                <CheckCircle size={20} />
                            </div>
                            <div>
                                <h3 className="text-[var(--text-muted)] text-xs">Confirmed</h3>
                                <div className="text-white text-2xl font-bold">{stats.accepted}</div>
                            </div>
                        </div>
                    </div>
                    <div className="bg-[var(--dark-card)] rounded-2xl p-5 border border-[var(--gold)]/10 transition-all hover:border-[var(--gold)]/30">
                        <div className="flex items-center gap-3 mb-3">
                            <div className="w-12 h-12 rounded-xl flex items-center justify-center text-lg bg-[rgba(243,156,18,0.1)] text-[var(--warning)]">
                                <Clock size={20} />
                            </div>
                            <div>
                                <h3 className="text-[var(--text-muted)] text-xs">Pending</h3>
                                <div className="text-white text-2xl font-bold">{stats.pending}</div>
                            </div>
                        </div>
                    </div>
                    <div className="bg-[var(--dark-card)] rounded-2xl p-5 border border-[var(--gold)]/10 transition-all hover:border-[var(--gold)]/30">
                        <div className="flex items-center gap-3 mb-3">
                            <div className="w-12 h-12 rounded-xl flex items-center justify-center text-lg bg-[rgba(231,76,60,0.1)] text-[var(--danger)]">
                                <XCircle size={20} />
                            </div>
                            <div>
                                <h3 className="text-[var(--text-muted)] text-xs">Rejected</h3>
                                <div className="text-white text-2xl font-bold">{stats.rejected}</div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Bookings */}
                <div className="bg-[var(--dark-card)] rounded-3xl p-6 border border-[var(--gold)]/10 mb-8">
                    <h3 className="text-[var(--gold)] text-base mb-5 flex items-center gap-2 font-semibold">
                        <Inbox size={18} /> All Booking Conversations
                    </h3>

                    <div className="flex gap-2 mb-5 flex-wrap">
                        {(['all', 'pending', 'accepted', 'rejected'] as const).map(f => (
                            <button
                                key={f}
                                onClick={() => setFilter(f)}
                                className={`px-4 py-2 rounded-full text-xs cursor-pointer transition-all font-inherit border-none capitalize ${
                                    filter === f
                                        ? 'bg-[var(--gold)] text-[var(--dark)] font-semibold'
                                        : 'bg-[var(--dark-surface)] text-[var(--text)] hover:text-[var(--gold)]'
                                }`}
                            >
                                {f}
                            </button>
                        ))}
                    </div>

                    {filteredBookings.length === 0 ? (
                        <div className="text-center py-12 text-[var(--text-muted)]">
                            <Inbox size={40} className="mx-auto mb-3 opacity-30" />
                            <p>No bookings yet</p>
                        </div>
                    ) : (
                        <div className="space-y-4">
                            {filteredBookings.map(booking => (
                                <div key={booking.id} className="bg-[var(--dark-surface)] rounded-2xl p-5 border border-white/5 transition-all hover:border-[var(--gold)]/20">
                                    <div className="flex justify-between items-start mb-4 flex-wrap gap-2">
                                        <div className="flex items-center gap-3">
                                            <div className="w-12 h-12 rounded-full bg-[var(--gold)] flex items-center justify-center text-[var(--dark)] text-lg">
                                                <User size={20} />
                                            </div>
                                            <div>
                                                <h4 className="text-white text-sm font-semibold">{booking.name}</h4>
                                                <p className="text-[var(--text-muted)] text-xs">{booking.phone} | {booking.email}</p>
                                            </div>
                                        </div>
                                        <span className={`px-3 py-1 rounded-full text-[0.7rem] font-semibold capitalize ${
                                            booking.status === 'accepted'
                                                ? 'bg-[rgba(37,211,102,0.15)] text-[var(--success)]'
                                                : booking.status === 'rejected'
                                                ? 'bg-[rgba(231,76,60,0.15)] text-[var(--danger)]'
                                                : 'bg-[rgba(243,156,18,0.15)] text-[var(--warning)]'
                                        }`}>
                                            {booking.status}
                                        </span>
                                    </div>

                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                                        <div>
                                            <h5 className="text-[var(--text-muted)] text-xs mb-1">Check-in</h5>
                                            <p className="text-white text-sm">{booking.checkin}</p>
                                        </div>
                                        <div>
                                            <h5 className="text-[var(--text-muted)] text-xs mb-1">Check-out</h5>
                                            <p className="text-white text-sm">{booking.checkout}</p>
                                        </div>
                                        <div>
                                            <h5 className="text-[var(--text-muted)] text-xs mb-1">Nights</h5>
                                            <p className="text-white text-sm">{booking.nights}</p>
                                        </div>
                                        <div>
                                            <h5 className="text-[var(--text-muted)] text-xs mb-1">Total</h5>
                                            <p className="text-[var(--gold)] text-sm font-bold">{booking.total} TND</p>
                                        </div>
                                    </div>

                                    <div className="flex gap-2 flex-wrap">
                                        {booking.status === 'pending' && (
                                            <>
                                                <button
                                                    onClick={() => handleUpdateStatus(booking.id, 'accepted')}
                                                    className="px-4 py-2 rounded-xl border-none text-xs font-semibold cursor-pointer transition-all bg-[var(--success)] text-white hover:-translate-y-0.5 hover:shadow-[0_8px_25px_rgba(37,211,102,0.3)] flex items-center gap-1"
                                                >
                                                    <CheckCircle size={12} /> Accept
                                                </button>
                                                <button
                                                    onClick={() => handleUpdateStatus(booking.id, 'rejected')}
                                                    className="px-4 py-2 rounded-xl border-none text-xs font-semibold cursor-pointer transition-all bg-[var(--danger)] text-white hover:-translate-y-0.5 hover:shadow-[0_8px_25px_rgba(231,76,60,0.3)] flex items-center gap-1"
                                                >
                                                    <XCircle size={12} /> Reject
                                                </button>
                                            </>
                                        )}
                                        <button
                                            onClick={() => setSelectedBooking(booking)}
                                            className="px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all bg-[var(--dark-surface)] text-[var(--text)] border border-white/10 hover:border-[var(--gold)] hover:text-[var(--gold)] flex items-center gap-1"
                                        >
                                            <Eye size={12} /> View
                                        </button>
                                        <a
                                            href={`https://wa.me/${booking.phone.replace(/\+/g, '')}`}
                                            target="_blank"
                                            className="px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all bg-[var(--success)] text-white hover:-translate-y-0.5 flex items-center gap-1 no-underline"
                                        >
                                            <WhatsAppIcon size={12} /> WhatsApp
                                        </a>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* Management Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                    <div
                        onClick={() => alert('Properties management - Coming soon!')}
                        className="bg-[var(--dark-card)] rounded-2xl p-8 border border-[var(--gold)]/10 cursor-pointer text-center transition-all hover:border-[var(--gold)] hover:-translate-y-1 hover:shadow-[0_15px_40px_rgba(0,0,0,0.3)]"
                    >
                        <div className="w-[60px] h-[60px] rounded-full bg-[var(--gold)]/10 flex items-center justify-center mx-auto mb-4 text-[var(--gold)] text-xl">
                            <Home size={24} />
                        </div>
                        <h4 className="text-white text-sm font-semibold mb-2">Properties</h4>
                        <p className="text-[var(--text-muted)] text-xs">Add, edit, or remove properties for sale and rent</p>
                    </div>
                    <div
                        onClick={() => alert('Books management - Coming soon!')}
                        className="bg-[var(--dark-card)] rounded-2xl p-8 border border-[var(--gold)]/10 cursor-pointer text-center transition-all hover:border-[var(--gold)] hover:-translate-y-1 hover:shadow-[0_15px_40px_rgba(0,0,0,0.3)]"
                    >
                        <div className="w-[60px] h-[60px] rounded-full bg-[var(--gold)]/10 flex items-center justify-center mx-auto mb-4 text-[var(--gold)] text-xl">
                            <BookOpenIcon size={24} />
                        </div>
                        <h4 className="text-white text-sm font-semibold mb-2">Books</h4>
                        <p className="text-[var(--text-muted)] text-xs">Manage Amazon Kindle books and pricing</p>
                    </div>
                    <div
                        onClick={() => alert('Settings - Coming soon!')}
                        className="bg-[var(--dark-card)] rounded-2xl p-8 border border-[var(--gold)]/10 cursor-pointer text-center transition-all hover:border-[var(--gold)] hover:-translate-y-1 hover:shadow-[0_15px_40px_rgba(0,0,0,0.3)]"
                    >
                        <div className="w-[60px] h-[60px] rounded-full bg-[var(--gold)]/10 flex items-center justify-center mx-auto mb-4 text-[var(--gold)] text-xl">
                            <CogIcon size={24} />
                        </div>
                        <h4 className="text-white text-sm font-semibold mb-2">Booking Settings</h4>
                        <p className="text-[var(--text-muted)] text-xs">Configure prices, commissions, and rules</p>
                    </div>
                </div>
            </div>

            {/* View Booking Modal */}
            {selectedBooking && (
                <div
                    className="fixed inset-0 bg-black/85 z-[10000] flex items-center justify-center p-5 backdrop-blur-lg"
                    onClick={(e) => { if (e.target === e.currentTarget) setSelectedBooking(null); }}
                >
                    <div className="bg-[var(--dark-card)] rounded-3xl w-full max-w-[450px] p-8 border border-[var(--gold)]/15 relative">
                        <button
                            onClick={() => setSelectedBooking(null)}
                            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-[var(--dark-surface)] border-none text-[var(--text-muted)] cursor-pointer flex items-center justify-center hover:bg-[var(--danger)] hover:text-white transition-all"
                        >
                            <X size={18} />
                        </button>
                        <h3 className="text-[var(--gold)] text-lg font-bold mb-4">Booking Details</h3>
                        <div className="space-y-3 text-sm">
                            <div className="flex justify-between"><span className="text-[var(--text-muted)]">Client:</span><span className="text-white">{selectedBooking.name}</span></div>
                            <div className="flex justify-between"><span className="text-[var(--text-muted)]">Phone:</span><span className="text-white">{selectedBooking.phone}</span></div>
                            <div className="flex justify-between"><span className="text-[var(--text-muted)]">Email:</span><span className="text-white">{selectedBooking.email}</span></div>
                            <div className="flex justify-between"><span className="text-[var(--text-muted)]">Check-in:</span><span className="text-white">{selectedBooking.checkin}</span></div>
                            <div className="flex justify-between"><span className="text-[var(--text-muted)]">Check-out:</span><span className="text-white">{selectedBooking.checkout}</span></div>
                            <div className="flex justify-between"><span className="text-[var(--text-muted)]">Nights:</span><span className="text-white">{selectedBooking.nights}</span></div>
                            <div className="flex justify-between"><span className="text-[var(--text-muted)]">Total:</span><span className="text-[var(--gold)] font-bold">{selectedBooking.total} TND</span></div>
                            <div className="flex justify-between"><span className="text-[var(--text-muted)]">Status:</span><span className="capitalize">{selectedBooking.status}</span></div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

function BookOpenIcon({ size = 16 }: { size?: number }) {
    return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>;
}

function CogIcon({ size = 16 }: { size?: number }) {
    return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20a8 8 0 1 0 0-16 8 8 0 0 0 0 16Z"/><path d="M12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/></svg>;
}
