import {
    Megaphone,
    Users,
    Share2,
    Globe,
    Camera,
    BarChart3
} from 'lucide-react';
import WhatsAppIcon from '@/components/WhatsAppIcon';

const services = [
    { icon: <Megaphone size={28} className="text-[var(--gold)]" />, title: 'Brand Promotion', desc: 'Complete brand promotion strategy across all platforms.' },
    { icon: <Users size={28} className="text-[var(--gold)]" />, title: 'Influencer Marketing', desc: 'Connect with top influencers for your brand campaigns.' },
    { icon: <Share2 size={28} className="text-[var(--gold)]" />, title: 'Social Media', desc: 'Full social media management and content creation.' },
    { icon: <Globe size={28} className="text-[var(--gold)]" />, title: 'Global Reach', desc: 'International marketing campaigns for global brands.' },
    { icon: <Camera size={28} className="text-[var(--gold)]" />, title: 'Content Creation', desc: 'Professional photos, videos, and creative content.' },
    { icon: <BarChart3 size={28} className="text-[var(--gold)]" />, title: 'Analytics', desc: 'Detailed analytics and performance tracking.' },
];

const influencers = [
    { name: 'Influencer 1', niche: 'Lifestyle & Travel', followers: '50K+' },
    { name: 'Influencer 2', niche: 'Fashion & Beauty', followers: '100K+' },
    { name: 'Influencer 3', niche: 'Business & Tech', followers: '75K+' },
    { name: 'Influencer 4', niche: 'Food & Lifestyle', followers: '30K+' },
];

export default function MarketingPage() {
    return (
        <div className="pt-20">
            {/* Hero */}
            <section className="min-h-[50vh] flex items-center justify-center text-center bg-[radial-gradient(ellipse_at_20%_50%,rgba(201,169,110,0.08)_0%,transparent_50%),radial-gradient(ellipse_at_80%_20%,rgba(201,169,110,0.05)_0%,transparent_40%),var(--darker)] pt-20 px-8">
                <div>
                    <span className="section-label">MARKETING</span>
                    <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold leading-tight mb-5 bg-gradient-to-br from-white via-[var(--gold-light)] to-[var(--gold)] bg-clip-text text-transparent" style={{ fontFamily: "'Playfair Display', serif" }}>
                        Marketing & Influencers
                    </h1>
                    <p className="text-[var(--text-muted)] max-w-[600px] mx-auto mb-8 text-base">
                        Professional marketing with well-known influencers for any brand!
                    </p>
                    <a href="https://wa.me/21692644215" target="_blank" className="btn-gold">
                        <WhatsAppIcon size={16} /> Get Started
                    </a>
                </div>
            </section>

            {/* Services */}
            <section className="py-20 px-8 bg-[var(--darker)]">
                <div className="text-center mb-12">
                    <span className="section-label">SERVICES</span>
                    <h2 className="section-title text-3xl md:text-4xl">Marketing Services</h2>
                    <div className="gold-line" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 max-w-[1200px] mx-auto">
                    {services.map((s, i) => (
                        <div key={i} className="bg-[var(--dark-card)] p-7 rounded-2xl border border-[var(--gold)]/[0.08] text-center transition-all hover:-translate-y-1 hover:border-[var(--gold)]/20 hover:shadow-[0_15px_40px_rgba(0,0,0,0.3)]">
                            <div className="mb-4">{s.icon}</div>
                            <h4 className="text-white text-base mb-3 font-semibold">{s.title}</h4>
                            <p className="text-[var(--text-muted)] text-sm">{s.desc}</p>
                        </div>
                    ))}
                </div>
            </section>

            {/* Influencers */}
            <section className="py-20 px-8 bg-[var(--dark)]">
                <div className="text-center mb-12">
                    <span className="section-label">INFLUENCERS</span>
                    <h2 className="section-title text-3xl md:text-4xl">Our Network</h2>
                    <div className="gold-line" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 max-w-[800px] mx-auto">
                    {influencers.map((inf, i) => (
                        <div key={i} className="bg-[var(--dark-card)] p-6 rounded-2xl border border-[var(--gold)]/[0.08] flex items-center gap-5 transition-all hover:border-[var(--gold)]/20 hover:shadow-[0_15px_40px_rgba(0,0,0,0.3)]">
                            <div className="w-14 h-14 min-w-[56px] rounded-full bg-[var(--dark-surface)] flex items-center justify-center text-xl text-[var(--gold)] border-2 border-[var(--gold)]">
                                <Users size={24} />
                            </div>
                            <div>
                                <h4 className="text-white text-base mb-1 font-semibold">{inf.name}</h4>
                                <p className="text-[var(--text-muted)] text-sm">{inf.niche}</p>
                                <p className="text-[var(--gold)] text-xs font-semibold mt-1">{inf.followers} Followers</p>
                            </div>
                        </div>
                    ))}
                </div>
            </section>
        </div>
    );
}


