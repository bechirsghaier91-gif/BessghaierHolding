import { useState } from 'react';
import {
    Newspaper,
    Home,
    Plane,
    Briefcase,
    Megaphone,
    Handshake,
    Calendar,
    User,
    ArrowRight,
    X
} from 'lucide-react';

const articles = [
    { id: 'real-estate', image: 'https://i.postimg.cc/pLwwXK80/1d056bf9-58da-4e77-bab0-9ce7b3fe3b04.jpg', badge: 'Real Estate', title: 'Villa Nefta - Our Latest Project', date: 'Jan 2026', author: 'Bessghaier Team', desc: 'Discover our beautiful villa in Nefta with traditional architecture and modern amenities...', content: 'Our Villa Nefta project features traditional Tunisian architecture combined with modern amenities. The villa includes 4 bedrooms, 3 bathrooms, a 500m2 garden, and a swimming pool. Located in the heart of Nefta, this property offers an authentic desert living experience with all contemporary comforts.' },
    { id: 'travel', image: 'https://i.postimg.cc/8CLqFsBx/2e9c89ed-a44d-43f6-b9ce-cac1c37416fc.jpg', badge: 'Travel', title: 'Desert Safari Experience', date: 'Dec 2025', author: 'Djerid Travel', desc: 'Join us for an unforgettable journey through the Tunisian Sahara with our expert guides...', content: 'Our Desert Safari Experience takes you through the magical landscapes of the Tunisian Sahara. With expert local guides, you will discover hidden oases, traditional Berber villages, and breathtaking sand dunes. The tour includes camel rides, traditional meals, and overnight camping under the stars.' },
    { id: 'consulting', image: 'https://i.postimg.cc/FHMMs0c2/b19eca96-e6f5-4c5c-9754-606470aabbbe.jpg', badge: 'Consulting', title: 'Revenue Growth Success Story', date: 'Nov 2025', author: 'Consulting Team', desc: 'How we helped a local business increase revenue by 40% through strategic consulting...', content: 'We recently helped a local tourism business increase their revenue by 40% through strategic consulting. Our approach included market analysis, process optimization, and digital marketing strategies. The results exceeded expectations within just 3 months of implementation.' },
    { id: 'marketing', image: 'https://i.postimg.cc/Jzff4jJK/0bf9f2f0-44cf-45e9-8ed8-9690f38f794a.jpg', badge: 'Marketing', title: 'Influencer Campaign Results', date: 'Oct 2025', author: 'Marketing Team', desc: 'Our latest influencer marketing campaign reached over 100K people and boosted sales...', content: 'Our latest influencer marketing campaign partnered with 5 top travel influencers to promote Djerid Travel. The campaign reached over 100,000 people, generated 500+ inquiries, and resulted in 150 bookings. The ROI was 300% compared to traditional advertising methods.' },
    { id: 'publishing', image: null, badge: 'Publishing', title: 'New Book Launch on Amazon', date: 'Sep 2025', author: 'Publishing Team', desc: 'We successfully published and marketed a new book on Amazon Kindle with great results...', content: 'Bessghaier Publishing successfully launched a new book on Amazon Kindle, achieving bestseller status in its category within the first week. Our dedicated marketing team handled everything from formatting to promotion, resulting in over 1,000 copies sold in the first month.' },
    { id: 'collaboration', image: null, badge: 'Collaboration', title: 'New Partnership Announcement', date: 'Aug 2025', author: 'Bessghaier Holding', desc: 'We are excited to announce new collaboration opportunities for travel agencies and influencers...', content: 'We are excited to announce new collaboration opportunities for 2026. Whether you are a travel agency, influencer, or business owner, we offer partnership programs with attractive commission structures. Contact us to discuss how we can work together.' },
];

const publicityTypes = [
    { icon: <Home size={24} className="text-[var(--gold)]" />, title: 'Real Estate', desc: 'Promote your properties for sale or rent' },
    { icon: <Plane size={24} className="text-[var(--gold)]" />, title: 'Tourism', desc: 'Advertise tours, hotels, and experiences' },
    { icon: <Briefcase size={24} className="text-[var(--gold)]" />, title: 'Services', desc: 'Promote any business or service' },
];

export default function MagazinePage() {
    const [selectedArticle, setSelectedArticle] = useState<typeof articles[0] | null>(null);

    return (
        <div className="pt-20">
            {/* Hero */}
            <section className="min-h-[50vh] flex items-center justify-center text-center bg-[radial-gradient(ellipse_at_20%_50%,rgba(201,169,110,0.08)_0%,transparent_50%),radial-gradient(ellipse_at_80%_20%,rgba(201,169,110,0.05)_0%,transparent_40%),var(--darker)] pt-20 px-8">
                <div>
                    <span className="section-label">MAGAZINE</span>
                    <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold leading-tight mb-5 bg-gradient-to-br from-white via-[var(--gold-light)] to-[var(--gold)] bg-clip-text text-transparent" style={{ fontFamily: "'Playfair Display', serif" }}>
                        Bessghaier Magazine
                    </h1>
                    <p className="text-[var(--text-muted)] max-w-[600px] mx-auto mb-8 text-base">
                        All in One Place - Find all properties, ongoing projects, tourism experiences, and investment opportunities with Bessghaier Holding!
                    </p>
                    <a href="#articles" className="btn-gold">
                        <Newspaper size={16} /> Read Stories
                    </a>
                </div>
            </section>

            {/* Articles */}
            <section id="articles" className="py-20 px-8 bg-[var(--darker)]">
                <div className="text-center mb-12">
                    <span className="section-label">STORIES</span>
                    <h2 className="section-title text-3xl md:text-4xl">Our Experiences</h2>
                    <div className="gold-line" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-[1200px] mx-auto">
                    {articles.map(article => (
                        <div
                            key={article.id}
                            onClick={() => setSelectedArticle(article)}
                            className="card-dark cursor-pointer"
                        >
                            {article.image ? (
                                <div className="h-[180px] bg-cover bg-center relative" style={{ backgroundImage: `url(${article.image})` }}>
                                    <span className="absolute top-4 right-4 bg-[var(--gold)]/15 px-3 py-1 rounded-full text-[0.65rem] text-[var(--gold)] font-semibold">
                                        {article.badge}
                                    </span>
                                </div>
                            ) : (
                                <div className="h-[180px] bg-gradient-to-br from-[#1a1a1a] to-[#2d2d2d] flex items-center justify-center relative">
                                    <Handshake size={48} className="text-[var(--gold)]" />
                                    <span className="absolute top-4 right-4 bg-[var(--gold)]/15 px-3 py-1 rounded-full text-[0.65rem] text-[var(--gold)] font-semibold">
                                        {article.badge}
                                    </span>
                                </div>
                            )}
                            <div className="p-6">
                                <h3 className="text-base mb-3 text-white font-semibold">{article.title}</h3>
                                <div className="flex gap-4 text-[var(--text-dim)] text-xs mb-4">
                                    <span className="flex items-center gap-1"><Calendar size={12} /> {article.date}</span>
                                    <span className="flex items-center gap-1"><User size={12} /> {article.author}</span>
                                </div>
                                <p className="text-[var(--text-muted)] text-sm mb-4 leading-relaxed">{article.desc}</p>
                                <span className="text-[var(--gold)] text-sm font-semibold inline-flex items-center gap-2 hover:gap-3 transition-all">
                                    Read More <ArrowRight size={14} />
                                </span>
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            {/* Publicity */}
            <section className="py-20 px-8 bg-[var(--dark)]">
                <div className="text-center mb-12">
                    <span className="section-label">PUBLICITY</span>
                    <h2 className="section-title text-3xl md:text-4xl">Advertise With Us</h2>
                    <div className="gold-line" />
                </div>
                <div className="bg-[var(--dark-card)] rounded-3xl p-8 md:p-10 max-w-[1000px] mx-auto border border-[var(--gold)]/[0.08] text-center">
                    <h3 className="text-[var(--gold)] text-xl mb-4 flex items-center justify-center gap-2">
                        <Megaphone size={20} /> Promote Your Business
                    </h3>
                    <p className="text-[var(--text-muted)] mb-8">
                        Reach thousands of potential customers through our magazine and platform. We offer advertising opportunities for:
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 my-8">
                        {publicityTypes.map((p, i) => (
                            <div key={i} className="bg-[var(--dark-surface)] p-5 rounded-2xl border border-[var(--gold)]/[0.08]">
                                <div className="mb-3">{p.icon}</div>
                                <h4 className="text-white text-sm mb-2 font-semibold">{p.title}</h4>
                                <p className="text-[var(--text-muted)] text-xs">{p.desc}</p>
                            </div>
                        ))}
                    </div>
                    <a href="https://wa.me/21692644215?text=I want to advertise on Bessghaier Magazine" target="_blank" className="btn-gold">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z" /></svg> Contact for Advertising
                    </a>
                </div>
            </section>

            {/* Article Modal */}
            {selectedArticle && (
                <div
                    className="fixed inset-0 bg-black/85 z-[10000] flex items-center justify-center p-5 backdrop-blur-lg"
                    onClick={(e) => { if (e.target === e.currentTarget) setSelectedArticle(null); }}
                >
                    <div className="bg-[var(--dark-card)] rounded-3xl w-full max-w-[600px] p-8 border border-[var(--gold)]/15 relative max-h-[90vh] overflow-y-auto">
                        <button
                            onClick={() => setSelectedArticle(null)}
                            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-[var(--dark-surface)] border-none text-[var(--text-muted)] cursor-pointer flex items-center justify-center hover:bg-[var(--danger)] hover:text-white transition-all"
                        >
                            <X size={18} />
                        </button>
                        <span className="bg-[var(--gold)]/15 px-3 py-1 rounded-full text-[0.65rem] text-[var(--gold)] font-semibold mb-4 inline-block">
                            {selectedArticle.badge}
                        </span>
                        <h2 className="text-xl text-white font-bold mb-3" style={{ fontFamily: "'Playfair Display', serif" }}>
                            {selectedArticle.title}
                        </h2>
                        <div className="flex gap-4 text-[var(--text-dim)] text-xs mb-5">
                            <span className="flex items-center gap-1"><Calendar size={12} /> {selectedArticle.date}</span>
                            <span className="flex items-center gap-1"><User size={12} /> {selectedArticle.author}</span>
                        </div>
                        <p className="text-[var(--text-muted)] text-sm leading-relaxed">{selectedArticle.content}</p>
                    </div>
                </div>
            )}
        </div>
    );
}
