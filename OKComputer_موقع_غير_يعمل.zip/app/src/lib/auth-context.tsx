import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import {
    auth,
    db,
    onAuthStateChanged,
    signInWithEmailAndPassword,
    createUserWithEmailAndPassword,
    updateProfile,
    signOut,
    sendPasswordResetEmail,
    doc,
    setDoc,
    getDoc
} from './firebase';
import type { User as FirebaseUser } from 'firebase/auth';

interface AuthContextType {
    user: FirebaseUser | null;
    isAdmin: boolean;
    isLoading: boolean;
    login: (email: string, password: string) => Promise<void>;
    register: (name: string, email: string, password: string) => Promise<void>;
    logout: () => Promise<void>;
    forgotPassword: (email: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const ADMIN_CREDENTIALS = {
    username: 'admin',
    password: 'bessghaier2026'
};

export function AuthProvider({ children }: { children: ReactNode }) {
    const [user, setUser] = useState<FirebaseUser | null>(null);
    const [isAdmin, setIsAdmin] = useState(false);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
            if (firebaseUser) {
                setUser(firebaseUser);
                try {
                    const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
                    if (userDoc.exists()) {
                        setIsAdmin(userDoc.data()?.role === 'admin');
                    }
                } catch (e) {
                    console.error('Error checking admin status:', e);
                }
            } else {
                setUser(null);
                setIsAdmin(false);
            }
            setIsLoading(false);
        });

        return unsubscribe;
    }, []);

    const login = async (email: string, password: string) => {
        // Check for admin credentials
        if (email === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password) {
            try {
                await signInWithEmailAndPassword(auth, 'admin@bessghaier.com', 'Admin123!');
            } catch (err: any) {
                if (err.code === 'auth/invalid-credential' || err.code === 'auth/user-not-found') {
                    const cred = await createUserWithEmailAndPassword(auth, 'admin@bessghaier.com', 'Admin123!');
                    await updateProfile(cred.user, { displayName: 'Admin' });
                    await setDoc(doc(db, 'users', cred.user.uid), {
                        name: 'Admin',
                        email: 'admin@bessghaier.com',
                        role: 'admin',
                        createdAt: new Date().toISOString()
                    });
                } else {
                    throw err;
                }
            }
            setIsAdmin(true);
            return;
        }
        // Regular user login
        await signInWithEmailAndPassword(auth, email, password);
    };

    const register = async (name: string, email: string, password: string) => {
        const cred = await createUserWithEmailAndPassword(auth, email, password);
        await updateProfile(cred.user, { displayName: name });
        await setDoc(doc(db, 'users', cred.user.uid), {
            name: name,
            email: email,
            role: 'user',
            createdAt: new Date().toISOString()
        });
    };

    const logout = async () => {
        await signOut(auth);
        setIsAdmin(false);
        setUser(null);
    };

    const forgotPassword = async (email: string) => {
        await sendPasswordResetEmail(auth, email);
    };

    return (
        <AuthContext.Provider value={{ user, isAdmin, isLoading, login, register, logout, forgotPassword }}>
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth() {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}
