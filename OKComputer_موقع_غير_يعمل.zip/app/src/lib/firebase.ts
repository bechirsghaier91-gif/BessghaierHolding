// Firebase Configuration - Bessghaier Holding
import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged, updateProfile, sendPasswordResetEmail } from 'firebase/auth';
import { getFirestore, collection, doc, setDoc, getDoc, getDocs, addDoc, deleteDoc, updateDoc, query, orderBy, Timestamp } from 'firebase/firestore';

const firebaseConfig = {
    apiKey: "AIzaSyCE31o4_mvi3Mvgi_7u73dhfQ5YXv8k-hM",
    authDomain: "bessghaier-holding.firebaseapp.com",
    projectId: "bessghaier-holding",
    storageBucket: "bessghaier-holding.firebasestorage.app",
    messagingSenderId: "273989837068",
    appId: "1:273989837068:web:b6ca09649ac8901a50a929",
    measurementId: "G-YEV8WCFBCR"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export {
    auth,
    db,
    // Auth functions
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut,
    onAuthStateChanged,
    updateProfile,
    sendPasswordResetEmail,
    // Firestore functions
    collection,
    doc,
    setDoc,
    getDoc,
    getDocs,
    addDoc,
    deleteDoc,
    updateDoc,
    query,
    orderBy,
    Timestamp
};

export default app;
