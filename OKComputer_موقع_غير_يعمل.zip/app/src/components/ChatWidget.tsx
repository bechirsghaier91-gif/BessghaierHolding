import { useState, useRef, useEffect } from 'react';
import { Bot, Send, X } from 'lucide-react';

interface Message {
    text: string;
    isBot: boolean;
}

const botResponses: Record<string, string> = {
    'price': 'Our prices vary by service:<br/>- Real Estate: Contact us<br/>- Travel: From 150 TND/night<br/>- Books: $7.99 - $14.99<br/>- Consulting: Free first session!',
    'book': 'You can book through:<br/>1. WhatsApp: 92644215<br/>2. Contact form on website<br/>3. Direct booking system (coming soon)',
    'hello': 'Hello! Welcome to Bessghaier Holding! How can I assist you today?',
    'hi': 'Hello! Welcome to Bessghaier Holding! How can I assist you today?',
    'collab': 'For collaboration, please check our "Rules & Collab" room.<br/><br/>You can also contact us directly via WhatsApp: <strong>92644215</strong>',
};

function getBotResponse(input: string): string {
    const lower = input.toLowerCase();
    for (const [key, response] of Object.entries(botResponses)) {
        if (lower.includes(key)) return response;
    }
    return 'Thank you for your message! Our team will contact you soon.<br/><br/>You can also reach us via WhatsApp at <strong>92644215</strong> or email <strong>bechirsghaier91@gmail.com</strong>';
}

export default function ChatWidget() {
    const [open, setOpen] = useState(false);
    const [messages, setMessages] = useState<Message[]>([
        { text: 'Hello! I am Bessghaier AI Assistant. How can I help you today?', isBot: true }
    ]);
    const [input, setInput] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const sendMessage = () => {
        const text = input.trim();
        if (!text) return;

        setMessages(prev => [...prev, { text, isBot: false }]);
        setInput('');

        setTimeout(() => {
            const response = getBotResponse(text);
            setMessages(prev => [...prev, { text: response, isBot: true }]);
        }, 800);
    };

    return (
        <>
            {open && (
                <div className="fixed bottom-24 left-6 z-[9998] w-[320px] h-[400px] bg-[var(--dark-card)] rounded-2xl border border-[var(--gold)]/15 shadow-[0_20px_60px_rgba(0,0,0,0.5)] flex flex-col overflow-hidden">
                    <div className="p-4 bg-[var(--gold)] text-[var(--dark)] flex items-center gap-3">
                        <div>
                            <h4 className="text-sm font-semibold flex items-center gap-2">
                                <Bot size={16} /> Bessghaier AI
                            </h4>
                            <span className="text-xs opacity-80">Online - Replies instantly</span>
                        </div>
                    </div>
                    <div className="flex-1 p-4 overflow-y-auto flex flex-col gap-2.5">
                        {messages.map((msg, i) => (
                            <div
                                key={i}
                                className={`max-w-[80%] p-3 rounded-2xl text-sm leading-relaxed ${
                                    msg.isBot
                                        ? 'bg-[var(--dark-surface)] text-[var(--text)] self-start rounded-bl-sm'
                                        : 'bg-[var(--gold)] text-[var(--dark)] self-end rounded-br-sm'
                                }`}
                                dangerouslySetInnerHTML={{ __html: msg.text }}
                            />
                        ))}
                        <div ref={messagesEndRef} />
                    </div>
                    <div className="p-3 border-t border-white/5 flex gap-2">
                        <input
                            type="text"
                            value={input}
                            onChange={e => setInput(e.target.value)}
                            onKeyPress={e => e.key === 'Enter' && sendMessage()}
                            placeholder="Type your question..."
                            className="flex-1 px-4 py-2.5 bg-[var(--dark-surface)] border border-white/8 rounded-full text-[var(--text)] font-inherit text-sm outline-none focus:border-[var(--gold)]"
                        />
                        <button
                            onClick={sendMessage}
                            className="w-9 h-9 rounded-full bg-[var(--gold)] border-none text-[var(--dark)] cursor-pointer flex items-center justify-center hover:scale-110 transition-transform"
                        >
                            <Send size={16} />
                        </button>
                    </div>
                </div>
            )}

            <button
                onClick={() => setOpen(!open)}
                className="fixed bottom-6 left-6 z-[9997] w-[60px] h-[60px] rounded-full bg-[var(--gold)] border-none text-[var(--dark)] text-2xl cursor-pointer shadow-[0_5px_25px_rgba(201,169,110,0.4)] flex items-center justify-center hover:scale-110 transition-transform"
            >
                {open ? <X size={24} /> : <Bot size={24} />}
            </button>
        </>
    );
}
