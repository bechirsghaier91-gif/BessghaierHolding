import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '@/lib/auth-context';
import {
    Menu,
    X,
    User,
    LogOut,
    ShieldCheck,
    Home,
    BookOpen,
    Plane,
    Building2,
    Briefcase,
    Megaphone,
    Newspaper,
    Gavel,
    LogIn
} from 'lucide-react';

export default function Navbar() {
    const [mobileOpen, setMobileOpen] = useState(false);
    const [loginOpen, setLoginOpen] = useState(false);
    const [loginTab, setLoginTab] = useState<'login' | 'register'>('login');
    const { user, isAdmin, login, register, logout } = useAuth();
    const location = useLocation();

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [name, setName] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);



    const handleLogin = async () => {
        setError('');
        if (!email || !password) { setError('Please fill all fields!'); return; }
        setLoading(true);
        try {
            await login(email, password);
            setLoginOpen(false);
            setEmail('');
            setPassword('');
        } catch (err: any) {
            setError(err.message || 'Login failed!');
        }
        setLoading(false);
    };

    const handleRegister = async () => {
        setError('');
        if (!name || !email || !password) { setError('Please fill all fields!'); return; }
        if (password.length < 6) { setError('Password must be at least 6 characters!'); return; }
        setLoading(true);
        try {
            await register(name, email, password);
            setLoginOpen(false);
            setName('');
            setEmail('');
            setPassword('');
        } catch (err: any) {
            setError(err.message || 'Registration failed!');
        }
        setLoading(false);
    };

    const navLinks = [
        { to: '/', label: 'Home', icon: Home },
        { to: '/books', label: 'Books', icon: BookOpen },
        { to: '/travel', label: 'Travel', icon: Plane },
        { to: '/real-estate', label: 'Real Estate', icon: Building2 },
        { to: '/consulting', label: 'Consulting', icon: Briefcase },
        { to: '/marketing', label: 'Marketing', icon: Megaphone },
        { to: '/magazine', label: 'Magazine', icon: Newspaper },
        { to: '/rules', label: 'Rules', icon: Gavel },
    ];

    return (
        <>
            <nav className="fixed top-0 left-0 right-0 z-50 px-4 md:px-8 py-4 flex justify-between items-center bg-[var(--dark)]/95 backdrop-blur-xl border-b border-[var(--gold)]/10">
                <Link to="/" className="flex items-center gap-3 text-[var(--gold)] font-bold text-lg md:text-xl no-underline">
                    <img src="https://i.postimg.cc/jS0wHFYF/IMG-1699.jpg" alt="Bessghaier Holding" className="w-9 h-9 md:w-10 md:h-10 rounded-full object-cover border-2 border-[var(--gold)]" />
                    <span className="hidden sm:inline">BESSGHAIER HOLDING</span>
                    <span className="sm:hidden">BH</span>
                </Link>

                <ul className="hidden lg:flex items-center gap-6 list-none">
                    {navLinks.map(link => (
                        <li key={link.to}>
                            <Link
                                to={link.to}
                                className={`text-[0.82rem] font-medium transition-colors duration-300 no-underline ${
                                    location.pathname === link.to
                                        ? 'text-[var(--gold)]'
                                        : 'text-[var(--text-muted)] hover:text-[var(--gold)]'
                                }`}
                            >
                                {link.label}
                            </Link>
                        </li>
                    ))}
                </ul>

                <div className="flex items-center gap-3">
                    {user ? (
                        <div className="flex items-center gap-3">
                            {isAdmin && (
                                <Link
                                    to="/admin"
                                    className="hidden md:flex items-center gap-2 text-[var(--success)] text-xs font-semibold no-underline"
                                >
                                    <ShieldCheck size={16} /> Admin
                                </Link>
                            )}
                            <span className="hidden md:inline text-[var(--text-muted)] text-xs">
                                {user.displayName || user.email}
                            </span>
                            <button
                                onClick={logout}
                                className="flex items-center gap-2 bg-[var(--danger)] text-white px-4 py-2 rounded-full text-xs font-semibold border-none cursor-pointer transition-all hover:-translate-y-0.5"
                            >
                                <LogOut size={14} /> <span className="hidden sm:inline">Logout</span>
                            </button>
                        </div>
                    ) : (
                        <button
                            onClick={() => { setLoginOpen(true); setError(''); }}
                            className="btn-gold text-xs py-2 px-4"
                        >
                            <User size={14} /> Login
                        </button>
                    )}

                    <button
                        className="lg:hidden bg-transparent border-none text-[var(--gold)] text-xl cursor-pointer"
                        onClick={() => setMobileOpen(!mobileOpen)}
                    >
                        {mobileOpen ? <X size={24} /> : <Menu size={24} />}
                    </button>
                </div>
            </nav>

            {/* Mobile Menu */}
            {mobileOpen && (
                <div className="fixed top-[70px] left-0 right-0 bg-[var(--dark-card)] z-40 border-b border-[var(--gold)]/10 p-5 lg:hidden">
                    {navLinks.map(link => (
                        <Link
                            key={link.to}
                            to={link.to}
                            onClick={() => setMobileOpen(false)}
                            className="flex items-center gap-3 text-[var(--text)] py-3 text-sm no-underline border-b border-white/5"
                        >
                            <link.icon size={16} className="text-[var(--gold)]" /> {link.label}
                        </Link>
                    ))}
                </div>
            )}

            {/* Login Modal */}
            {loginOpen && (
                <div
                    className="fixed inset-0 bg-black/85 z-[10000] flex items-center justify-center p-5 backdrop-blur-lg"
                    onClick={(e) => { if (e.target === e.currentTarget) setLoginOpen(false); }}
                >
                    <div className="bg-[var(--dark-card)] rounded-3xl w-full max-w-[450px] p-8 border border-[var(--gold)]/15 relative max-h-[90vh] overflow-y-auto">
                        <button
                            onClick={() => setLoginOpen(false)}
                            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-[var(--dark-surface)] border-none text-[var(--text-muted)] cursor-pointer flex items-center justify-center text-lg hover:bg-[var(--danger)] hover:text-white transition-all"
                        >
                            <X size={18} />
                        </button>

                        <div className="text-center mb-6">
                            <div className="w-[70px] h-[70px] rounded-full bg-[var(--gold)] flex items-center justify-center mx-auto mb-4 text-[var(--dark)]">
                                <ShieldCheck size={28} />
                            </div>
                            <h2 className="text-[var(--gold)] text-xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
                                Account Access
                            </h2>
                            <p className="text-[var(--text-muted)] text-sm mt-2">Login or create a new account</p>
                        </div>

                        <div className="flex gap-1 mb-5 bg-[var(--dark-surface)] p-1 rounded-xl">
                            <button
                                onClick={() => { setLoginTab('login'); setError(''); }}
                                className={`flex-1 py-2.5 border-none rounded-lg text-sm font-semibold cursor-pointer transition-all font-inherit ${
                                    loginTab === 'login'
                                        ? 'bg-[var(--gold)] text-[var(--dark)]'
                                        : 'bg-transparent text-[var(--text-muted)] hover:text-[var(--gold)]'
                                }`}
                            >
                                Login
                            </button>
                            <button
                                onClick={() => { setLoginTab('register'); setError(''); }}
                                className={`flex-1 py-2.5 border-none rounded-lg text-sm font-semibold cursor-pointer transition-all font-inherit ${
                                    loginTab === 'register'
                                        ? 'bg-[var(--gold)] text-[var(--dark)]'
                                        : 'bg-transparent text-[var(--text-muted)] hover:text-[var(--gold)]'
                                }`}
                            >
                                Register
                            </button>
                        </div>

                        {loginTab === 'login' ? (
                            <div>
                                <div className="mb-4">
                                    <label className="block text-[var(--text-muted)] text-sm mb-2">
                                        Email
                                    </label>
                                    <input
                                        type="email"
                                        placeholder="your@email.com"
                                        value={email}
                                        onChange={e => setEmail(e.target.value)}
                                        className="w-full px-4 py-3 bg-[var(--dark-surface)] border border-white/8 rounded-xl text-[var(--text)] font-inherit text-sm outline-none transition-all focus:border-[var(--gold)] focus:shadow-[0_0_0_3px_rgba(201,169,110,0.1)]"
                                    />
                                </div>
                                <div className="mb-4">
                                    <label className="block text-[var(--text-muted)] text-sm mb-2">
                                        Password
                                    </label>
                                    <input
                                        type="password"
                                        placeholder="********"
                                        value={password}
                                        onChange={e => setPassword(e.target.value)}
                                        className="w-full px-4 py-3 bg-[var(--dark-surface)] border border-white/8 rounded-xl text-[var(--text)] font-inherit text-sm outline-none transition-all focus:border-[var(--gold)] focus:shadow-[0_0_0_3px_rgba(201,169,110,0.1)]"
                                    />
                                </div>
                                {error && (
                                    <div className="text-[var(--danger)] text-sm text-center mb-4 flex items-center justify-center gap-2">
                                        <span>{error}</span>
                                    </div>
                                )}
                                <button
                                    onClick={handleLogin}
                                    disabled={loading}
                                    className="w-full btn-gold justify-center disabled:opacity-50"
                                >
                                    {loading ? 'Please wait...' : <><LogIn size={16} /> Login</>}
                                </button>
                            </div>
                        ) : (
                            <div>
                                <div className="mb-4">
                                    <label className="block text-[var(--text-muted)] text-sm mb-2">
                                        Full Name
                                    </label>
                                    <input
                                        type="text"
                                        placeholder="Your name"
                                        value={name}
                                        onChange={e => setName(e.target.value)}
                                        className="w-full px-4 py-3 bg-[var(--dark-surface)] border border-white/8 rounded-xl text-[var(--text)] font-inherit text-sm outline-none transition-all focus:border-[var(--gold)] focus:shadow-[0_0_0_3px_rgba(201,169,110,0.1)]"
                                    />
                                </div>
                                <div className="mb-4">
                                    <label className="block text-[var(--text-muted)] text-sm mb-2">
                                        Email
                                    </label>
                                    <input
                                        type="email"
                                        placeholder="your@email.com"
                                        value={email}
                                        onChange={e => setEmail(e.target.value)}
                                        className="w-full px-4 py-3 bg-[var(--dark-surface)] border border-white/8 rounded-xl text-[var(--text)] font-inherit text-sm outline-none transition-all focus:border-[var(--gold)] focus:shadow-[0_0_0_3px_rgba(201,169,110,0.1)]"
                                    />
                                </div>
                                <div className="mb-4">
                                    <label className="block text-[var(--text-muted)] text-sm mb-2">
                                        Password
                                    </label>
                                    <input
                                        type="password"
                                        placeholder="Min 6 characters"
                                        value={password}
                                        onChange={e => setPassword(e.target.value)}
                                        className="w-full px-4 py-3 bg-[var(--dark-surface)] border border-white/8 rounded-xl text-[var(--text)] font-inherit text-sm outline-none transition-all focus:border-[var(--gold)] focus:shadow-[0_0_0_3px_rgba(201,169,110,0.1)]"
                                    />
                                </div>
                                {error && (
                                    <div className="text-[var(--danger)] text-sm text-center mb-4">
                                        <span>{error}</span>
                                    </div>
                                )}
                                <button
                                    onClick={handleRegister}
                                    disabled={loading}
                                    className="w-full btn-gold justify-center disabled:opacity-50"
                                >
                                    {loading ? 'Creating...' : <><User size={16} /> Create Account</>}
                                </button>
                            </div>
                        )}

                        <div className="text-center mt-4">
                            <Link
                                to="/admin"
                                onClick={() => setLoginOpen(false)}
                                className="text-[var(--text-dim)] text-xs no-underline hover:text-[var(--gold)] transition-colors"
                            >
                                Admin Dashboard
                            </Link>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
}
