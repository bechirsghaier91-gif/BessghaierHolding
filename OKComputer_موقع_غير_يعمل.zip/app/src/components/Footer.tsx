import { Link } from 'react-router-dom';
import { Crown, Instagram, Facebook, Linkedin } from 'lucide-react';
import WhatsAppIcon from './WhatsAppIcon';

export default function Footer() {
    return (
        <footer className="bg-[var(--darker)] border-t border-[var(--gold)]/[0.08] pt-16 pb-8 px-8">
            <div className="max-w-[1200px] mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
                <div className="lg:col-span-1">
                    <h3 className="text-xl text-[var(--gold)] mb-4 flex items-center gap-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                        <Crown size={20} /> BESSGHAIER HOLDING
                    </h3>
                    <p className="text-[var(--text-muted)] text-sm leading-relaxed mb-5">
                        A multi-activity entity combining real estate investment, publishing, and desert tourism.
                    </p>
                    <div className="flex gap-2.5">
                        <a href="#" target="_blank" className="w-10 h-10 bg-[var(--dark-card)] rounded-xl flex items-center justify-center text-[var(--text-muted)] no-underline text-base transition-all border border-white/5 hover:bg-[var(--gold)] hover:text-[var(--dark)] hover:-translate-y-1">
                            <Instagram size={18} />
                        </a>
                        <a href="#" target="_blank" className="w-10 h-10 bg-[var(--dark-card)] rounded-xl flex items-center justify-center text-[var(--text-muted)] no-underline text-base transition-all border border-white/5 hover:bg-[var(--gold)] hover:text-[var(--dark)] hover:-translate-y-1">
                            <Facebook size={18} />
                        </a>
                        <a href="https://wa.me/21692644215" target="_blank" className="w-10 h-10 bg-[var(--dark-card)] rounded-xl flex items-center justify-center text-[var(--text-muted)] no-underline text-base transition-all border border-white/5 hover:bg-[var(--gold)] hover:text-[var(--dark)] hover:-translate-y-1">
                            <WhatsAppIcon size={18} />
                        </a>
                        <a href="#" target="_blank" className="w-10 h-10 bg-[var(--dark-card)] rounded-xl flex items-center justify-center text-[var(--text-muted)] no-underline text-base transition-all border border-white/5 hover:bg-[var(--gold)] hover:text-[var(--dark)] hover:-translate-y-1">
                            <Linkedin size={18} />
                        </a>
                    </div>
                </div>

                <div>
                    <h4 className="text-white text-sm font-semibold mb-5">Our Rooms</h4>
                    <ul className="list-none">
                        <li className="mb-3"><Link to="/books" className="text-[var(--text-muted)] text-sm no-underline hover:text-[var(--gold)] transition-colors">Publishing</Link></li>
                        <li className="mb-3"><Link to="/real-estate" className="text-[var(--text-muted)] text-sm no-underline hover:text-[var(--gold)] transition-colors">Real Estate</Link></li>
                        <li className="mb-3"><Link to="/travel" className="text-[var(--text-muted)] text-sm no-underline hover:text-[var(--gold)] transition-colors">Djerid Travel</Link></li>
                        <li className="mb-3"><Link to="/consulting" className="text-[var(--text-muted)] text-sm no-underline hover:text-[var(--gold)] transition-colors">Consulting</Link></li>
                        <li className="mb-3"><Link to="/marketing" className="text-[var(--text-muted)] text-sm no-underline hover:text-[var(--gold)] transition-colors">Marketing</Link></li>
                    </ul>
                </div>

                <div>
                    <h4 className="text-white text-sm font-semibold mb-5">Services</h4>
                    <ul className="list-none">
                        <li className="mb-3"><Link to="/real-estate" className="text-[var(--text-muted)] text-sm no-underline hover:text-[var(--gold)] transition-colors">Property Sales</Link></li>
                        <li className="mb-3"><Link to="/travel" className="text-[var(--text-muted)] text-sm no-underline hover:text-[var(--gold)] transition-colors">Desert Tourism</Link></li>
                        <li className="mb-3"><Link to="/consulting" className="text-[var(--text-muted)] text-sm no-underline hover:text-[var(--gold)] transition-colors">Consulting</Link></li>
                        <li className="mb-3"><Link to="/marketing" className="text-[var(--text-muted)] text-sm no-underline hover:text-[var(--gold)] transition-colors">Marketing</Link></li>
                    </ul>
                </div>

                <div>
                    <h4 className="text-white text-sm font-semibold mb-5">Quick Links</h4>
                    <ul className="list-none">
                        <li className="mb-3"><Link to="/" className="text-[var(--text-muted)] text-sm no-underline hover:text-[var(--gold)] transition-colors">Home</Link></li>
                        <li className="mb-3"><Link to="/magazine" className="text-[var(--text-muted)] text-sm no-underline hover:text-[var(--gold)] transition-colors">Magazine</Link></li>
                        <li className="mb-3"><Link to="/rules" className="text-[var(--text-muted)] text-sm no-underline hover:text-[var(--gold)] transition-colors">Rules</Link></li>
                        <li className="mb-3"><Link to="/admin" className="text-[var(--text-muted)] text-sm no-underline hover:text-[var(--gold)] transition-colors">Admin</Link></li>
                    </ul>
                </div>
            </div>

            <div className="max-w-[1200px] mx-auto mt-10 pt-8 border-t border-white/5 flex justify-between text-[var(--text-dim)] text-xs flex-wrap gap-2">
                <p>&copy; 2026 Bessghaier Holding. All Rights Reserved.</p>
                <p className="flex items-center gap-1"><span className="text-[var(--gold)]">&#9829;</span> Crafted with Excellence</p>
            </div>
        </footer>
    );
}
